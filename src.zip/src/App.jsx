// App.js
import { Routes, Route } from 'react-router-dom';
import Navbar from "./components/Navbar";
import ScrollToTop from "./components/ScrollToTop"
import Home from "./components/Home";
import About from "./components/About";
import Values from "./components/Values";
import Services from "./components/Services"; // New "Our Services" component
import Contact from "./components/Contact";
import Login from "./components/Login";
import Login_admin from "./components/Login_admin";
import Client from "./components/Client";
import AffiliatePage from "./components/AffiliatePage";
import PersonalDetailsForm from "./components/PersonalDetailsForm";
import Payment from "./components/Payment";
import AdminPanel from "./components/AdminPanel";
import Dashboard from "./components/Dashboard";
import ServiceConfiguration from "./components/ServiceConfiguration";
import AddService from "./components/AddService";
import UpdateService from "./components/UpdateService";
import Accounting from "./components/Accounting";
import Affiliates from "./components/Affiliates";
import './app.css'; 
import OrderHistory from './components/OrderHistory';
import ManageOrders from './components/ManageOrders';
import Signout from './components/Signout';
import ProtectedRoute from "./components/ProtectedRoute";
import ManageStatus from "./components/ManageStatus";
import ListUsers from "./components/ListUsers";

export default function App() {
	
  return (
    <>
    
	<ScrollToTop />
		<Routes>
        
			<Route path="/" element={<Home /> }/>
			<Route path="/Login" element={<Login />} />
			<Route path="/Login_admin" element={<Login_admin />} />
			<Route path="/about" element={<About />} />
			<Route path="/values" element={<Values />} />
			<Route path="/services" element={<Services />} />
			<Route path="/Contact" element={<Contact />} />
			
			<Route path="/AdminPanel" element={<ProtectedRoute role="admin"><AdminPanel /> </ProtectedRoute>} /> 
			<Route path="/Accounting" element={<ProtectedRoute role="admin"><Accounting /> </ProtectedRoute>} /> 
			<Route path="/Dashboard"  element={<ProtectedRoute role="admin"><Dashboard />  </ProtectedRoute>} />
			<Route path="/service-configuration"  element={<ProtectedRoute role="admin"><ServiceConfiguration />  </ProtectedRoute>} />
			<Route path="/service-configuration/add"  element={<ProtectedRoute role="admin"><AddService />  </ProtectedRoute>} />
			<Route path="/service-configuration/update"  element={<ProtectedRoute role="admin"><UpdateService />  </ProtectedRoute>} />
			<Route path="/manage-status"  element={<ProtectedRoute role="admin"><ManageStatus />  </ProtectedRoute>} />
			<Route path="/list-users" element={<ProtectedRoute role="admin"> <ListUsers /> </ProtectedRoute>} />
						
			<Route path="/Client" element={<ProtectedRoute>	<Client/> </ProtectedRoute>} />
			<Route path="/Payment" element={<ProtectedRoute> <Payment /></ProtectedRoute>} /> 
			<Route path="/order-history" element={<ProtectedRoute> <OrderHistory /> </ProtectedRoute>} />
			<Route path="/manage-orders" element={<ProtectedRoute> <ManageOrders /> </ProtectedRoute>} />
			<Route path="/Logout" element={<Signout />} />
		
		</Routes>

    </>
  );
}
