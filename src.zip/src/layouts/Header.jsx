// import React, { useState } from "react";
// import { useNavigate, Link } from "react-router-dom";
// import { FaUserCircle } from "react-icons/fa";
// import logo from '../assets/logo.png'; // Adjust path based on your file location


// const Header = () => {
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
//   const navigate = useNavigate();

//   const toggleDropdown = () => {
//     setDropdownOpen(!dropdownOpen);
//   };

//   const closeDropDown = () => {
//     setDropdownOpen(false);
//   };

//   const handleLogoutClick = () => {
//     closeDropDown();
//     setShowLogoutConfirm(true);
//   };

//   const handleConfirmLogout = () => {
//     // Clear local storage (or however you're storing user session)
//     localStorage.clear();
//     setShowLogoutConfirm(false);
//     navigate("/login"); // Redirect to login page
//   };

//   const handleCancelLogout = () => {
//     setShowLogoutConfirm(false);
//   };

 

//   return (
//     <>
//       <header className="bg-[#074572] text-[#F2F6FA] p-2 lg:pl-6 shadow-md">
//   <div className="flex justify-between items-center">
//     {/* Logo Section */}
//    <div className="flex items-center space-x-3">
//   <img
//     src={logo}
//     alt="Dua Hub Logo"
//     className="h-10 w-10 object-contain"
//   />
//   <div className="text-xl font-bold tracking-wide">
//     DuaHub
//   </div>
// </div>

//     {/* Avatar Section */}
//     <div className="relative flex items-center space-x-4 pr-4">
//       <FaUserCircle
//         className="text-[#F2F6FA] w-8 h-8 cursor-pointer hover:text-gray-200 transition duration-200"
//         onClick={toggleDropdown}
//       />

//       {/* Dropdown Menu */}
//       {dropdownOpen && (
//         <div className="absolute top-10 right-0 w-48 bg-[#0c5d80] text-[#F2F6FA] rounded-md shadow-lg z-20 border border-[#0e7ca6]">
//           <ul>
//             <li className="px-4 py-2 hover:bg-[#106f94] cursor-pointer transition">
//               <Link to="profile" onClick={closeDropDown}>Profile</Link>
//             </li>
//             <li className="px-4 py-2 hover:bg-[#106f94] cursor-pointer transition">
//               Settings
//             </li>
//             <li
//               className="px-4 py-2 hover:bg-red-600 cursor-pointer transition"
//               onClick={handleLogoutClick}
//             >
//               Logout
//             </li>
//           </ul>
//         </div>
//       )}
//     </div>
//   </div>
// </header>


//       {/* Logout Confirmation Modal */}
//       {showLogoutConfirm && (
//         <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
//           <div className="bg-white p-6 rounded-lg shadow-lg w-80 text-center">
//             <h2 className="text-lg font-semibold mb-4">Are you sure you want to logout?</h2>
//             <div className="flex justify-center space-x-4">
//               <button
//                 className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
//                 onClick={handleConfirmLogout}
//               >
//                 Yes
//               </button>
//               <button
//                 className="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500"
//                 onClick={handleCancelLogout}
//               >
//                 No
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </>
//   );
// };

// export default Header;
import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { FaUserCircle } from "react-icons/fa";
import logo from '../assets/logo.png';

const Header = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);
  const closeDropDown = () => setDropdownOpen(false);
  const handleLogoutClick = () => {
    closeDropDown();
    setShowLogoutConfirm(true);
  };
  const handleConfirmLogout = () => {
    localStorage.clear();
    setShowLogoutConfirm(false);
    navigate("/Login");
  };
  const handleCancelLogout = () => setShowLogoutConfirm(false);

  return (
    <>
      <header className="bg-[#074572] text-[#F2F6FA] p-2 md:p-4 shadow-md w-full">
  <div className="flex justify-between items-center w-full">
    {/* Logo + Text on the left */}
   <div className="flex items-center space-x-2 sm:space-x-3 ml-11 sm:ml-0">
  <img
    src={logo}
    alt="Dua Hub Logo"
    className="h-8 w-8 sm:h-10 sm:w-10 object-contain"
  />
  <div className="text-lg sm:text-xl font-bold tracking-wide">DuaHub</div>
</div>


    {/* Avatar on the right */}
    <div className="relative">
      <FaUserCircle
        className="text-[#F2F6FA] w-7 h-7 sm:w-8 sm:h-8 cursor-pointer hover:text-gray-200 transition duration-200"
        onClick={toggleDropdown}
      />
      {dropdownOpen && (
        <div className="absolute right-0 mt-2 w-44 bg-[#0c5d80] text-[#F2F6FA] rounded-md shadow-lg z-20 border border-[#0e7ca6]">
          <ul>
            <li className="px-4 py-2 hover:bg-[#106f94] transition">
              <Link to="profile" onClick={closeDropDown}>Profile</Link>
            </li>
            <li className="px-4 py-2 hover:bg-[#106f94] transition">Settings</li>
            <li
              className="px-4 py-2 hover:bg-red-600 transition"
              onClick={handleLogoutClick}
            >
              Logout
            </li>
          </ul>
        </div>
      )}
    </div>
  </div>
</header>


      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-72 sm:w-80 text-center">
            <h2 className="text-base sm:text-lg font-semibold mb-4">
              Are you sure you want to logout?
            </h2>
            <div className="flex justify-center space-x-4">
              <button
                className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
                onClick={handleConfirmLogout}
              >
                Yes
              </button>
              <button
                className="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500"
                onClick={handleCancelLogout}
              >
                No
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;
