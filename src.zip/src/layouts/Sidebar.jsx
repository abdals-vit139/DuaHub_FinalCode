
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  FaTachometerAlt,
  FaUsers,
  FaProjectDiagram,
  FaTasks,
  FaAddressBook,
  FaChevronDown,
  FaChevronUp,
  FaBars,
  FaTimes
} from "react-icons/fa";

const navItems = [
  { label: "Dashboard", icon: <FaTachometerAlt />, path: "/dashboard" },
  { label: "Manage Orders", icon: <FaAddressBook />, path: "/manage-status" }, // <-- New Tab Added
  { label: "Service Configuration", icon: <FaProjectDiagram />, path: "/service-configuration" },
  { label: "Accounting", icon: <FaAddressBook />, path: "/accounting" },
  { label: "User List", icon: <FaUsers />, path: "/list-users" },
];

const Sidenav = () => {
  const location = useLocation();
  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const isActive = (path) => location.pathname === path;

  useEffect(() => {
    document.body.style.overflow = isMobileOpen ? "hidden" : "";
  }, [isMobileOpen]);

  return (
    <>
      {/* Mobile Menu Button */}
     <div className="md:hidden absolute top-3 left-2 z-50">
  <button onClick={() => setIsMobileOpen(true)} className="text-2xl text-white">
    <FaBars />
  </button>
</div>

      {/* Mobile Sidebar */}
      <div
        className={`fixed inset-0 z-50 bg-[#074572] text-[#F2F6FA] w-64 h-full transform transition-transform duration-300 md:hidden ${
          isMobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex justify-between items-center p-4 border-b border-[#0a5a80]">
          {/* <div className="text-xl font-bold">Menu</div> */}
          <button onClick={() => setIsMobileOpen(false)} className="text-2xl">
            <FaTimes />
          </button>
        </div>

        <ul className="px-4 py-6 space-y-2 overflow-y-auto">
          {navItems.map(({ label, icon, path }) => (
            <li key={path}>
              {label === "Service Configuration" ? (
                <>
                  <div className="flex justify-between items-center">
                    <Link
                      to={path}
                      onClick={() => setIsMobileOpen(false)}
                      className={`flex items-center p-3 rounded-lg w-full transition-all duration-200 ${
                        isActive(path)
                          ? "bg-[#0b6d95] text-white shadow"
                          : "hover:bg-[#0c81b2] hover:text-white text-[#F2F6FA]"
                      }`}
                    >
                      <span className="text-xl">{icon}</span>
                      <span className="ml-3">{label}</span>
                    </Link>
                    <button onClick={() => setIsSubmenuOpen(!isSubmenuOpen)} className="ml-2">
                      {isSubmenuOpen ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                  </div>
                  {isSubmenuOpen && (
                    <ul className="ml-6 mt-1 space-y-1 text-sm">
                      <li>
                        <Link
                          to="/service-configuration/add"
                          onClick={() => setIsMobileOpen(false)}
                          className="block px-3 py-2 rounded bg-[#F2F6FA] text-[#074572]"
                        >
                          Add
                        </Link>
                      </li>
                      <li>
                        <Link
                          to="/service-configuration/update"
                          onClick={() => setIsMobileOpen(false)}
                          className="block px-3 py-2 rounded bg-[#F2F6FA] text-[#074572]"
                        >
                          Update
                        </Link>
                      </li>
                    </ul>
                  )}
                </>
              ) : (
                <Link
                  to={path}
                  onClick={() => setIsMobileOpen(false)}
                  className={`flex items-center p-3 rounded-lg transition-all duration-200 ${
                    isActive(path)
                      ? "bg-[#0b6d95] text-white shadow"
                      : "hover:bg-[#0c81b2] hover:text-white text-[#F2F6FA]"
                  }`}
                >
                  <span className="text-xl">{icon}</span>
                  <span className="ml-3">{label}</span>
                </Link>
              )}
            </li>
          ))}
        </ul>
      </div>

      {/* Background overlay when mobile menu is open */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-white bg-opacity-50 z-40 md:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Desktop Sidebar */}
      <div className="hidden md:flex h-screen bg-[#074572] text-[#F2F6FA] shadow-lg flex-col w-64 transition-all duration-300">
        <div className="p-6 border-b border-[#0a5a80] text-2xl font-bold tracking-wide">Admin Panel</div>
        <ul className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          {navItems.map(({ label, icon, path }) => (
            <li key={path}>
              {label === "Service Configuration" ? (
                <>
                  <div className="flex justify-between items-center">
                    <Link
                      to={path}
                      className={`flex items-center p-3 rounded-lg w-full transition-all duration-200 ${
                        isActive(path)
                          ? "bg-[#0b6d95] text-white shadow"
                          : "hover:bg-[#0c81b2] hover:text-white text-[#F2F6FA]"
                      }`}
                    >
                      <span className="text-xl">{icon}</span>
                      <span className="ml-3">{label}</span>
                    </Link>
                    <button onClick={() => setIsSubmenuOpen(!isSubmenuOpen)} className="ml-2">
                      {isSubmenuOpen ? <FaChevronUp /> : <FaChevronDown />}
                    </button>
                  </div>
                  {isSubmenuOpen && (
                    <ul className="ml-6 mt-1 space-y-1 text-sm">
                      <li>
                        <Link
                          to="/service-configuration/add"
                          className="block px-3 py-2 rounded bg-[#F2F6FA] text-[#074572]"
                        >
                          Add
                        </Link>
                      </li>
                      <li>
                        <Link
                          to="/service-configuration/update"
                          className="block px-3 py-2 rounded bg-[#F2F6FA] text-[#074572]"
                        >
                          Update
                        </Link>
                      </li>

                    </ul>
                  )}
                </>
              ) : (
                <Link
                  to={path}
                  className={`flex items-center p-3 rounded-lg transition-all duration-200 ${
                    isActive(path)
                      ? "bg-[#0b6d95] text-white shadow"
                      : "hover:bg-[#0c81b2] hover:text-white text-[#F2F6FA]"
                  }`}
                >
                  <span className="text-xl">{icon}</span>
                  <span className="ml-3">{label}</span>
                </Link>
              )}
            </li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default Sidenav;
