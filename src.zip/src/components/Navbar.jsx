import { useState } from "react";
import { Link } from "react-router-dom";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaHandsHelping,
  FaShieldAlt,
  FaKey
} from "react-icons/fa";

export default function Navbar() 
{
  const [menuOpen, setMenuOpen] = useState(false);
  
  return (
    <>
		{/*Nav Bar for desktop device*/}
		<div className="hidden sm:block fixed top-0 left-0 w-full z-50 bg-gradient-to-br from-[#074572] via-[#074572] to-[#8CAAC3] text-[#F2F6FA] shadow-lg">
					
			<div className="bg-[#074572] bg-gradient-to-br from-[#074572] via-[#074572] to-[#8CAAC3] text-[#F2F6FA] shadow-lg text-white px-4 sm:h-14 h-10 shadow-lg flex items-center justify-between w-full">
						
				<div className="flex items-center justify-center ">
													
					<div className="hidden sm:flex gap-1 items-center whitespace-nowrap">
						<img
							src="/logo.png"
							alt="Logo"
							className="h-12 w-12 rounded-full object-cover ml-10"
						/>

						<Link to="/" className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md transition-transform duration-200 hover:-translate-y-1">
							<FaHome sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Home
						</Link>
						
						<Link to="/About" className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md transition-transform duration-200 hover:-translate-y-1">
							<FaHeart sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Our Services
						</Link>
						
						<Link to="/Values" className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md transition-transform duration-200 hover:-translate-y-1">
						    <FaHandsHelping sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Our Role
						</Link>
						
						<Link to="/Services" className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md transition-transform duration-200 hover:-translate-y-1">
						    <FaShieldAlt sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Why Us?
						</Link>
						
						<Link to="/Contact" className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md transition-transform duration-200 hover:-translate-y-1">
						  <FaPhoneAlt sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Contact Us
						</Link>	
					</div>
				</div>
						
				{/* Right Section: Login Button */}
<div className="relative group w-fit">
  <Link
    to="/Login"
    className="relative z-10 flex items-center gap-2 bg-white text-[#074572] font-bold text-sm px-6 py-2 rounded-full shadow-md hover:bg-[#D7E7F2] transition-all duration-200"
  >
    🌸 Send Esaal-e-Sawab
  </Link>

  <svg
    className="absolute inset-0 w-full h-full pointer-events-none"
    viewBox="0 0 100 40"
    preserveAspectRatio="none"
  >
    <rect
      x="1"
      y="1"
      width="98"
      height="38"
      rx="20"
      ry="20"
      fill="none"
      stroke="#074572"
      strokeWidth="2"
      strokeDasharray="250"
      strokeDashoffset="0"
    >
      <animate
        attributeName="stroke-dashoffset"
        values="250;0;250"
        dur="3s"
        repeatCount="indefinite"
      />
    </rect>
  </svg>
</div>


			</div>
		</div>
		{/*Nav Bar for desktop device Ends*/}
		
		{/* Mobile Navbar starts */}
		{!menuOpen && (
			<div className="sm:hidden bg-[#074572] shadow-md w-full h-12  fixed top-0 z-50 flex items-center  px-0">
				<div className="flex items-center justify-between w-full px-2">
					<FaBars className="text-4xl text-[#F2F6FA] cursor-pointer" 
						onClick={() => setMenuOpen(true)}/>
		<div >

			<Link
			to="/Login"
			className="flex items-center gap-2 bg-white text-[#074572] font-bold text-sm px-4 py-1  shadow-md hover:bg-[#D7E7F2] transition-all duration-200 rounded-full mr-[10px]"
			>
				🌸 Send Esaal-e-Sawab
			</Link>

		</div>

		</div>
			</div> 
		)}
		
		{/* Dropdown Menu */}
		{menuOpen && (
			<div className="sm:hidden bg-[#074572] text-[#074572] shadow-lg px-4 fixed top-0 w-full h-screen z-50 flex flex-col gap-4 pt-4">
    
				{/* Close Button */}
				<div className="flex justify-between pr-2 mb-4">
					<img
							src="/logo.png"
							alt="Logo"
							className="h-12 w-12 rounded-full object-cover ml-10"
					/>
					<FaTimes 
						className="text-3xl text-[#F2F6FA] cursor-pointer hover:scale-110 transition-transform duration-200"
						onClick={() => setMenuOpen(false)}
					/>
				</div>

				{/* Navigation Links */}
				<Link to="/" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md hover:-translate-y-1 transition-transform duration-200">
					<FaHome size={20} /> Home
				</Link>
    
				<Link to="/About" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md hover:-translate-y-1 transition-transform duration-200">
					<FaHeart size={20} /> Our Services
				</Link>

				<Link to="/Values" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md hover:-translate-y-1 transition-transform duration-200">
					<FaHandsHelping size={20} /> Our Role
				</Link> 

				<Link to="/Services" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md hover:-translate-y-1 transition-transform duration-200">
					<FaShieldAlt size={20} /> Why Us?
				</Link>

				<Link to="/Contact" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md hover:-translate-y-1 transition-transform duration-200">
					<FaPhoneAlt size={20} /> Contact Us
				</Link>

				<Link to="/Login" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md hover:-translate-y-1 transition-transform duration-200">
					 🌸 Send Esaal-e-Sawab
				</Link>
			</div>
		)}
		{/* Mobile Navbar ends */}
    </>
  );
}