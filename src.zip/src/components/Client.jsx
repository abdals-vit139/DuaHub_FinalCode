import { Carousel } from "react-responsive-carousel";
import s1 from "../assets/s1.jpeg";
import s2 from "../assets/s2.jpg";
import React, { useState, useEffect,useRef } from 'react';
import { useNavigate} from 'react-router-dom';
import quran_icon from "../assets/Quran_icon.png"
import dua_hands from "../assets/dua_hands.png"
import bgImage from "../assets/bg-image.jpg";
import greyBg from "/bg-image_grey.jpg";
import axios from "axios";
import {
  FaSearch,
  FaShoppingCart,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaTrashAlt,
  FaArchive ,
  FaUser,
  FaHandsHelping,
  FaHeart,
  FaHistory, 
  FaTasks, 
  FaSignOutAlt, 
} from 'react-icons/fa';
import Home from "../components/Home.jsx";
import Client_navbar from "../components/Client_navbar.jsx";
import logo from '../assets/logo.png';
import ProductCard from '../components/ProductCard';
import AstagfirTayllah from '../assets/AstagfirTayllah.jpeg';
import DuroodSharif from '../assets/DuroodSharif.jpeg';
import KalmaTayyab from '../assets/KalmaTayyab.jpeg';
import SureYasseen from '../assets/SureYasseen.jpeg';
import s3 from '../assets/s3.jpg';
import Upevent from '../assets/upcoming-event.jpg';
import Payment from "./Payment.jsx";
import sandook from "../assets/sandook.png";
import sandook_w from "../assets/sandook_white.png";
import { baseURL } from "./baseURL";
import PersonalDetailsForm from "./PersonalDetailsForm.jsx";
import { Link } from "react-router-dom";
const Client = () => {
	
	const [menuOpen, setMenuOpen] = useState(false);
	const username = localStorage.getItem("loggedInUsername");
	const [cartItems, setCartItems] = useState(() =>
	{
		if (!username) return [];
		const saved = localStorage.getItem(`cartItems_${username}`);
		return saved ? JSON.parse(saved) : [];
	});
	
	// Save cart to localStorage every time cartItems changes
	useEffect(() => 
	{
		if (username) 
		{
		localStorage.setItem(`cartItems_${username}`, JSON.stringify(cartItems));
		}
	}, [cartItems, username]);
	
	//console.log(cartItems);
	const UserId = localStorage.getItem("loginIdentifier");
	const [error, setError] = useState("");
	const [isCartModalOpen, setIsCartModalOpen] = useState(false);
	const [isCartModalComplete, setIsCartModalComplete] = useState(false);
	const [servc, setServc] = useState([]);
	const [user, getUser] = useState([]);
	const [quantity, setQuantity] = useState(0);
	const increaseQuantity = () => setQuantity(prev => prev + 1);
	const decreaseQuantity = () => setQuantity(prev => Math.max(1, prev - 1));
	const navigate = useNavigate();
	const [showFlowerAlert, setShowFlowerAlert] = useState(false);
	const [animateFlower, setAnimateFlower] = useState(false);
	const [count, setCount] = useState(0); // 0 means "not added yet"
	const [counts, setCounts] = useState({});
	const buttonRef =(null);
	const [flowerPos, setFlowerPos] = useState({ top: 0, left: 0 });
	const isLoggedIn = localStorage.getItem("loggedIn"); // Returns "true" (as a string)
	const [userId, setUserId] = useState(null);
	const [userdata,setUserData] =useState('');
	const totalQuantity = cartItems.reduce((sum, item) => sum + item.quantity, 0);
	const totalPrice = cartItems.reduce(
		(sum, item) => sum + (item.price || 0) * item.quantity,
		0
	);

	// Retrieve user ID from localStorage on component mount
	useEffect(() => 
	{
		const storedUserId = localStorage.getItem("loginIdentifier");
		const isLoggedIn 	 = localStorage.getItem("loggedIn");
		if (storedUserId) 
		{
			setUserId(storedUserId);
			axios.post(`${baseURL}/api/GetUser`, { email: storedUserId })
			.then((res) => 
			{
				console.log("User data:", res.data);
				setUserData(res.data[0]); // or set whatever part of response you need
			})
        .catch((err) => {
			console.error("Error fetching user:", err);
			//setError("Failed to fetch user data");
        });
    }
	}, []);
	
	useEffect(() => 
	{
		const fetchData = async () => {
		try 
		{
			const res = await axios.post(`${baseURL}/api/Getservices/`, { email: UserId });
			setServc(res.data); // ✅ res.data is already your response JSON
		} catch (error) 
		{
			console.error("Error fetching services:", error);
		}
	};

	fetchData();
	}, []);

	useEffect(() => 
	{
		const fetchData = async () => {
		const res = await fetch(`${baseURL}/api/GetUser`);
		const data = await res.json();
		getUser(data);
	};
	fetchData();
	}, [userId]);  

	const handleAddToCart = (item, quantity,price,currency) => 
	{
		setCartItems((prev) => 
		{
			const existing = prev.find((cartItem) => cartItem.heading === item.heading);
			if (existing) 
			{
				if (quantity === 0) 
				{
					// Remove item from cart if quantity becomes 0
					return prev.filter((cartItem) => cartItem.heading !== item.heading);
				} 
				else 
				{
					// Update quantity
					return prev.map((cartItem) =>
					cartItem.heading === item.heading
					? { ...cartItem, quantity,price,currency }
					: cartItem
					);
				}
			}
			// Add new item with quantity if > 0
			if (quantity > 0) 
			{
				return [...prev, { ...item, quantity,price,currency }];
			}
			return prev;
		});
	setShowFlowerAlert(true);
	};

	const [formDetails, setFormData] = useState({
		deceased_name: "",
		relation: "",
		date_of_death: "",
		esaal_date: "",
		schedule: "Once",
		});

	const handleChange = (e) => 
	{
		const { name, value } = e.target;
		const nameRegex = /^[A-Za-z\s]*$/;
  
		if (name === "deceased_name" || name === "relation") 
		{
			if (!nameRegex.test(value)) 
			{
				setError("Only letters and spaces are allowed in name fields");
			} 
			else 
			{
				setError(""); // Clear error if valid
			}
		}
		else
		{
			setError(""); // Clear error if valid
		}
		setFormData((prev) => ({ ...prev, [name]: value }));
	};

	const handleSubmit = async (e) => 
	{
		e.preventDefault();
		const userEmail = localStorage.getItem("loginIdentifier"); // or whatever key you stored it as
		
		if (!formDetails.relation) 
		{
			alert("Please select a relation before submitting.");
			return;
		}
		if (!formDetails.relation || !formDetails.deceased_name || !formDetails.date_of_death || !formDetails.esaal_date || !formDetails.schedule) 
		{
			alert("Please select a all required details before submitting.");
			return;
		}
		if (!userEmail) 
		{
			alert("User email not found. Please log in again.");
			return;
		}
		const today = new Date();
		const selectedDate = new Date(formDetails.date_of_death);

		if (selectedDate > today) 
		{
			alert("Date of death cannot be in the future.");
			return;
		}
		today.setHours(0, 0, 0, 0); // remove time part for accurate comparison
		const selectedDate_esaal = new Date(formDetails.esaal_date);

		if (selectedDate_esaal <= today) 
		{
			alert("Esaal-e-Sawab date must be in the future");
			return;
		}
		
		try 
		{

				navigate("/payment", {
				state: {
					cartItems,
					totalQuantity,
					totalPrice,
					formDetails 
					},
					});

		} catch (error) 
		{
			console.error("Error:", error);
		}
	}; 
	return (
	<>

	{/*{isLoggedIn && ( */}
    <div>
	
	{showFlowerAlert && (
		<div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 flex flex-col items-center">
			<div className="relative w-60 h-20 overflow-hidden mt-2">
				{[...Array(15)].map((_, i) => (
					<span
						key={i}
						className="absolute animate-float-up text-pink-400 text-xl"
						style={{
						left: `${Math.random() * 100}%`,
						animationDuration: `${1 + Math.random() * 4.5}s`,
						}}
					>
						🌸
					</span>
				))}
			</div>
		</div>
	)}
	
	{/* Navbar */}
	<div className="hidden sm:flex bg-[#074572] text-white flex flex-wrap md:flex-nowrap items-center justify-between px-4 py-0.5 sm:py-3 text-sm gap-4 relative z-10">
		{/* Hamburger + Logo */}
		<div className="flex items-center space-x-4">
			<button
				onClick={() => setMenuOpen(true)}
				className="text-[#F2F6FA] text-2xl focus:outline-none"
			>
				<FaBars />
			</button>
         
            <img
              src={logo}
              alt="duahub Logo"
              className="h-8 w-8 sm:h-12 sm:w-12 md:h-12 md:w-12 rounded-lg object-cover flex-shrink-0"
            />

        </div>

        {/* Delivery */}
        <div className="flex items-center space-x-1 cursor-pointer font-bold">
          <FaMapMarkerAlt />
          <span>{userdata.city} </span>
        </div>

        {/* Search bar */}
        <div className="flex flex-grow max-w-6xl h-10 bg-[#F2F6FA] rounded overflow-hidden text-black mx-0 md:mx-4 w-full sm:w-auto flex-shrink-0">
          <select className="bg-[#F2F6FA] text-sm px-2 border-r border-gray-300 outline-none">
            <option>All</option>
          </select>
          <input
            type="text"
            placeholder="Search Duahub.in"
            className="flex-grow px-3 text-sm outline-none"
          />
          <button className="bg-[#F2F6FA] hover:bg-[#F2F6FA] px-4 flex items-center justify-center">
            <FaSearch className="text-black" />
          </button>
        </div>

        {/* Account */}
		<div className="flex justify-center items-center gap-1">
		<FaUser />
				<p>Welcome, {userdata.name}</p>

		</div>


        {/* Cart */}
        <div
		onClick={() => setIsCartModalOpen(true)}
		className="relative flex items-center text-sm font-bold cursor-pointer"
		>
			<div className="relative">
		
				<img src={sandook_w} className="w-8 h-8 shadow-xl rounded-lg transform hover:scale-105 hover:rotate-[2deg] transition duration-300 ease-in-out" title="Blessing Box"/>
				{cartItems.length > 0 && (
					<span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
						{cartItems.reduce((sum, item) => sum + item.quantity, 0)}
					</span>
					)}
			</div>
			{<span className="ml-1">Esaal-e-sawab Box</span> } 
		</div>

    </div>
	{/*Nav bar ends*/}

	{/* Navbar for mobile*/}
    <div className="sm:hidden bg-[#074572] fixed top-0 text-white flex flex-wrap md:flex-nowrap items-center justify-between px-4 py-0.5 sm:py-3 text-sm gap-4 relative z-10">
        
		{/* Hamburger + Logo */}
        <div className="flex items-center space-x-4 mt-1">
          <button
            onClick={() => setMenuOpen(true)}
            className="text-[#F2F6FA] text-2xl focus:outline-none"
          >
            <FaBars />
          </button>

            <img
              src={logo}
              alt="duahub Logo"
              className="h-8 w-8 sm:h-12 sm:w-12 md:h-12 md:w-12 rounded-lg object-cover flex-shrink-0 mt-1"
            />
        </div>
		
        {/* Account */}
		<div className="flex justify-right items-center gap-1 ml-15">
		<FaUser />
				<p>Welcome, {userdata.name}</p>

		</div>
		
		{/* Cart */}
        <div
			onClick={() => setIsCartModalOpen(true)}
			className="relative flex items-center text-sm font-bold cursor-pointer"
		>
			<div className="relative">
			<img src={sandook_w} className="w-6 h-6 shadow-xl rounded-lg transform hover:scale-105 hover:rotate-[2deg] transition duration-300 ease-in-out" title="Blessing Box"/>	
					{cartItems.length > 0 && (
						<span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex 	items-center justify-center rounded-full">
						{cartItems.reduce((sum, item) => sum + item.quantity, 0)}
						</span>
					)}
			</div>
			
		</div>
		
		{/* Search bar */}
        <div className="flex flex-grow max-w-6xl h-10 bg-[#F2F6FA] rounded overflow-hidden text-black mx-0 md:mx-4 w-full sm:w-auto flex-shrink-0 mb-2">
          <select className="bg-[#F2F6FA] text-sm px-2 border-r border-gray-300 outline-none">
            <option>All</option>
          </select>
          <input
            type="text"
            placeholder="Search Duahub.in"
            className="flex-grow px-3 text-sm outline-none"
          />
          <button className="bg-[#F2F6FA] hover:bg-[#F2F6FA] px-4 flex items-center justify-center">
            <FaSearch className="text-black" />
          </button>
        </div>

     </div>
	{/*Nav bar for mobile ends*/}
	
	<div className="flex justify-center gap-2 items-center mt-3 bg-[#074572] h-10">
			<p className="flex justify-center text-bold text-center sm:text-3xl text-[#F2F6FA] text-sm">Send Esaal-e-sawab to their souls with your selections 
			</p>
	</div> 
 
	{/* Sidebar menu */}
	<div className={`fixed top-0 left-0 h-full w-64 bg-[#074572] text-white p-4 z-50 transform ${
		menuOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300`}
	>
		<div className="flex justify-between items-center mb-6">
			<button
				onClick={() => setMenuOpen(false)}
				className="text-white text-xl"
			>
				<FaTimes />
			</button>
		</div>
		
		<ul className="space-y-4">
				<li className="flex items-center gap-3">
					<FaUser />
					<Link to="/Client" onClick={() => setMenuOpen(false)}>
						Home
					</Link>
				</li>
				<li className="flex items-center gap-3">
					<FaHistory />
					<Link to="/order-history" onClick={() => setMenuOpen(false)}>
						Order History
					</Link>
				</li>
				<li className="flex items-center gap-3">
					<FaTasks />
					<Link to="/manage-orders" onClick={() => setMenuOpen(false)}>
						Manage Orders
					</Link>
				</li>
		        <li className="flex items-center gap-3">
					<FaSignOutAlt />
					<Link to="/" onClick={() => setMenuOpen(false)}>
						Logout
					</Link>
				</li>
		</ul>	

	</div> 

    {/* Backdrop */}
    {menuOpen && (
        <div
          className="fixed inset-0 bg-black opacity-50 z-40"
          onClick={() => setMenuOpen(false)}
        />
		)}
		
			{/* Fetch services from DB */}
			<div className="grid grid-cols-1 sm:grid-cols-4 gap-6 mr-4">
				{
					servc.map((item, index) => 
					{
						const itemKey = item.service_heading; // or use item.id
						const count = counts[itemKey] || 0;
						return(
							<div key={index}>

								<div className="sm:w-full w-[90%] min-h-[300px] bg-white shadow-md rounded-lg overflow-hidden flex flex-col mt-5 sm:ml-2 sm:mr-2 mr-5 ml-5">
								{/*backgrnd image div starts*/}
								<div className="w-full flex justify-center items-center p-2 h-80 sm:h-100 w-50 bg-cover bg-center border border-[#074572]" style={{ backgroundImage: `url(${greyBg})` }}
								>
								
								<div className={`sm:h-80 h-65 mb-2 w-70 ${
									index % 2 === 0 ? 'bg-[#F2F6FA]' : 'bg-[#F2F6FA]'
									} border-1 border-[#F2F6FA] shadow-2xl`}>
									<img
										src="./logo.png"
										alt="Logo"
										loading="lazy"
										className="hidden sm:flex h-15 w-15 rounded-full object-cover ml-25 mt-3"
									/>
					
									<img
										src="./logo.png"
										alt="Logo"
										loading="lazy"
										className="sm:hidden h-10 w-10 rounded-full object-cover ml-30 mt-2"
									/>
									<p 
										className={`hidden sm:flex justify-center text-bold sm:text-xl text-sm font-[cursive] mt-2 
										${index % 2 === 0 ? 'text-[#074572]' : 'text-[#074572]'}`}>
											{item.service_heading || "Surah Yaseen"}
									</p>
									
									<p 
										className={`sm:hidden justify-center flex items-center text-bold  text-sm font-[cursive] mt-2 ${index % 2 === 0 ? 'text-[#074572]' : 'text-[#074572]'}`}> 
										 {item.service_heading || "Surah Mulk"}
									</p>
									
									<p 
										className={`sm:hidden justify-center flex items-center text-bold sm:text-xl text-xs font-[cursive] mt-2 ${index % 2 === 0 ? 'text-[#074572]' : 'text-[#074572]'}`}> 
										"{item.service_tagline || "The greatness of Allah and His creation"}"
									</p>
		

									<img
										src={quran_icon}
										alt="quran icon"
										loading="lazy"
										className="hidden sm:flex h-15 w-15 rounded-full object-cover ml-20 mt-3"
									/>
						
									<img
										src={quran_icon}
										alt="quran icon"
										loading="lazy"
										className="sm:hidden h-10 w-10 rounded-full object-cover ml-30 mt-1"
									/>
									<p 
									className={`sm:flex text-left sm:text-sm text-xs ml-3 ${index % 2 === 0 ? 'text-[#074572]' : 'text-[#074572]'}`}>
										{item.service_description || "The Prophet (PBUH) said gifting the reward of Surah Al-Mulk to the dead brings them ease in the grave. Its recitation reduces their suffering and helps save them from punishment."}
									</p>
								</div>
								
							</div>
							{/*backgrnd image div ends*/}
							
							{/*Button div starts*/}
							
							{/* Add to Cart Button */}
							<div className="flex justify-between items-center ref={buttonRef}">
								
								<button
									 onClick={() => handleAddToCart({
									 heading: item.service_heading,
									 tagline: item.service_tagline,
									 description: item.service_description,
									})}
									className=" text-[#F2F6FA] px-2 py-2 rounded hover:bg-[#02588F] text-sm whitespace-nowrap border border-[#F2F6FA] bg-[#074572] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96] w-40 mt-2 mb-2 ml-2"
								>
									{item.currency_code}  {(item.price * (counts[itemKey] || 1)).toFixed(2)}
										


								</button>
								
								
								{/*Replace button with controls when clicked*/}

								{(counts[itemKey] || 0) === 0 ? (
								// 🌟 Add Blessing Button
								<button
									onClick={() => 
										{
									
											setCounts((prev) => ({
											...prev,
											[itemKey]: 1,
											}));
									
										handleAddToCart(
										{
											heading: item.service_heading,
											tagline: item.service_tagline,
											description: item.service_description,
										},1,item.price,item.currency_code);

										}
									}
									className="text-[#F2F6FA] px-2 py-2 rounded hover:bg-[#02588F] text-sm whitespace-nowrap border border-[#F2F6FA] bg-[#074572] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96] w-40 mt-2 mb-2 mr-2"
									>
									<div className="flex justify-center items-center gap-1">
									<img
										src={dua_hands}
										alt="Logo"
										className="h-5 w-5 rounded-full object-cover"
									/>
									<p>Add Esaal-e-Sawab</p>
									</div>
								</button>
								) : (
								// ➕➖ Controller
								<div className="flex items-center gap-4">
									    <button
									onClick={() => {
									const newQty = Math.max(0, (counts[itemKey] || 1) - 1);
									setCounts((prev) => ({
										...prev,
										[itemKey]: newQty,
									}));
									handleAddToCart(
										{
										heading: item.service_heading,
										tagline: item.service_tagline,
										description: item.service_description,
										},
										newQty,
										item.price,
										item.currency_code
										
									);
									}} 
									className="text-[#F2F6FA] px-2 py-2 rounded hover:bg-[#02588F] text-sm whitespace-nowrap border border-[#F2F6FA] bg-[#074572] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96] w-10 mt-2 mb-2 mr-2"
								>
									–
								</button>
								
									<span>{counts[itemKey]}</span>
								
									 <button
									onClick={() => {
									const newQty = (counts[itemKey] || 0) + 1;
							setCounts((prev) => ({
							...prev,
								[itemKey]: newQty,
									}));
							handleAddToCart(
						{
						heading: item.service_heading,
							tagline: item.service_tagline,
							description: item.service_description,
						},
						newQty,
						item.price,
						item.currency_code
					);
      }}
	  className="text-[#F2F6FA] px-2 py-2 rounded hover:bg-[#02588F] text-sm whitespace-nowrap border border-[#F2F6FA] bg-[#074572] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96] w-10 mt-2 mb-2 mr-2"
    >
      +
    </button>
								</div>
							)}
							</div>
							
						{/*Button div ends*/}	
						</div>
					
					</div>

					)})}	
		</div>
		{/*Fetch services from DB ends*/}
		
		 {isCartModalComplete && (
		  <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
		  <form
      onSubmit={handleSubmit}
      className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md border border-[#074572]"
    >
      <h2 className="text-2xl font-bold text-center mb-6 text-[#074572]">
        Details for Esaal-e-Sawab
      </h2>
      <p className="text-sm text-gray-500 mb-4">
        Special characters not allowed in full name field
      </p>

      <div className="mb-4">
        <label className="block font-semibold mb-1">
          Name of Deceased <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          name="deceased_name"
          value={formDetails.deceased_name}
          onChange={handleChange}
          className="w-full border border-[#074572] rounded px-3 py-2"
        />
      </div>

      <div className="mb-4">
        <label className="block font-semibold mb-1">
          Relation with Deceased <span className="text-red-500">*</span>
        </label>
        {/*<input
          type="text"
          name="relation"
          value={formDetails.relation}
          onChange={handleChange}
          className="w-full border border-[#074572] rounded px-3 py-2"
		 /> */}
		
		 <select
          name="relation"
          value={formDetails.relation}
          onChange={handleChange}
          className="w-full border border-[#074572] rounded px-3 py-2"
        >
		  <option>Select Your Option</option>
          <option>Parents</option>
          <option>Relative</option>
          <option>Spouse</option>
          <option>Children</option>
		  <option>Guardian</option>
        </select>
      </div>

      <div className="mb-4">
        <label className="block font-semibold mb-1">
          Date of Death <span className="text-red-500">*</span>
        </label>
        <input
          type="date"
          name="date_of_death"
          value={formDetails.date_of_death}
          onChange={handleChange}
          className="w-full border border-[#074572] rounded px-3 py-2"
        />
      </div>

      <div className="mb-4">
        <label className="block font-semibold mb-1">
          Date for Esal-e-Sawab <span className="text-red-500">*</span>
        </label>
        <input
          type="date"
          name="esaal_date"
          value={formDetails.esaal_date}
          onChange={handleChange}
          className="w-full border border-[#074572] rounded px-3 py-2"
        />
      </div>

      <div className="mb-4">
        <label className="block font-semibold mb-1">
          Do you want to schedule this activity? <span className="text-red-500">*</span>
        </label>
        <select
          name="schedule"
          value={formDetails.schedule}
          onChange={handleChange}
          className="w-full border border-[#074572] rounded px-3 py-2"
        >
          <option>Once</option>
          <option>Weekly</option>
          <option>Monthly</option>
          <option>Yearly</option>
        </select>
      </div>
		{error && <p style={{ color: "red" }}>{error}</p>}
        <button

          type="submit"
          className="w-full bg-[#074572] text-[#F2F6FA] font-bold py-2 px-4 rounded hover:bg-[#D7E7F2]"
        >
          Continue with Hadiya
        </button>
      </form>
		</div>
		 )}
      {isCartModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl relative transition-all">
            {/* Close Button */}
            <button
              onClick={() => 
			  {
				  {setIsCartModalOpen(false); setIsCartModalComplete(false)}   // Optional: Sync counts to match cart quantities
				const syncedCounts = {};
				cartItems.forEach(item => {
				const key = item.heading; // or generateItemKey(item) if you use something else
				syncedCounts[key] = item.quantity;
				});
			setCounts(syncedCounts);}}
              className="absolute top-3 right-3 text-2xl text-gray-700 hover:text-red-500 transition"
              title="Close"
            >
              ✕
            </button>
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 flex items-center justify-center gap-2">
			
			
            <FaArchive className="text-[#074572]" />
                   <p className="text-[#074572]">Your Cart </p>
            </h2>

				
            {cartItems.length === 0 ? (
              <p className="text-center text-gray-500">Cart is empty.</p>
            ) : (
				<ul className="space-y-4">
                {cartItems.map((item, index) => (
                  <li
                    key={index}
                    className="flex items-center justify-between space-x-3"
                  >
                    {/* Product Heading */}
					<div className="flex items-center px-3 py-1 bg-white shadow-inner space-x-2">
					<p className="text-lg">	{item.heading}</p>
					</div>

                    {/* Quantity and Controls */}
                    <div className="flex items-center border-2 border-[#074572] rounded-full px-3 py-1 bg-white shadow-inner space-x-2">
                      {/* Trash Icon */}
                      <button
							onClick={() =>
							setCartItems((prev) =>
							prev.filter((i) => i.heading !== item.heading)
							)
							}
                        className="text-black hover:text-red-600 text-lg transition"
                        title="Remove"
                      >
                        <FaTrashAlt />
                      </button>

                      {/* Minus Button */}
                      <button
                        onClick={() =>
                          setCartItems((prev) =>
                            prev.map((i) =>
                              i.heading === item.heading
                                ? { ...i, quantity: Math.max(1, i.quantity - 1) }
                                : i
                            )
                          )
                        }
                        className="text-[#074572] hover:text-[#074572] text-lg font-bold px-2 transition"
                        title="Decrease"
                      >
                        -
                      </button>

                      {/* Quantity */}
                      <span className="font-bold text-lg">{item.quantity}</span>
					   

                      {/* Plus Button */}
                      <button
                        onClick={() =>
                          setCartItems((prev) =>
                            prev.map((i) =>
                              i.heading === item.heading
                                ? { ...i, quantity: i.quantity + 1 }
                                : i
                            )
                          )
                        }
                        className="text-[#074572] hover:text-[#074572] text-lg font-bold px-2 transition"
                        title="Increase"
                      >
                        +
                      </button>
					  
                    </div>
					
                  </li>
				  			
                ))}
              </ul>

            )}

			  {/* Buy Now Button */}
            {cartItems.length > 0 && (

				<button
                onClick={() => {setIsCartModalComplete(true);setIsCartModalOpen(false);}}
                className="mt-6 w-full bg-[#074572] hover:bg-[#8CAAC3] text-[#F2F6FA] font-bold py-3 rounded-xl transition hover:shadow-lg"
              >
                Send Esal-e-Sawab
				</button>
            )}
          </div>
        </div>
      )}
    </div>
	</>
  );
};

export default Client;