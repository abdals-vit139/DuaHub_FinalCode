import paymentlogo from "../assets/paymentlogo.png";
import "@fortawesome/fontawesome-free/css/all.min.css";
import dua from "../assets/dua.png";
import quran from "../assets/slide1.png";
import world from "../assets/world.jpg";
import path from "../assets/path.png";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import s1 from "../assets/s1.jpeg";
import s2 from "../assets/s2.jpg";
import introVideo from "../assets/introVideo.mp4";
import { Moon } from "lucide-react"; // or your preferred icon library
import slide1 from "../assets/slide1.jpg";
import slide2 from "../assets/slide2.jpg";
import slide3 from "../assets/slide3.jpg";
import slide4 from "../assets/slide4.png";
import slide5 from "../assets/slide5.png";
import slide6 from "../assets/slide6.png";
import slide7 from "../assets/slide7.png";
import slide8 from "../assets/slide8.png";
import Client from "./Client.jsx";
import { Link } from "react-router-dom";
import { useState } from "react";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaKey,
  FaLockOpen,
  FaWhatsapp ,
  FaStarAndCrescent ,
  FaQuestion 
} from "react-icons/fa";
import Navbar from "./Navbar.jsx";

export default function Contact() {
	
	const navButtonClass = `
  bg-gradient-to-br from-[#F2F6FA] via-[#F2F6FA] to-[#F2F6FA]
  text-[#074572] font-semibold sm:text-lg text-sm 
  px-6 sm:px-8 md:px-10 py-2 
  shadow-[0_4px_0_#02588F] transition-all duration-150 
  hover:brightness-110 hover:shadow-[0_2px_0_#02588F] 
  hover:scale-[0.98] active:scale-[0.96]
  whitespace-nowrap
  mr-1
`.trim();
  const [menuOpen, setMenuOpen] = useState(false);
  return (

    <section className="bg-[#074572] mt-14 pt-4 pb-0 mb-0">
	 		
		<Navbar />
      
        <h1 className="text-3xl font-bold mb-6 text-[#F2F6FA] text-center pb-0 mb-0">
          Contact Us
        </h1>

        
          {/* Subscribe + Social */}
          <div className="bg-[#fff] bg-opacity-50 rounded-md p-6 max-w-6xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-6 mb-6">
            {/* Subscribe */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left w-full lg:w-1/2 space-y-3">
              <h2 className="text-2xl font-extrabold text-[#074572] drop-shadow-md">
                Join The Impact Community
              </h2>
              <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-0">
                <input
                  type="email"
                  placeholder="Email Id"
                  className="p-2 rounded-l-md w-64 sm:w-auto text-[#074572] border border-[#074572]"
                />
                <button className="bg-[#074572] px-4 ml-3 py-2 rounded-md text-white font-semibold hover:bg-[#8CAAC3] transition">
                  Subscribe
                </button>
              </div>
            </div>

            {/* Social Icons */}
            <div className="flex flex-col items-center lg:items-end w-full lg:w-1/2 space-y-3 text-center lg:text-right">
              <h3 className="text-2xl font-bold text-[#074572] drop-shadow-md sm:mr-9">
                Follow us
              </h3>
              <div className="flex justify-center lg:justify-end space-x-4 bg-white rounded-md p-3 ">
                <a href="#" className="text-2xl text-green-600 hover:text-green-600">
                  <i className="fab fa-whatsapp"></i>
                </a>
                <a href="#" className="text-2xl text-blue-600 hover:text-blue-600">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="text-2xl text-blue-700 hover:text-blue-700">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="text-2xl text-pink-500 hover:text-pink-500">
                  <i className="fab fa-instagram"></i>
                </a>

              </div>
            </div>
          </div>

          {/* Dua Hub Info & Contact */}
          <div className="bg-[#F2F6FA] p-6 max-w-6xl mx-auto mb-3 text-sm">
            <div className="flex flex-col md:flex-row justify-between gap-6 mb-4">
              {/* Dua Hub Text */}
              <div className="md:w-2/3 text-center md:text-left mb-2">
                <h2 className="text-[#074572] font-bold text-2xl mb-3 transition-colors cursor-pointer">
                  Dua Hub
                </h2>
                <div className="text-[#074572] max-w-2xl space-y-1 text-justify">
                  <p>
                    Want to honor someone you’ve lost? <br />With our Esal-e-Sawab
                    services, you can send Quran


                    recitation and dua on behalf of your loved ones —
                    from anywhere in the world.


                    <br />Each act is carried out with care, sincerity & Islamic
                    principles. <br />Get in touch today to begin.
                  </p>
                </div>
              </div>

              {/* Contact Info */}
			  
              <div className="md:w-1/3 text-[#074572] text-left md:text-left sm:ml-90 space-y-2">
				
				<div className="flex justify-start items-center gap-1">
					<FaEnvelope className="text-[#074572]"/> 
					<p>
					duahub26@gmail.com
					</p>
				</div>

              
			  </div>
            </div>

            {/* Bottom Row */}
            <div className="flex flex-col-reverse sm:flex-row justify-between items-center gap-4 border-t border-[#074572] pt-4 mt-4">
              <div className="text-[#074572] text-[10px] flex flex-wrap justify-center sm:justify-start gap-2">
                <a href="#" className="hover:underline">
                  Terms of Use
                </a>
                <span>-</span>
                <a href="#" className="hover:underline">
                  Privacy Policy
                </a>
                <span>-</span>
                <a href="#" className="hover:underline">
                  Raise a Concern
                </a>
                <span>-</span>
                <a href="#" className="hover:underline">
                  Cookie Policy
                </a>
              </div>
              <img
                src={paymentlogo}
                alt="Payment Methods"
                className="h-12 w-auto"
              />
            </div>
			<div className="text-[#074572] text-[12px] text-center">
				  © {new Date().getFullYear()} Designed & Developed by Verheffen Infotech Pvt Ltd
				</div>
          </div>

    </section>
  );
}
