import React, { useState, useEffect } from "react";
import Sidebar from "../layouts/Sidebar";
import Header from "../layouts/Header";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const COLORS = [
  "#0088FE",
  "#00C49F",
  "#FFBB28",
  "#FF8042",
  "#8884D8",
  "#82CA9D",
];

const Dashboard = () => {
  // Sample data - typically fetched from an API
  const [payments, setPayments] = useState([
    {
      id: 1,
      amount: 150,
      date: new Date(2023, 5, 15),
      client: {
        id: 1,
        name: "Client A",
        country: "USA",
        state: "California",
        city: "Los Angeles",
      },
    },
    {
      id: 2,
      amount: 200,
      date: new Date(2023, 5, 16),
      client: {
        id: 2,
        name: "Client B",
        country: "USA",
        state: "New York",
        city: "New York",
      },
    },
    {
      id: 3,
      amount: 75,
      date: new Date(2023, 5, 17),
      client: {
        id: 3,
        name: "Client C",
        country: "Canada",
        state: "Ontario",
        city: "Toronto",
      },
    },
    {
      id: 4,
      amount: 300,
      date: new Date(2023, 5, 18),
      client: {
        id: 4,
        name: "Client D",
        country: "UK",
        state: "England",
        city: "London",
      },
    },
    {
      id: 5,
      amount: 125,
      date: new Date(2023, 5, 19),
      client: {
        id: 5,
        name: "Client E",
        country: "USA",
        state: "California",
        city: "San Francisco",
      },
    },
    {
      id: 6,
      amount: 250,
      date: new Date(2023, 5, 20),
      client: {
        id: 6,
        name: "Client F",
        country: "Canada",
        state: "Quebec",
        city: "Montreal",
      },
    },
    {
      id: 7,
      amount: 180,
      date: new Date(),
      client: {
        id: 7,
        name: "Client G",
        country: "USA",
        state: "Texas",
        city: "Austin",
      },
    },
    {
      id: 8,
      amount: 90,
      date: new Date(),
      client: {
        id: 8,
        name: "Client H",
        country: "Germany",
        state: "Bavaria",
        city: "Munich",
      },
    },
  ]);

  // Filters and states
  const [filter, setFilter] = useState("today");
  const [customStartDate, setCustomStartDate] = useState(null);
  const [customEndDate, setCustomEndDate] = useState(null);
  const [filteredPayments, setFilteredPayments] = useState([]);
  const [countryData, setCountryData] = useState([]);
  const [stateData, setStateData] = useState([]);
  const [cityData, setCityData] = useState([]);

  // Filtered payments logic
  useEffect(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let filtered = [];

    switch (filter) {
      case "today":
        filtered = payments.filter((p) => {
          const paymentDate = new Date(p.date);
          paymentDate.setHours(0, 0, 0, 0);
          return paymentDate.getTime() === today.getTime();
        });
        break;

      case "thisWeek":
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - today.getDay());
        filtered = payments.filter((p) => {
          const paymentDate = new Date(p.date);
          return paymentDate >= startOfWeek && paymentDate <= today;
        });
        break;

      case "thisMonth":
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        filtered = payments.filter((p) => {
          const paymentDate = new Date(p.date);
          return paymentDate >= startOfMonth && paymentDate <= today;
        });
        break;

      case "custom":
        if (customStartDate && customEndDate) {
          const start = new Date(customStartDate);
          const end = new Date(customEndDate);
          end.setHours(23, 59, 59, 999);
          filtered = payments.filter((p) => {
            const paymentDate = new Date(p.date);
            return paymentDate >= start && paymentDate <= end;
          });
        }
        break;

      default:
        filtered = payments;
    }

    setFilteredPayments(filtered);
  }, [filter, payments, customStartDate, customEndDate]);

  // Analytics data generation
  useEffect(() => {
    const countryMap = {};
    const stateMap = {};
    const cityMap = {};

    payments.forEach((payment) => {
      const { country, state, city } = payment.client;
      countryMap[country] = (countryMap[country] || 0) + 1;
      const stateKey = `${country}-${state}`;
      stateMap[stateKey] = (stateMap[stateKey] || 0) + 1;
      const cityKey = `${country}-${state}-${city}`;
      cityMap[cityKey] = (cityMap[cityKey] || 0) + 1;
    });

    setCountryData(
      Object.entries(countryMap).map(([name, value]) => ({ name, value }))
    );

    setStateData(
      Object.entries(stateMap).map(([key, value]) => {
        const [country, state] = key.split("-");
        return { country, state, value };
      })
    );

    setCityData(
      Object.entries(cityMap).map(([key, value]) => {
        const [country, state, city] = key.split("-");
        return { country, state, city, value };
      })
    );
  }, [payments]);

  // Totals
  const totalAmount = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalClients = new Set(filteredPayments.map((p) => p.client.id)).size;

  return (
    <div className="admin-panel">
      <Header />
      <div className="flex">
        <Sidebar />
        <div className="dashboard p-4 w-full">
          <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold mb-5 text-[#074572] w-full max-w-lg mx-auto">
  <span className="flex-grow border-t border-[#074572] mr-4"></span>
  Dashboard
  <span className="flex-grow border-t border-[#074572] ml-4"></span>
</h1>
          {/* Filter Section */}
<div className="filter-section mb-6">
  <div className="flex flex-wrap items-center justify-between gap-4">
    
    {/* Heading */}
    <h2 className="text-xl font-semibold text-[#074572] whitespace-nowrap">
      Payment Analytics :
    </h2>

    {/* Filter Buttons */}
    <div className="flex gap-2 mr-3">
      {["today", "thisWeek", "thisMonth", "custom"].map((f) => (
        <button
          key={f}
          className={`px-3 py-1 border rounded ${
            filter === f
              ? f === "today"
                ? "bg-[#074572] text-white"
                : "bg-[#074572] text-white"
              : "bg-gray-200"
          }`}
          onClick={() => setFilter(f)}
        >
          {f === "today"
            ? "Today"
            : f === "thisWeek"
            ? "This Week"
            : f === "thisMonth"
            ? "This Month"
            : "Custom Range"}
        </button>
      ))}
    </div>

    {/* Stat Cards */}
    <div className="flex gap-4">
      <div className="stat-card bg-gray-100 p-3 rounded shadow">
        <h3 className="font-medium">Total Payments</h3>
        <p>{filteredPayments.length}</p>
      </div>
      <div className="stat-card bg-gray-100 p-3 rounded shadow">
        <h3 className="font-medium">Total Amount</h3>
        <p>${totalAmount.toFixed(2)}</p>
      </div>
      <div className="stat-card bg-gray-100 p-3 rounded shadow">
        <h3 className="font-medium">Unique Clients</h3>
        <p>{totalClients}</p>
      </div>
    </div>
  </div>

  {/* Custom Date Picker shown only if 'custom' is selected */}
  {filter === "custom" && (
    <div className="flex gap-2 mt-4">
      <DatePicker
        selected={customStartDate}
        onChange={(date) => setCustomStartDate(date)}
        placeholderText="Start Date"
        selectsStart
        startDate={customStartDate}
        endDate={customEndDate}
      />
      <DatePicker
        selected={customEndDate}
        onChange={(date) => setCustomEndDate(date)}
        placeholderText="End Date"
        selectsEnd
        startDate={customStartDate}
        endDate={customEndDate}
        minDate={customStartDate}
      />
    </div>
  )}
</div>

          {/* Charts Section */}
          <div className="analytics-section">
            <h2 className="text-xl font-semibold mb-2 text-[#074572]">Client Distribution</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Country Pie Chart */}
              <div className="chart bg-white p-4 rounded shadow">
                <h3 className="font-medium mb-2">By Country</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={countryData}
                      dataKey="value"
                      nameKey="name"
                      outerRadius={100}
                      label={({ name, percent }) =>
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {countryData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={COLORS[index % COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* State Bar Chart */}
              <div className="chart bg-white p-4 rounded shadow">
                <h3 className="font-medium mb-2">Top States</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={stateData.slice(0, 10)}
                    margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="state"
                      angle={-45}
                      textAnchor="end"
                      height={60}
                    />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" name="Clients" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
