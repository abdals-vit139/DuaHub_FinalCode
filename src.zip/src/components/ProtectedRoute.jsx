// ProtectedRoute.js
import React from 'react';
import { useNavigate, Navigate, Outlet } from 'react-router-dom';
import { useEffect, useState } from 'react';

/*const ProtectedRoute = ({ children }) => 
{
  const loggedIn = localStorage.getItem("loggedIn") === "true";
  return loggedIn ? children : <Navigate to="/Login" replace />;
}; */
const ProtectedRoute = ({ children, role = "user" }) => {
  const isUserLoggedIn = localStorage.getItem("userLoggedIn") === "true";
  const isAdminLoggedIn = localStorage.getItem("adminLoggedIn") === "true";

  const isAuthorized = role === "admin" ? isAdminLoggedIn : isUserLoggedIn;

  return isAuthorized ? children : <Navigate to="/Login" replace />;
};

export default ProtectedRoute;