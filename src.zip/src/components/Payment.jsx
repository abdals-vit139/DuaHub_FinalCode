import React, { useState , useEffect } from 'react';
import { ShoppingCart } from 'lucide-react';
import logo from '../assets/logo.png';
import visa from '../assets/visa.png';
import mastercard from '../assets/mastercard.png';
import americanExpress from '../assets/americanExpress.png';
import rupay from '../assets/rupay.png';
import { Link , useNavigate, useLocation} from "react-router-dom";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaCrown,
  FaBlog 
} from "react-icons/fa";
import Contact from "./Contact.jsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import axios from "axios";
import { baseURL } from "./baseURL";



function CheckoutNavbar() {
  return (
    <nav className="bg-[#02588F] border-b border-gray-200 shadow-sm px-6 py-3 flex items-center justify-between">
      <div className="flex items-center">
        <img src={logo} alt="Duahub" className="h-12 w-12 rounded-sm" />
      </div>
      <div className="text-2xl font-bold  text-white">Secure checkout</div>
      <div className="relative">
       
		<Link to="/Client" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg">
			<FaHome sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Home
		</Link>
      </div>
    </nav>
  );
}

export default function Payment() 
{
  
	const [userId, setUserId] = useState(null);
	const [userdata,setUserData] =useState('');	
	const storedUserId = localStorage.getItem("loginIdentifier");
	const isLoggedIn 	 = localStorage.getItem("loggedIn");

	useEffect(() => 
	{
    const storedUserId = localStorage.getItem("loginIdentifier");
    if (storedUserId) 
	{
		setUserId(storedUserId);
	    axios.post(`${baseURL}/api/GetUser`, { email: storedUserId })
        .then((res) => 
		{
			setUserData(res.data[0]); // or set whatever part of response you need
        })
        .catch((err) => {
          console.error("Error fetching user:", err);
        });
    }
	}, []);
	const [form, setForm] = useState({ fullName: '', email: '', mobile: '', cardNumber: '', expiry: '', cvv: '' });
	const [selectedMethod, setSelectedMethod] = useState('card');
	const [selectedBank, setSelectedBank] = useState('');
	const [showCardModal, setShowCardModal] = useState(false);
	const [upiId, setUpiId] = useState('');
	const [upiStatus, setUpiStatus] = useState('');
	const [isEditingAddress, setIsEditingAddress] = useState(false);
	const [address, setAddress] = useState(userdata.address);
	const [billID,setBillId]= useState('');
	
	const fetchBillID = async () => 
	{
		try {
		const res = await axios.get(`${baseURL}/maxBillID`);
			console.log(res.data[0]);
			if (res.data) 
			{
				setBillId(res.data[0]);
			} 
      
		} catch (err) {
		console.error(err);
		}
	};

	useEffect(() => 
	{
		fetchBillID();
	}, []);
  
	const billId = billID.BillID;
	
	//Function to generate Bill
	const generatePDF = (cartItems, selectedMethod) => 
	{
		const doc = new jsPDF();
		doc.setFontSize(18);
		doc.text("Duahub Invoice", 105, 20, null, null, 'center');

		const rightMargin = 195;
	
		doc.setFontSize(10);
		//doc.text(`${userdata.name}`, rightMargin, 14, { align: "right" });
		doc.text(`Invoice Number: ${billId}`, rightMargin, 14, { align: "right" });
		doc.text(`Invoice Date: ${new Date().toLocaleDateString()}`, rightMargin, 20, { align: "right" });
		doc.text("www.duahub.in", rightMargin, 26, { align: "right" });

		doc.setLineWidth(0.5);
		doc.line(14, 34, 195, 34);

		doc.setFontSize(12);
		doc.text("Billed To:", 14, 42);
		doc.setFontSize(10);
		doc.text(`${userdata.name}`, 14, 48);
		//doc.text("Pune 411041", 14, 53);
		doc.text( `${userdata.address}`, 14, 53);
 
		doc.text(`${userdata.phone}`, 14, 58);

		const tableColumn = ["#", "Product", "Quantity"];

		const tableRows = cartItems.map((item, index) => 
		[
			index + 1,
			item.heading
			? item.heading
			: item.name || "Unnamed Product",
			item.quantity,
		]);
		console.log(tableRows);	
		autoTable(doc, 
		{
			startY: 65,
			head: [tableColumn],
			body: tableRows,
			styles: { fontSize: 10 },
			headStyles: { fillColor: [2, 88, 143] },
		});

		const totalItems = cartItems.reduce((sum, i) => sum + i.quantity, 0);
		const totalPriceState = cartItems.reduce((sum, i) => sum + (i.quantity * i.price), 0);
		doc.setFontSize(12);
		const totalItemsY = doc.lastAutoTable.finalY + 10;
		doc.text(`Total Items: ${totalItems}`, 14, totalItemsY);
		doc.text(`Total Amount: ${totalPriceState}`, 14, totalItemsY+8);
		// Payment method line just below Total Items
		doc.text(`Payment Method: ${selectedMethod}`, 14, totalItemsY + 16);

		const footerY = doc.lastAutoTable.finalY + 40;

		doc.setFontSize(10);
		doc.setTextColor(60);
		doc.setFont("helvetica", "italic");

  
		const thankYouMessage = [
			"Thank you for choosing and trusting DuaHub.",
			"We are deeply honored to be a part of your spiritual journey.",
			"Your faith in us means more than words can express,",
			"and we are committed to serving you with sincerity, care, and devotion.",
			"May your duas be accepted and your loved ones be blessed.",
			"",
			"With gratitude and prayers,",
			"The DuaHub Team"
		];

		thankYouMessage.forEach((line, i) => 
		{
			doc.text(line, 14, footerY + i * 6);
		});

		// doc.save("Duahub_Invoice.pdf");
		doc.save("Duahub_Invoice.pdf");
		return doc.output("blob"); // Optional if you still need to attach or preview
	};
	
	const handleChange = (e) => 
	{
		setForm({ ...form, [e.target.name]: e.target.value });
	};

	const handleSubmit = (e) => 
	{
		e.preventDefault();
    // alert('Payment submitted successfully!');
	};

	const handleVerifyUpi = () => 
	{
		if (upiId.trim().length > 5 && upiId.includes('@')) 
		{
			setUpiStatus('valid');
		} 
		else 
		{
			setUpiStatus('invalid');
		}
	};

	const location = useLocation();
	const { cartItems = [], totalQuantity, totalPrice,formDetails } = location.state || {};
	console.log(cartItems);
	const [cartItemsState, setCartItems] = useState(cartItems || []);
	const uniqueCurrencies = [...new Set(cartItemsState.map(item => item.currency))];
	console.log(uniqueCurrencies); // ["INR", "USD"]
	const [totalPriceState, setTotalPrice] = useState(totalPrice || 0);
	console.log(totalPriceState);
	const [totalQuantityState, setTotalQuantity] = useState(totalQuantity || 0);

	const navigate = useNavigate(); // ✅ this must be inside the component

	const handlePhonePePayment = async () => 
	{
		try 
		{
			const response = await fetch('http://localhost:7000/api/initiate-phonepe-payment', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
			amount: 1000, // Amount in paisa. 1000 = ₹10.00
			userId: 'USER123',
		}),
		});
			const data = await response.json();

			if (data.success && data.redirectUrl) 
			{
				window.location.href = data.redirectUrl;
			} 
			else 
			{
			alert('Failed to initiate PhonePe payment.');
			}
		} catch (error) 
		{
			console.error('PhonePe Payment Error:', error);
			alert('Something went wrong while processing the payment.');
		}
	};

	const handlePayment = async () => 
	{
		const pdfBlob = generatePDF(cartItems, selectedMethod);
		const formData = new FormData();
		formData.append("pdf", pdfBlob, "Duahub_Invoice.pdf");
		//today change 16-6-25
		const username = localStorage.getItem("loggedInUsername");
		console.log(JSON.stringify(formDetails));
		formData.append("username", username);
		formData.append("paymentMethod", selectedMethod);
		formData.append("totalItems", cartItems.reduce((sum, i) => sum + i.quantity, 0));
		formData.append("Quantity", cartItems.reduce((sum, i) => sum + i.quantity, 0));
		formData.append("totalPrice", totalPrice);
		formData.append("items", JSON.stringify(cartItems));
		formData.append("Esaal_details", JSON.stringify(formDetails));
		try 
		{
			await axios.post(`${baseURL}/api/save-bill`, formData, {
			headers: {
			'Content-Type': 'multipart/form-data'
				}
		});
	// ✅ Show alert on success
    alert("Bill saved successfully and PDF uploaded.");
	// ✅ Clear cart in both state and localStorage
	//today change 16-6-25
    setCartItems([]);
    localStorage.removeItem(`cartItems_${username}`);
    //localStorage.removeItem(`cartItems_${username}`);
    //setCartItems([]);
    setSelectedMethod('');
    setTotalPrice(0);
    setTotalQuantity(0);
	navigate("/Client");
    

  } catch (err) {
    console.error('Error saving bill:', err);
    alert('Payment succeeded, but bill was not saved.');
  }
};

  return (
    <div className="min-h-screen bg-blue-50">
      <CheckoutNavbar />
      <div className="p-6 flex flex-col ">
        <div className="w-full flex flex-col lg:flex-row gap-6">
          <div className="flex-[2]">
            <div className="bg-white rounded-lg shadow p-6 mb-4">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="font-bold text-lg">Delivering to {userdata.name}</h2>
                  <p className="text-sm text-gray-700 mt-1">{userdata.address}</p>
                </div>
                
              </div>
             
            </div>
<div className="bg-white shadow-xl rounded-2xl p-6">
  <h2 className="text-xl font-bold mb-4">Choose Payment Method</h2>

  {/* Credit/Debit Card Option */}
  <label className="flex items-center mb-2">
    <input
      type="radio"
      name="payment"
      value="card"
      checked={selectedMethod === 'card'}
      onChange={(e) => setSelectedMethod(e.target.value)}
      className="mr-2"
    />
    Credit or debit card
  </label>

  {/* Card section now always visible */}
  <div
    className={`ml-6 mt-2 border p-4 rounded ${
      selectedMethod === 'card'
        ? 'bg-yellow-50 border-yellow-300'
        : 'bg-gray-50 border-gray-200'
    }`}
  >
    <div className="flex flex-wrap items-center gap-3 mb-4">
      <img src={visa} alt="Visa" className="h-8" />
      <img src={mastercard} alt="maestro" className="h-8" />
      <img src={americanExpress} alt="amex" className="h-8" />
      <img src={rupay} alt="rupay" className="h-11 ml-2" />
    </div>

    <div
      className="flex items-center gap-2 mt-4 cursor-pointer"
      onClick={() => setShowCardModal(true)}
    >
      <div className="h-10 w-10 bg-gray-200 flex items-center justify-center rounded">
        <span className="text-xl font-bold">+</span>
      </div>
      <span className="text-blue-600 font-medium hover:underline">
        Add a new credit or debit card
      </span>
    </div>
    <p className="text-sm text-gray-600 mt-1">Duahub accepts all major credit & debit cards</p>
  </div>

  {/* Netbanking Option */}
  <label className="flex items-center mt-4 mb-2">
    <input
      type="radio"
      name="payment"
      value="netbanking"
      checked={selectedMethod === 'netbanking'}
      onChange={(e) => setSelectedMethod(e.target.value)}
      className="mr-2"
    />
    Net Banking
  </label>

  {selectedMethod === 'netbanking' && (
    <div className="ml-6 mb-2">
      <select
        className="border p-2 rounded w-full"
        value={selectedBank}
        onChange={(e) => setSelectedBank(e.target.value)}
      >
        <option value="">Choose a Bank</option>
        <option>SBI</option>
        <option>ICICI</option>
        <option>HDFC</option>
        <option>Axis Bank</option>
        <option>Kotak</option>
        <option>Punjab National Bank</option>
        <option>Yes Bank</option>
        <option>Bank of Baroda</option>
        <option>Canara Bank</option>
        <option>Union Bank</option>
      </select>
    </div>
  )}

  {/* UPI Option */}
  <label className="flex items-center mb-2">
    <input
      type="radio"
      name="payment"
      value="upi"
      checked={selectedMethod === 'upi'}
      onChange={(e) => setSelectedMethod(e.target.value)}
      className="mr-2"
    />
    Other UPI Apps
  </label>

  {selectedMethod === 'upi' && (
    <div className="ml-6 mt-2 bg-yellow-50 border border-yellow-200 p-4 rounded">
      <label htmlFor="upiId" className="block mb-2 font-medium">
        Please enter your UPI ID
      </label>
      <div className="flex items-center gap-2">
        <input
          type="text"
          id="upiId"
          name="upiId"
          value={upiId}
          onChange={(e) => setUpiId(e.target.value)}
          placeholder="Enter UPI ID"
          className="border rounded p-2 flex-1"
        />
        <button
          className="bg-yellow-100 text-gray-800 px-4 py-1  border border-yellow-300 hover:bg-yellow-200"
          onClick={handleVerifyUpi}
        >
          Verify
        </button>
      </div>

      {upiStatus === 'valid' && (
        <p className="text-green-600 text-sm mt-1">Valid UPI ID</p>
      )}
      {upiStatus === 'invalid' && (
        <p className="text-red-600 text-sm mt-1">Invalid UPI ID</p>
      )}
      <p className="text-sm text-gray-600 mt-1">
        The UPI ID is in the format of name/phone number@bankname
      </p>

      
    </div>
    
  )}

  {/* phonepay */}
  <label className="flex items-center mb-2">
  <input
    type="radio"
    name="payment"
    value="phonepe"
    checked={selectedMethod === 'phonepe'}
    onChange={(e) => setSelectedMethod(e.target.value)}
    className="mr-2"
  />
  Pay using PhonePe UPI
</label>

{selectedMethod === 'phonepe' && (
  <div className="ml-6 mt-2 bg-purple-50 border border-purple-200 p-4 rounded">
    <p className="mb-2 text-sm text-gray-700">
      You’ll be redirected to complete the payment via PhonePe.
    </p>
    <button
      className="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700"
      onClick={handlePhonePePayment}
    >
      Proceed to Pay with PhonePe
    </button>
  </div>
)}


  {/* <button
    className="mt-6 w-60 bg-yellow-400 hover:bg-yellow-500 text-black font-semibold py-2 rounded-2xl"
    onClick={handleSubmit}
  >
    Use this payment method
  </button>
</div> */}
<button
  onClick={handlePayment}
  className="bg-[#02588F] text-white py-2 px-4 rounded hover:bg-[#014f7f]"
>
  Use this payment method
</button>
</div>

          </div>


          
<div className="w-full h-auto lg:w-1/3 bg-yellow-50 border border-yellow-300 shadow p-6 rounded-2xl sticky top-20">
  <h2 className="text-lg font-bold mb-4 text-center">Order Summary</h2>

  
<div className="space-y-2">
  <div className="flex justify-between font-bold text-gray-700">
    <span className="flex-1">Items</span>
    <span className="w-20 text-center">Quantity</span>
    <span className="w-20 text-right">Price</span>
  </div>
  <hr />

  <div>
    {cartItems.length === 0 ? (
      <p className="text-center text-gray-500">Cart is empty.</p>
    ) : (
      <ul className="space-y-1">
        {cartItems.map((item, index) => (
          <li key={index} className="flex justify-between text-gray-700">
            <span className="flex-1">{item.heading}</span>
            <span className="w-20 text-center">{item.quantity}</span>
            <span className="w-20 text-right">{item.currency}{item.quantity*item.price}</span>
          </li>
        ))}
      </ul>
    )}
  </div>

  <div className="flex justify-between font-semibold border-t pt-2 mt-2">
    <span className="font-bold">Order Total:</span>
<span className="text-lg text-black">{uniqueCurrencies[0]}{totalPriceState}</span>
  </div>
  
</div>


  
</div>
</div>
      </div>

      {showCardModal && (
        <>
          <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white w-full max-w-md p-6 rounded shadow-lg relative">
              <button onClick={() => setShowCardModal(false)} className="absolute top-2 right-2 text-gray-500 hover:text-black">✕</button>
              <h2 className="text-lg font-semibold mb-4">Add a new credit or debit card</h2>
              <div className="mb-4">
                <label className="block font-medium mb-1">Card number</label>
                <input type="text" className="w-full border p-2 rounded" placeholder="XXXX XXXX XXXX XXXX" />
              </div>
              <div className="mb-4">
                <label className="block font-medium mb-1">Nickname</label>
                <input type="text" className="w-full border p-2 rounded" defaultValue=" " />
              </div>
              <div className="mb-4 flex gap-2">
                <div>
                  <label className="block font-medium mb-1">Expiry date</label>
                  <div className="flex gap-2">
                    <select className="border p-2 rounded">
                      {Array.from({ length: 12 }, (_, i) => (<option key={i + 1}>{String(i + 1).padStart(2, '0')}</option>))}
                    </select>
                    <select className="border p-2 rounded">
                      {Array.from({ length: 16 }, (_, i) => (<option key={i}>{2025 + i}</option>))}
                    </select>
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <button onClick={() => setShowCardModal(false)} className="px-4 py-2 border rounded hover:bg-gray-100">Cancel</button>
                <button className="px-4 py-2 bg-yellow-400 text-black font-semibold rounded hover:bg-yellow-500">Continue</button>
              </div>
            </div>
          </div>
        </>
      )}
 

      <div className="mt-10">
        {/* Back to Top */}
        <div
          className="text-center py-4 bg-[#121212] text-white cursor-pointer"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
        </div>

        {/* Logo and Help Section */}
        <div className="bg-[#2C3E50] text-white py-6 flex justify-center items-center space-x-6">
          <img
            src={logo}
            alt="DuaHub Logo"
            className="h-10 rounded-md"
          />
          <Link to="/Contact" className="text-sm hover:underline">Help</Link>
        </div>


        {/* Footer Bottom Links */}
        <div className="bg-[#02588F] text-white text-center py-4 text-xs">
          <div className="space-x-4 mb-1">
            <a href="#" className="hover:underline">Terms & Conditions</a>
          </div>

		  <div>© {new Date().getFullYear()} Designed & Developed by Verheffen Infotech</div>
        </div>
        
      </div>


    </div>
    
  );
}