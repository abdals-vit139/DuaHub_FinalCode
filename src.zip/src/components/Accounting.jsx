import React, { useState, useEffect } from "react";
import Header from "../layouts/Header";
import Sidebar from "../layouts/Sidebar";
import * as XLSX from "xlsx";
import axios from "axios";
import {
FaDownload 
} from 'react-icons/fa';
import { baseURL } from "./baseURL";


const Accounting = () => {
  const [billingData, setBillingData] = useState([]);
  const [filters, setFilters] = useState({
    client_name: "",
    email: "",
    mobile: "",
    city: "",
    state: "",
    country: "",
    billing_date: "",
  });
  const [periodFilter, setPeriodFilter] = useState("");
  const [customDates, setCustomDates] = useState({ start: "", end: "" });
  const [tempCustomDates, setTempCustomDates] = useState({ start: "", end: "" });
		//function to format date
	const formatDate = (dateString) => 
	{
		const date = new Date(dateString);
		const year = date.getFullYear();
		const month = String(date.getMonth() + 1).padStart(2, '0'); // months are zero-indexed
		const day = String(date.getDate()).padStart(2, '0');
		return `${year}-${month}-${day}`;
	};
	
  useEffect(() => {
    axios
      .get(`${baseURL}/api/billing`)
      .then((res) => setBillingData(res.data))
      .catch((err) => console.error("Failed to fetch billing data:", err));
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handlePeriodChange = (e) => {
    setPeriodFilter(e.target.value);
  };

  const isDateInRange = (dateStr, startStr, endStr) => {
    const date = new Date(dateStr);
    const start = new Date(startStr);
    const end = new Date(endStr);
    return date >= start && date <= end;
  };

  const filteredByPeriod = (data) => {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();

    if (periodFilter === "this_month") {
      return data.filter((item) => {
        const date = new Date(item.billing_date);
        return date.getFullYear() === year && date.getMonth() === month;
      });
    } else if (periodFilter === "last_month") {
      return data.filter((item) => {
        const date = new Date(item.billing_date);
        return (
          date.getFullYear() === (month === 0 ? year - 1 : year) &&
          date.getMonth() === (month === 0 ? 11 : month - 1)
        );
      });
    } else if (periodFilter === "next_month") {
      return data.filter((item) => {
        const date = new Date(item.billing_date);
        return (
          date.getFullYear() === (month === 11 ? year + 1 : year) &&
          date.getMonth() === (month === 11 ? 0 : month + 1)
        );
      });
    } else if (periodFilter === "custom" && customDates.start && customDates.end) {
      return data.filter((item) =>
        isDateInRange(item.billing_date, customDates.start, customDates.end)
      );
    }
    return data;
  };

  const getUniqueValues = (key) => {
    const unique = [...new Set(billingData.map((item) => item[key]))];
    return unique.sort();
  };

  const filteredData = filteredByPeriod(
    billingData.filter((item) =>
      Object.entries(filters).every(([key, val]) =>
        val === "" ? true : item[key]?.toLowerCase().includes(val.toLowerCase())
      )
    )
  );

  const billingTotal = filteredData.reduce(
    (acc, curr) => acc + parseFloat(curr.billing_total || 0),
    0
  ).toFixed(2);

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(filteredData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "BillingData");
    XLSX.writeFile(wb, "AccountingDetails.xlsx");
  };

  const exportSingleBill = (row) => {
    const ws = XLSX.utils.json_to_sheet([row]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Bill");
    const fileName = `${row.client_name.replace(/\s+/g, "_")}_Bill.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  const clearFilters = () => {
    setFilters({
      client_name: "",
      email: "",
      mobile: "",
      city: "",
      state: "",
      country: "",
      billing_date: "",
    });
    setPeriodFilter("");
    setCustomDates({ start: "", end: "" });
    setTempCustomDates({ start: "", end: "" });
  };


    const handleDownload = (id) => 
	{
		console.log(" in handle download func")
		console.log(id)
		window.location.href = `${baseURL}/bill_download/${id}`;
	};

  return (
    <div>
      <Header />
      <div className="flex flex-col md:flex-row min-h-screen">
        <Sidebar />
        <div className="p-6 w-full" style={{ backgroundColor: "#F2F6FA" }}>
          <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold mb-4 text-[#074572] w-full max-w-lg mx-auto">
            <span className="flex-grow border-t border-[#074572] mr-4"></span>
            Accounting
            <span className="flex-grow border-t border-[#074572] ml-4"></span>
          </h1>

          <div className="mb-4 flex flex-col md:flex-row md:items-center gap-4">
            <label htmlFor="periodFilter" className="font-semibold">
              Select Period:
            </label>
            <select
              id="periodFilter"
              value={periodFilter}
              onChange={handlePeriodChange}
              className="p-2 border rounded w-full md:w-auto"
            >
              <option value="">All</option>
              <option value="this_month">This Month</option>
              <option value="last_month">Last Month</option>
              <option value="next_month">Next Month</option>
              <option value="custom">Custom</option>
            </select>

            {periodFilter === "custom" && (
              <div className="flex flex-col md:flex-row md:items-center gap-2 w-full md:w-auto">
                <input
                  type="date"
                  value={tempCustomDates.start}
                  onChange={(e) =>
                    setTempCustomDates((prev) => ({ ...prev, start: e.target.value }))
                  }
                  className="p-2 border rounded w-full md:w-auto"
                />
                <input
                  type="date"
                  value={tempCustomDates.end}
                  onChange={(e) =>
                    setTempCustomDates((prev) => ({ ...prev, end: e.target.value }))
                  }
                  className="p-2 border rounded w-full md:w-auto"
                />
                <button
                  onClick={() => setCustomDates({ ...tempCustomDates })}
                  className="bg-[#074572] text-white px-3 py-2 rounded hover:bg-green-800"
                >
                  Apply
                </button>
              </div>
            )}

            <button
              onClick={clearFilters}
              className="bg-[#074572] text-white px-3 py-2 rounded hover:bg-[#053957]"
            >
              Clear Filters
            </button>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4 flex-wrap">
            <div className="bg-gray-300 p-4 rounded-md font-bold text-black">
              Billing Total ₹{billingTotal}
            </div>
            <button
              onClick={exportToExcel}
              className="bg-[#074572] hover:bg-blue-800 text-white px-4 py-2 rounded flex items-center gap-2"
              title="Download All"
            >
              Export to Excel
            </button>
          </div>

          <div className="overflow-x-auto rounded-md border border-gray-300 shadow-md">
          <table className="min-w-[700px] w-full text-sm text-left text-gray-700">
  <thead className="bg-[#fff] border-gray-300">
    <tr>
      {[
        "C.Name",
        "Email",
        "Mobile",
        "City",
        "State",
        "Country",
        "Bill Date",
        "Bill Total",
        "Req. Status",
        "Bill",
      ].map((heading, index) => {
        const keys = [
          "client_name",
          "email",
          "mobile",
          "city",
          "state",
          "country",
          "billing_date",
          "billing_total",
          "request_status",
          "", // No filter for the download column
        ];
        const key = keys[index];

        return (
          <th
            key={heading}
            className="px-2 md:px-4 py-3 text-[#074572] font-semibold align-top whitespace-nowrap"
          >
            <div>{heading}</div>
            {key && (
              <select
                name={key}
                value={filters[key]}
                onChange={handleFilterChange}
                className="mt-1 p-1 mr-10 border rounded w-full"
              >
                <option value="">All</option>
                {getUniqueValues(key).map((val) => (
                  <option key={val} value={val}>
                    {val}
                  </option>
                ))}
              </select>
            )}
          </th>
        );
      })}
    </tr>
  </thead>
  <tbody>
    {filteredData.length === 0 ? (
      <tr>
        <td colSpan={10} className="text-center py-4">
          No records found.
        </td>
      </tr>
    ) : (
      filteredData.map((row, i) => (
        <tr
          key={i}
          className={`border-b ${
            i % 2 === 0 ? "bg-white" : "bg-gray-50"
          }`}
        >
          <td className="pl-6">{row.client_name}</td>
          <td className="pl-4">{row.email}</td>
          <td className="pl-4">{row.mobile}</td>
          <td className="pl-4">{row.city}</td>
          <td className="pl-3">{row.state}</td>
          <td className="pl-6">{row.country}</td>
          <td className="pl-6">{formatDate(row.billing_date)}</td>
          <td className="pl-4">₹{row.billing_total}</td>
          <td className="pl-5">{row.request_status}</td>
          <td>
            <button className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md" title="Download Receipt" onClick={() => handleDownload(row.bill_no)}>
			<FaDownload style={{ color: "#074572" }} />
			</button>
          </td>
        </tr>
      ))
    )}
  </tbody>
</table>

          </div>
        </div>
      </div>
    </div>
  );
};

export default Accounting;

