import { BookOpen, HeartHandshake, Globe, ShieldCheck } from "lucide-react";
import paymentlogo from "../assets/paymentlogo.png";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import parents from "../assets/parents.png";
import Quran_1 from "../assets/Quran_1.jpg";
import Tasbeeh from "../assets/Tasbeeh.png";
import Quran from "../assets/quran.jpg";
import LadyPraying from "../assets/LadyPraying.png";
import { Link } from "react-router-dom";
import { useState } from "react";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock,
  FaArrowRight ,
  FaHandPointer, 
  FaKey  
} from "react-icons/fa";
import Navbar from "./Navbar.jsx";

export default function About() {
	const cards = [
  {
    img: LadyPraying,
    title: "Send Esaal-e-Sawab",
    text: "A quick way to send Esal-e-Sawab to your parents.",
  },
  {
    img: Quran,
    title: "Choose Good Deeds",
    text: "Select charity , Quran recitation or more for their Jannah.",
  },
  {
    img: Tasbeeh,
    title: "Track Your Blessing",
    text: "See the Impact of your duas on their spiritual journey.",
  },
  {
    img: parents,
    title: "Stay Connected Always",
    text: "Feel closer to your parents, no matter the distance.",
  },
];
const [menuOpen, setMenuOpen] = useState(false);
	
  return (
	
	<>
	<section className="mt-12 mb-1 pt-4  shadow-md">
	
		<Navbar />
		<h1 className="text-4xl font-bold  text-[#034D83] text-center">
				Our Services - Bless Your Parents
		</h1>

		{/* Wrapper with horizontal scroll for mobile, grid for larger screens */}
		<div className=" block flex overflow-x-auto snap-x snap-mandatory sm:grid sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6 px-4 sm:px-0">
			{cards.map((card, idx) => (
				<div
					key={idx}
					className="relative flex-shrink-0 w-75 sm:w-full snap-start"
				>
					{/* Shadow Layer */}
					<div className="absolute inset-x-0 bottom-1 h-2 bg-[#074572] rounded-b-md z-0 transform scale-x-95 blur-sm " />

					{/* Card */}	
					<div className="mb-5 mt-5 relative bg-[#F2F6FA] rounded-md shadow-xl p-4 z-10 transform transition-transform duration-300 hover:shadow-2xl flex flex-col items-center justify-between min-h-[300px]  ml-2 mr-2 ">  


					{/* Diagonally Clipped Image */}
					<div
						className="h-60 w-full overflow-hidden border border-[#D7E7F2] border-3 border-[#074572]"
						style={{
						clipPath: 'polygon(0 0, 100% 0, 100% 80%, 0% 100%)'
						}}
					>
						<img
							src={card.img}
							alt={card.title}
							className="h-full w-full object-cover"
							
						/>
					</div>

					{/* Text Content */}
					<div className="text-center bg-[#D7E7F2] text-[#074572] w-full">
						<p className="text-sm ml-2 font-medium break-words  mt-5 font-[cursive]">
							<strong className="text-[#074572] block mb-1 text-lg">
								{card.title}
							</strong>
							<p className="text-sm ml-2 break-words text-center mt-5">	{card.text}</p>
						</p>

						<div className="flex justify-center">
							<Link
								className="relative mt-5 mb-6 border border-[#F2F6FA] bg-gradient-to-br from-[#034D83] via-[#034D83] to-[#F2F6FA] text-[#F2F6FA] font-semibold py-1 px-4 flex justify-center items-center gap-2 shadow-[0_2px_0_#D7E7F2] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96] animate-border-move"

								 to="/Login"
							>
								🌸 Send Esaal-e-Sawab
    
							</Link>
						</div>

					</div>

				</div>
			</div>
    )
	)}
  </div>
  <hr className="w-full border-t border-[#D7E7F2]" />
</section>

</>
  );
  
}

