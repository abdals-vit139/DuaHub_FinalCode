
// import React, { useState, useEffect } from "react";
// import Sidebar from "../layouts/Sidebar";
// import Header from "../layouts/Header";
// import axios from "axios";

// const Affiliates = () => {
//   const [image, setImage] = useState(null);
//   const [preview, setPreview] = useState(null);
//   const [name, setName] = useState("");
//   const [location, setLocation] = useState("");
//   const [description, setDescription] = useState("");
//    const [successMessage, setSuccessMessage] = useState("");


//   useEffect(() => {
//     if (!image) {
//       setPreview(null);
//       return;
//     }

//     const objectUrl = URL.createObjectURL(image);
//     setPreview(objectUrl);

//     return () => URL.revokeObjectURL(objectUrl);
//   }, [image]);

//   const handleImageChange = (e) => {
//     if (e.target.files[0]) {
//       setImage(e.target.files[0]);
//     }
//   };

//    const handleSubmit = async (e) => {
//     e.preventDefault();

//     const formData = new FormData();
//     formData.append("image", image);
//     formData.append("name", name);
//     formData.append("location", location);
//     formData.append("description", description);

//     try {
//       const res = await axios.post("http://localhost:7000/api/affiliates", formData, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });
//  alert("Affiliate added successfully!"); // <--- temporary alert to verify
//     console.log("Response received:", res.data);
//       // Set success message
//       setSuccessMessage("Affiliate added successfully!");

//       // Reset form
//       setImage(null);
//       setName("");
//       setLocation("");
//       setDescription("");

//       // Clear preview
//       setPreview(null);

//       // Remove message after 3 seconds
//       setTimeout(() => setSuccessMessage(""), 3000);
//     } catch (error) {
//       console.error("Error saving affiliate:", error);
//       alert("Failed to add affiliate");
//     }
//   };
//   return (
//     <div>
//       <Header />
//       <div className="flex">
//         <Sidebar />
//         <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md border border-gray-200">
//           <h2 className="text-2xl font-semibold text-gray-800 mb-4">Add New Affiliate</h2>
//           {/* Success Message */}
//           {successMessage && (
//             <div className="mb-4 p-3 bg-green-100 text-green-800 rounded-lg border border-green-300">
//               {successMessage}
//             </div>
//           )}
//           <form onSubmit={handleSubmit} className="space-y-4">
//             {/* Name */}
//             <div className="flex flex-col gap-2">
//               <label className="text-gray-700 font-medium">Affiliate Name</label>
//               <input
//                 type="text"
//                 value={name}
//                 onChange={(e) => setName(e.target.value)}
//                 required
//                 placeholder="Enter affiliate name"
//                 className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
//               />
//             </div>

//             {/* Location */}
//             <div className="flex flex-col gap-2">
//               <label className="text-gray-700 font-medium">Location</label>
//               <input
//                 type="text"
//                 value={location}
//                 onChange={(e) => setLocation(e.target.value)}
//                 required
//                 placeholder="Enter location"
//                 className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
//               />
//             </div>

//             {/* Image Upload */}
//             <div className="flex flex-col gap-2">
//               <label className="text-gray-700 font-medium">Affiliate Image</label>
//               <input
//                 type="file"
//                 accept="image/*"
//                 onChange={handleImageChange}
//                 required
//                 className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
//               />
//               {preview && (
//                 <div className="mt-2">
//                   <img
//                     src={preview}
//                     alt="Preview"
//                     className="h-24 w-24 object-cover rounded-md shadow"
//                   />
//                 </div>
//               )}
//             </div>

//             {/* Description */}
//             <div className="flex flex-col gap-2">
//               <label className="text-gray-700 font-medium">Description</label>
//               <textarea
//                 value={description}
//                 onChange={(e) => setDescription(e.target.value)}
//                 required
//                 placeholder="Describe the affiliate"
//                 rows={4}
//                 className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
//               ></textarea>
//             </div>

//             {/* Submit Button */}
//             <button
//               type="submit"
//               className="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition duration-200"
//             >
//               Save Affiliate
//             </button>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Affiliates;


// import React, { useState, useEffect } from "react";
// import Sidebar from "../layouts/Sidebar";
// import Header from "../layouts/Header";
// import axios from "axios";

// const Affiliates = () => {
//   const [image, setImage] = useState(null);
//   const [preview, setPreview] = useState(null);
//   const [name, setName] = useState("");
//   const [location, setLocation] = useState("");
//   const [description, setDescription] = useState("");
//   const [successMessage, setSuccessMessage] = useState("");

//   useEffect(() => {
//     if (!image) {
//       setPreview(null);
//       return;
//     }
//     const objectUrl = URL.createObjectURL(image);
//     setPreview(objectUrl);
//     return () => URL.revokeObjectURL(objectUrl);
//   }, [image]);

//   const handleImageChange = (e) => {
//     if (e.target.files[0]) {
//       setImage(e.target.files[0]);
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const formData = new FormData();
//     formData.append("image", image);
//     formData.append("name", name);
//     formData.append("location", location);
//     formData.append("description", description);

//     try {
//       const res = await axios.post("http://localhost:7000/api/affiliates", formData, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });
//       alert("Affiliate added successfully!");
//       setSuccessMessage("Affiliate added successfully!");
//       setImage(null);
//       setName("");
//       setLocation("");
//       setDescription("");
//       setPreview(null);
//       setTimeout(() => setSuccessMessage(""), 3000);
//     } catch (error) {
//       console.error("Error saving affiliate:", error);
//       alert("Failed to add affiliate");
//     }
//   };

//   return (
//     <div className="min-h-screen bg-[#F2F6FA] text-black">
//       <Header />
//       <div className="flex">
//         <Sidebar />
//         <div className="max-w-md mx-auto mt-10 p-8 bg-white rounded-xl shadow-lg border border-gray-200 w-full">
//           <h2 className="text-3xl font-bold mb-6 text-center text-[#074572]">
//             Add New Affiliate
//           </h2>

//           {successMessage && (
//             <div className="mb-4 p-3 bg-green-100 text-green-800 rounded-lg border border-green-300">
//               {successMessage}
//             </div>
//           )}

//           <form onSubmit={handleSubmit} className="space-y-5">
//             {/* Name */}
//             <div className="flex flex-col">
//               <label className="text-sm font-semibold">Affiliate Name</label>
//               <input
//                 type="text"
//                 value={name}
//                 onChange={(e) => setName(e.target.value)}
//                 required
//                 placeholder="Enter affiliate name"
//                 className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black bg-white"
//               />
//             </div>

//             {/* Location */}
//             <div className="flex flex-col">
//               <label className="text-sm font-semibold">Location</label>
//               <input
//                 type="text"
//                 value={location}
//                 onChange={(e) => setLocation(e.target.value)}
//                 required
//                 placeholder="Enter location"
//                 className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black bg-white"
//               />
//             </div>

//             {/* Image Upload */}
//             <div className="flex flex-col">
//               <label className="text-sm font-semibold">Affiliate Image</label>
//               <input
//                 type="file"
//                 accept="image/*"
//                 onChange={handleImageChange}
//                 required
//                 className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black bg-white"
//               />
//               {preview && (
//                 <img
//                   src={preview}
//                   alt="Preview"
//                   className="mt-3 h-24 w-24 object-cover rounded-md border border-gray-300 shadow-sm"
//                 />
//               )}
//             </div>

//             {/* Description */}
//             <div className="flex flex-col">
//               <label className="text-sm font-semibold">Description</label>
//               <textarea
//                 value={description}
//                 onChange={(e) => setDescription(e.target.value)}
//                 required
//                 placeholder="Describe the affiliate"
//                 rows={4}
//                 className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black bg-white"
//               ></textarea>
//             </div>

//             {/* Submit Button */}
//             <button
//               type="submit"
//               className="w-full bg-[#074572] text-white py-2 rounded-md font-semibold hover:bg-[#063a5a] transition duration-300"
//             >
//               Save Affiliate
//             </button>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Affiliates;


import React, { useState, useEffect } from "react";
import Sidebar from "../layouts/Sidebar";
import Header from "../layouts/Header";
import axios from "axios";

const Affiliates = () => {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    if (!image) {
      setPreview(null);
      return;
    }
    const objectUrl = URL.createObjectURL(image);
    setPreview(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [image]);

  const handleImageChange = (e) => {
    if (e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("image", image);
    formData.append("name", name);
    formData.append("location", location);
    formData.append("description", description);

    try {
      const res = await axios.post("http://localhost:7000/api/affiliates", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("Affiliate added successfully!");
      setSuccessMessage("Affiliate added successfully!");
      setImage(null);
      setName("");
      setLocation("");
      setDescription("");
      setPreview(null);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Error saving affiliate:", error);
      alert("Failed to add affiliate");
    }
  };

//   return (
//     <div className="min-h-screen bg-[#F2F6FA] text-black">
//       <Header />
//       <div className="flex flex-col lg:flex-row">
//         <Sidebar />


//          <div className="w-full flex justify-center px-4 sm:px-6 lg:px-8 py-10">
//           <div className="w-full max-w-lg bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200">
//             <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-left text-[#074572]">
//               Add New Affiliate
//             </h2>

//             {successMessage && (
//               <div className="mb-4 p-3 bg-green-100 text-green-800 rounded-lg border border-green-300 text-sm sm:text-base">
//                 {successMessage}
//               </div>
//             )}

//             <form onSubmit={handleSubmit} className="space-y-5">
//               {/* Name */}
//               <div className="flex flex-col">
//                 <label className="text-gray-700 font-semibold">Affiliate Name</label>
//                 <input
//                   type="text"
//                   value={name}
//                   onChange={(e) => setName(e.target.value)}
//                   required
//                   placeholder="Enter affiliate name"
//                   className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
//                 />
//               </div>

//               {/* Location */}
//               <div className="flex flex-col">
//                 <label className="text-gray-700 font-semibold">Location</label>
//                 <input
//                   type="text"
//                   value={location}
//                   onChange={(e) => setLocation(e.target.value)}
//                   required
//                   placeholder="Enter location"
//                   className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
//                 />
//               </div>

//               {/* Image Upload */}
//               <div className="flex flex-col">
//                 <label className="text-gray-700 font-semibold">Affiliate Image</label>
//                 <input
//                   type="file"
//                   accept="image/*"
//                   onChange={handleImageChange}
//                   required
//                   className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
//                 />
//                 {preview && (
//                   <img
//                     src={preview}
//                     alt="Preview"
//                     className="mt-3 h-24 w-24 object-cover rounded-md border border-gray-300 shadow-sm"
//                   />
//                 )}
//               </div>

//               {/* Description */}
//               <div className="flex flex-col">
//                 <label className="text-gray-700 font-semibold">Description</label>
//                 <textarea
//                   value={description}
//                   onChange={(e) => setDescription(e.target.value)}
//                   required
//                   placeholder="Describe the affiliate"
//                   rows={4}
//                   className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
//                 ></textarea>
//               </div>

//               {/* Submit Button */}
//               <button
//                 type="submit"
//                 className="w-full bg-[#074572] text-white py-2 rounded-md font-semibold hover:bg-[#063a5a] transition duration-300"
//               >
//                 Save Affiliate
//               </button>
//             </form>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };
return (
  <div className="min-h-screen bg-[#F2F6FA] text-black">
    <Header />
    <div className="flex flex-col lg:flex-row">
      <Sidebar />

      <div className="w-full flex flex-col items-center px-4 sm:px-6 lg:px-8 pt-0">
  <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold text-[#074572] w-full max-w-lg mx-auto mt-4 mb-5">
    <span className="flex-grow border-t border-[#074572] mr-4"></span>
    Affilates
    <span className="flex-grow border-t border-[#074572] ml-4"></span>
  </h1>


        {/* White card form */}
        <div className="w-full max-w-2xl bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200">

          {/* Subheading inside card */}
          <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-left text-[#074572]">
            Add New Affiliate
          </h2>

          {successMessage && (
            <div className="mb-4 p-3 bg-green-100 text-green-800 rounded-lg border border-green-300 text-sm sm:text-base">
              {successMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Name */}
            <div className="flex flex-col">
              <label className="text-gray-700 font-semibold">Affiliate Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                placeholder="Enter affiliate name"
                className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
              />
            </div>

            {/* Location */}
            <div className="flex flex-col">
              <label className="text-gray-700 font-semibold">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                placeholder="Enter location"
                className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
              />
            </div>

            {/* Image Upload */}
            <div className="flex flex-col">
              <label className="text-gray-700 font-semibold">Affiliate Image</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                required
                className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
              />
              {preview && (
                <img
                  src={preview}
                  alt="Preview"
                  className="mt-3 h-24 w-24 object-cover rounded-md border border-gray-300 shadow-sm"
                />
              )}
            </div>

            {/* Description */}
            <div className="flex flex-col">
              <label className="text-gray-700 font-semibold">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                placeholder="Describe the affiliate"
                rows={4}
                className="mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572] bg-white"
              ></textarea>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-[#074572] text-white py-2 rounded-md font-semibold hover:bg-[#063a5a] transition duration-300"
            >
              Save Affiliate
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
);
}

export default Affiliates;
