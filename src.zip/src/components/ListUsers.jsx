import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Header from '../layouts/Header';
import Sidebar from '../layouts/Sidebar';
import { baseURL } from "./baseURL";

const ListUsers = () => {
  const [data, setData] = useState([]);
  const [expandedRow, setExpandedRow] = useState(null);

  useEffect(() => {
    axios.get(`${baseURL}/api/admin/ListUsers`)
      .then((res) => {
		setData(res.data)
      })
      .catch((err) => {
        console.error('Fetch error:', err);
        setData([]);
      });
  }, []);
console.log(data);
  return (
    <div>
      <Header />
      <div className="flex flex-col md:flex-row min-h-screen">
        <Sidebar />
        <div className="p-6 w-full bg-[#F2F6FA]">
          <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold mb-6 text-[#074572] w-full max-w-lg mx-auto">
            <span className="flex-grow border-t border-[#074572] mr-4"></span>
            List of Users
            <span className="flex-grow border-t border-[#074572] ml-4"></span>
          </h1>

          <div className="overflow-x-auto bg-white shadow-md rounded-lg w-full">
            <table className="min-w-[100px] w-full text-sm text-left border-collapse">
              <thead className="bg-gray-100 text-xs text-gray-700 uppercase">
                <tr>
                  <th className="px-3 py-3 ">#</th>
                  <th className="px-6 py-3">Email-id </th>
                  <th className="px-6 py-3 whitespace-wrap">Name</th>
                  <th className="px-6 py-3">Contact Number</th>
                  <th className="px-6 py-3 whitespace-wrap">Address</th>
                  <th className="px-6 py-3">City</th>
				  <th className="px-6 py-3">State</th>
				  <th className="px-6 py-3">Country</th>

                </tr>
              </thead>
              <tbody>
				  {data.length > 0 ? (
                  data.map((order, idx) => (
                  <React.Fragment key={order.key}>
				  <tr className="border-b hover:bg-gray-50">
				  <td className="px-3 py-3">{order.id}</td>
                  <td className="px-6 py-3">{order.email} </td>
                  <td className="px-6 py-3">{order.name}</td>
                  <td className="px-6 py-3">{order.phone} </td>
                  <td className="px-6 py-3">{order.address}</td>
                  <td className="px-6 py-3">{order.city}</td>
				  <td className="px-6 py-3">{order.state}</td>
				  <td className="px-6 py-3">{order.country}</td>
				  </tr>
				   </React.Fragment>
                  ))
                ) : (
                  <tr>
                    <td colSpan="10" className="text-center px-6 py-10 text-gray-500">
                      No orders found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ListUsers;
