import paymentlogo from "../assets/paymentlogo.png";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Link , useNavigate} from "react-router-dom";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaCrown,
  FaBlog,
  FaEye,
  FaEyeSlash
} from "react-icons/fa";
import s2 from "../assets/s2.jpg";
import {useState } from "react";
import axios from 'axios';
//import Client from "./Client.jsx";
import PersonalDetailsForm from "../components/PersonalDetailsForm.jsx";
import { baseURL } from "./baseURL";

export default function Login_admin() {
	
const [useEmail,setUseEmail] =useState(false);
const [email,setEmail] = useState('');
const [error, setError] = useState(null);
const [otpRequested, setOtpRequested] = useState(false);
const navigate = useNavigate();
const [otpSent, setOtpSent] = useState(false);
const [otp, setOtp] = useState('');
const [password, setPassword] = useState('');
const [passwordVisible, setPasswordVisible]=useState(false);

function handleSubmit(event) {
  event.preventDefault();

  if (!email || !password) {
    alert("Please enter both email and password");
    return;
  }
console.log("before calling API")
  axios.post(`${baseURL}/api/login`, { email, password }) // ✅ Hardcoded or from baseURL
    .then((res) => {
      console.log("Login success", res.data);
      navigate('/dashboard'); 
    })
    .catch((err) => {
      console.error("Login error", err);
      alert("Invalid email or password. Please try again.");
	  setEmail('');
	  setPassword('');
	  setPasswordVisible('');
	  
    });
}
	const togglePasswordVisibility = () =>
	{
		setPasswordVisible(!passwordVisible);
	}
	function handleVerifyOTP (e)
	{
		e.preventDefault();
		console.log('handleVerifyOTP');
		if (!otp) 
		{
			alert("Please Enter otp");
			return; // Don't proceed with the API request if validation fails
		}
		
		axios.post(`${baseURL}/login-with-otp`, { otp })
		.then((res) => 
		{
			console.log(res.data);
			navigate('/dashboard')	
		})
		.catch((err) => 
		{
			if 
			(
			err.response &&
			err.response.status === 400 &&
			err.response.data &&
			err.response.data.message === 'Invalid OTP'
			) 
				{
					alert('OTP is invalid.Please try again!!!');
					setOtp("");
				}
			setError("An error occurred while logging in.");
		}); 
	};

	return(
	<>
	
	{/*NavBar starts*/}
	<div className="hidden fixed top-0 left-0 w-full z-50 lg:flex bg-gradient-to-br from-[#074572] via-[#074572] to-[#8CAAC3] text-[#F2F6FA] px-4 sm:h-14 h-10 shadow-lg flex items-center justify-left gap-20 w-full">

		<img
			src="/logo.png"
			alt="Logo"
			className="h-12 w-12 rounded-full object-cover ml-10"
		/>
		
		<Link to="/" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg">
			<FaHome sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Home
		</Link>
		
		<Link to="/Client" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg">
			<FaCrown sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Membership Plan
		</Link>
		
		<Link to="/" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg">
			<FaBlog sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Blog
		</Link>

	</div>
	{/*NavBar ends*/}
	
	{/* Main Navbar */}
	<div className="sm:hidden bg-[#074572] fixed shadow-md w-full h-12  top-0 z-50 flex items-center  px-0">
		<div className="flex items-center justify-end w-full px-2 gap-1"> 
			<div className="bg-[#F2F6FA] flex items-center gap-1 px-4 py-1 mr-4">
			 <FaHome sm:size={25} size={20} style={{ color: "#074572" }} />  
				<Link
				to="/"
				className="flex items-center gap-2 text-[#074572] font-semibold text-lg text-[#074572] font-bold sm:text-lg"
			>
			Home
			</Link>
			</div>
						
		</div>
	</div>
	
	<div className="flex flex-col sm:flex-row justify-center items-stretch sm:mt-20 mt-15 gap-6 px-4">
	
		{/* Login Form (now on the right) */}
	
		<form className="flex-1 md:max-w-lg w-full  bg-white sm:bg-[#F2F6FA] sm:border sm:border-[#074572] p-8 rounded-lg shadow-lg space-y-6 " >
				
			<div className="flex justify-center mb-4 style={{ perspective: '1000px' }}">
				<img
					src="/logo.png"
					alt="Logo"
					className="h-30 w-30 rounded-full object-cover" 
					style={{
					animation: 'flip-horizontal 20s infinite linear',
					transformStyle: 'preserve-3d',
					boxShadow: '0 0 20px rgba(0, 0, 0, 0.2), 0 0 40px rgba(0, 0, 0, 0.1)',
					border: '4px solid #074572',
					}}
				/>
			</div>
			
			<h1 className="text-2xl font-bold text-center text-[#074572]">Login</h1>

					<div className="space-y-2">
  {/* Email input with matching layout */}
  <div className="flex items-center gap-2">
    <input
      type="email"
      value={email}
      onChange={(e) => setEmail(e.target.value)}
      placeholder="Email"
      className="w-full px-4 py-2 border border-[#074572] rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572]"
    />
    
    {/* Invisible spacer to match the eye button */}
    <div className="p-2 opacity-0 border border-transparent rounded-md">X</div>
  </div>

  {/* Password input with eye button */}
  <div className="flex items-center gap-2">
    <input
      type={passwordVisible ? "text" : "password"}
      value={password}
      onChange={(e) => setPassword(e.target.value)}
      placeholder="Password"
      className="w-full px-4 py-2 border border-[#074572] rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572]"
    />

    <button
      type="button"
      onClick={togglePasswordVisibility}
      className="p-2 rounded-md border border-[#074572] text-[#074572] hover:bg-[#074572] hover:text-white transition"
      aria-label={passwordVisible ? "Hide Password" : "Show Password"}
    >
      {passwordVisible ? <FaEyeSlash size={18} /> : <FaEye size={18} />}
    </button>
  </div>
</div>

				{/* Submit */}
				<button
						onClick={otpSent ? handleVerifyOTP : handleSubmit}
						className="w-full bg-gradient-to-br from-[#074572] via-[#074572] to-[#8CAAC3] text-[#F2F6FA] py-2 rounded-md font-semibold hover:bg-[#fff] transition border-2 border-[#F2F6FA]"
						> 
					{ "Submit"}
				</button>
					
	
		</form>
  
		<div className="hidden lg:flex w-[700px] relative rounded-lg overflow-hidden shadow-lg">
			<img
				src={s2}
				alt="Full Div Background"
				className="absolute inset-0 w-full h-full object-cover"
			/>
		</div>
	</div>

	{/*Contact us*/}
	<section className="bg-[#074572] mt-16 pt-4 pb-0 mb-0">
	
      <div className="mt-5">
        <h1 className="text-3xl font-bold mb-6 text-[#F2F6FA] text-center pb-0 mb-0">
          Contact Us
        </h1>
        
          {/* Subscribe + Social */}
          <div className="bg-[#fff] bg-opacity-50 rounded-md p-6 max-w-6xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-6 mb-6">
            {/* Subscribe */}
            <div className="flex flex-col items-center lg:items-start text-center lg:text-left w-full lg:w-1/2 space-y-3">
              <h2 className="text-2xl font-extrabold text-[#074572] drop-shadow-md">
                Join The Impact Community
              </h2>
              <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-0">
                <input
                  type="email"
                  placeholder="Email Id"
                  className="p-2 rounded-l-md w-64 sm:w-auto text-[#074572] border border-[#074572]"
                />
                <button className="bg-[#074572] px-4 ml-3 py-2 rounded-md text-white font-semibold hover:bg-[#8CAAC3] transition">
                  Subscribe
                </button>
              </div>
            </div>

            {/* Social Icons */}
            <div className="flex flex-col items-center lg:items-end w-full lg:w-1/2 space-y-3 text-center lg:text-right">
              <h3 className="text-2xl font-bold text-[#074572] drop-shadow-md sm:mr-9">
                Follow us
              </h3>
              <div className="flex justify-center lg:justify-end space-x-4 bg-white rounded-md p-3 ">
                <a href="#" className="text-2xl text-green-600 hover:text-green-600">
                  <i className="fab fa-whatsapp"></i>
                </a>
                <a href="#" className="text-2xl text-blue-600 hover:text-blue-600">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="text-2xl text-blue-700 hover:text-blue-700">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="text-2xl text-pink-500 hover:text-pink-500">
                  <i className="fab fa-instagram"></i>
                </a>

              </div>
            </div>
          </div>

          {/* Dua Hub Info & Contact */}
          <div className="bg-[#F2F6FA] p-6 max-w-6xl mx-auto mb-3 text-sm">
            <div className="flex flex-col md:flex-row justify-between gap-6 mb-4">
              {/* Dua Hub Text */}
              <div className="md:w-2/3 text-center md:text-left mb-2">
                <h2 className="text-[#074572] font-bold text-2xl mb-3 transition-colors cursor-pointer">
                  Dua Hub
                </h2>
                <div className="text-[#074572] max-w-2xl space-y-1 text-justify">
                  <p>
                    Want to honor someone you’ve lost? With our Esal-e-Sawab
                    services, you can send Quran


                    recitation, dua, and charity on behalf of your loved ones —
                    from anywhere in the world.


                    Each act is carried out with care, sincerity & Islamic
                    principles. Message us today to begin.
                  </p>
                </div>
              </div>

              {/* Contact Info */}
              <div className="md:w-1/3 text-[#074572] text-left md:text-left sm:ml-90 space-y-2">
				
				<div className="flex justify-start items-center gap-1">
					<FaEnvelope className="text-[#074572]"/> 
					<p>
					support@duahub.com
					</p>
				</div>
				
				<div className="flex justify-start items-center gap-1">
				<FaPhoneAlt className="text-[#074572]"/> 
                <p>
                   +91-99999 99999
                </p>
				</div>
                
				<div className="flex justify-start items-center gap-1">
				<FaMapMarkerAlt className="text-[#074572]"/> 
					<p>
						123 Islamic Street, Pune
					</p>
				</div>
              
			  </div>
            </div>

            {/* Bottom Row */}
            <div className="flex flex-col-reverse sm:flex-row justify-between items-center gap-4 border-t border-[#074572] pt-4 mt-4">
              <div className="text-[#074572] text-[10px] flex flex-wrap justify-center sm:justify-start gap-2">
                <a href="#" className="hover:underline">
                  Terms of Use
                </a>
                <span>-</span>
                <a href="#" className="hover:underline">
                  Privacy Policy
                </a>
                <span>-</span>
                <a href="#" className="hover:underline">
                  Raise a Concern
                </a>
                <span>-</span>
                <a href="#" className="hover:underline">
                  Cookie Policy
                </a>
              </div>
              <img
                src={paymentlogo}
                alt="Payment Methods"
                className="h-12 w-auto"
              />
            </div>
          </div>
        
      </div>
    </section>
</>

);
}