import paymentlogo from "../assets/paymentlogo.png";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Link, useNavigate } from "react-router-dom";
import {
  FaEnvelope, FaPhoneAlt, FaMapMarkerAlt, FaBars, FaTimes,
  FaHome, FaHeart, FaShieldAlt, FaHandsHelping, FaLock, FaCrown, FaBlog
} from "react-icons/fa";
import s2 from "../assets/s2.jpg";
import { useState, useEffect } from "react";
import axios from 'axios';
import { FaSpinner } from 'react-icons/fa';
import { baseURL } from "./baseURL";

export default function LoginPage() 
{
	//state variables
	const [useEmail, setUseEmail] = useState(false);
	const [email, setEmail] = useState('');
	const [otpRequested, setOtpRequested] = useState(false);
	const [otp, setOtp] = useState('');
	const [userExists, setUserExists] = useState(false);
	const [error, setError] = useState(null);
	const [newUserData, setNewUserData] = useState({
		name: '',
		phone: '',
		address: '',
		city: '',
		state: '',
		country: '',
		callingCode: '+'
	});
	const navigate = useNavigate();
	const [loading, setLoading] = useState(false);
	const [showPersonalDetailsModal, setShowPersonalDetailsModal] = useState(false);
	const [userData, setUserData] = useState(null); // Save server response
	const inputStyle = "w-full px-4 py-2 border border-[#074572] rounded-md focus:outline-none focus:ring-2 focus:ring-[#074572]";
	
	//Function to request OTP based on email id
	const handleSubmit = async (event) => 
	{
		event.preventDefault();
		setLoading(true); // 🔄 START
		
		//Check email address is valid/invalid
		if (useEmail && !email.includes('@')) 
		{
			setError("Please enter a valid email address.");
			setLoading(false)
			return;
		}

		// ✅ Gmail-only check
		/*if (useEmail && !email.endsWith('@gmail.com')) 
		{
			setError("Only gmail.com addresses are allowed.");
			setLoading(false); // Stop spinner
			return;
		}*/
		
		if (!useEmail && (!/^[0-9]{6,15}$/.test(email))) 
		{
			setError("Please enter a valid phone number.");
			setLoading(false)
			return;
		}

		try 
		{
			const type = useEmail ? 'email' : 'phone';
			const res = await axios.post(`${baseURL}/send-otp`,{[type]: email});
	
			if (res.data.message === 'OTP sent') 
			{
				setOtpRequested(true);
				setUserExists(res.data.userExists);
				setError(null);

				// Store login identifier
				localStorage.setItem("loginIdentifier", email);
				localStorage.setItem("loginType", type);
				localStorage.setItem("loggedIn", "true");
			} 
			else 
			{
				setError(res.data.message);
			}
		} catch (err) 
		{
			setLoading(false); // ✅ STOP
			console.error(err);
			setError("An error occurred while sending OTP.");
		}
	};
    
	//Function to validate OTP entered by user
 	const handleVerifyOtp = async (e) => 
	{
		e.preventDefault();
		const type = useEmail ? 'email' : 'phone';

		const payload = {
			[type]: email,
			otp,
		};

		if (!userExists) 
		{
			Object.assign(payload, newUserData);
			if (!useEmail) 
			{
				payload.phone = `${newUserData.callingCode}${email}`;
			}
		}

		try 
		{
			const res = await axios.post(`${baseURL}/verify-otp`, payload);
			const data = res.data;

			if (res.status === 200) 
			{
				alert(data.message);
				const uniqueUser = data?.username || email;
				localStorage.setItem("loggedInUsername", uniqueUser);

				if (data.newUser) 
				{
					// Show modal for new user
					setUserData(data); // Store data if needed in modal
					setShowPersonalDetailsModal(true);
				} 
				else 
				{
					if (data.role === 'admin') 
					{
						localStorage.setItem("adminLoggedIn", "true");
						navigate('/login_admin', { replace: true });
					} 
					else 
					{
						localStorage.setItem("userLoggedIn", "true");
						navigate('/Client', { replace: true });
					}
				}
			} 
			else 
			{
				setError(data.message || "OTP verification failed.");

			}
		} catch (err) 
		{
			console.error("OTP verification failed:", err);
			setError("OTP verification failed.");
			setOtp('');
		}
	};

	//Fetch Location based on ipaddress
	useEffect(() => {
		const fetchLocation = async () => 
		{
			try 
			{
				const ipRes = await axios.get("https://api64.ipify.org?format=json");
				const locRes = await axios.get(`https://ipapi.co/${ipRes.data.ip}/json/`);
				const { city, region, country_name, country_calling_code } = locRes.data;
				setNewUserData(prev => ({
					...prev,
					city: city || '',
					state: region || '',
					country: country_name || '',
					callingCode: country_calling_code || '+'
				}));
			} catch (error) {
				console.log('Could not auto-detect location');
			}
		};

		if (!userExists) 
		{
			fetchLocation();
		}
	}, [userExists]);
	
	const handleFieldChange = (e) => 
	{
		if (error) setError('');
	};
	
	return (
    <>
		{/* Desktop Navbar */}
		<div className="hidden fixed top-0 left-0 w-full z-50 lg:flex bg-gradient-to-br from-[#074572] via-[#074572] to-[#8CAAC3] text-[#F2F6FA] px-4 sm:h-14 h-10 shadow-lg items-center gap-20">
			<img src="/logo.png" alt="Logo" className="h-12 w-12 rounded-full ml-10" />
			<Link to="/" className="flex items-center gap-2 text-lg font-semibold"><FaHome /> Home</Link>
			<Link to="/Client" className="flex items-center gap-2 text-lg font-semibold"><FaCrown /> Membership Plan</Link>
			<Link to="/" className="flex items-center gap-2 text-lg font-semibold"><FaBlog /> Blog</Link>
		</div>
		{/* Desktop Navbar ends */}
		
		{/* Mobile Navbar */}
		<div className="sm:hidden bg-[#074572] fixed w-full h-12 top-0 z-50 flex items-center px-2">
			<div className="flex justify-end w-full gap-1">
			<div className="bg-[#F2F6FA] flex items-center gap-1 px-4 py-1">
				<FaHome style={{ color: "#074572" }} />
				<Link to="/" className="text-[#074572] font-bold text-lg">Home</Link>
			</div>
			</div>
		</div>
		{/* Mobile Navbar Ends*/}
			
		{/* Form Section */}
		<div className="flex flex-col sm:flex-row justify-center items-stretch sm:mt-20 mt-15 gap-6 px-4">
			{/* Login Form */}
			<form className="flex-1 md:max-w-lg w-full  bg-white sm:bg-[#F2F6FA] sm:border sm:border-[#074572] p-8 rounded-lg shadow-lg space-y-6"
			onSubmit={otpRequested ? handleVerifyOtp : handleSubmit}
			>
				<div className="flex justify-center mb-4 style={{ perspective: '1000px' }}">
					<img
						src="/logo.png"
						alt="Logo"
						className="h-30 w-30 rounded-full object-cover" 
						style={{
						animation: 'flip-horizontal 20s infinite linear',
						transformStyle: 'preserve-3d',
						boxShadow: '0 0 20px rgba(0, 0, 0, 0.2), 0 0 40px rgba(0, 0, 0, 0.1)',
						border: '4px solid #074572',
						}}
					/>
				</div>
				
				<h1 className="text-2xl font-bold text-center text-[#074572]">Login</h1>

				{/* Toggle */}
				<div className="flex justify-center mb-4">
					<div className="bg-[#F2F6FA] p-1 rounded-full flex space-x-1 w-fit border-[2px] border-[#074572]">
						<button type="button" onClick={() => setUseEmail(true)} className={`px-4 py-1 rounded-full ${useEmail ? 'bg-[#074572] text-white' : 'text-[#074572]'}`}>Email</button>
						<button type="button" onClick={() => setUseEmail(false)} className={`px-4 py-1 rounded-full ${!useEmail ? 'bg-[#074572] text-white' : 'text-[#074572]'}`}>Mobile</button>
					</div>
				</div>
			
				{/* Login method text */}
				<p className="text-center text-sm font-bold text-gray-600 mb-2">
					{useEmail ? 'Login via Email' : 'Login via Mobile[Only for India users]'}
				</p>
	
				{!otpRequested ? (
				<div>
				<label className="block text-[#FF6347] font-medium mb-1 flex justify-center">
					{useEmail ? '' : ''}
				</label>
				<input
					type={useEmail ? 'email' : 'tel'}
					placeholder={useEmail ? 'you@gmail.com' : '1234567890'}
					value={email}
					onChange={(e) => 
								{
									setEmail(e.target.value);
									handleFieldChange(e);
								}
							}
					className={inputStyle}
				/>
				</div>
				) : (
				<>
				
				<input
					type="text"
					value={otp}
					onChange={(e) => 
								{	
									setOtp(e.target.value)
									handleFieldChange(e);
								}
							 }
					placeholder="Enter OTP"
					className={inputStyle}
				/>
				</>
				)}
	
				{error && <p className="text-red-500 text-sm text-center">{error}</p>}
				<button
					type="submit"
					className="w-full bg-gradient-to-br from-[#074572] via-[#074572] to-[#8CAAC3] text-white py-2 rounded-md font-semibold border-2 border-[#F2F6FA] hover:brightness-105 flex justify-center items-center gap-2"
					>
						{otpRequested ? 'Login' : 'Request OTP'}
						{/* 🔄 Spinner aligned next to text */}
							{loading && !otpRequested && (
							<FaSpinner className="animate-spin text-white text-base" />
						)}
				</button>
				<a href="#" onClick={handleSubmit} className="block text-center text-[#074572] font-medium hover:underline mt-2"> Resend OTP</a>
			</form>
	
			{/* Side Image */}
			<div className="hidden lg:flex w-[750px] relative rounded-lg overflow-hidden shadow-lg">
				<img src={s2} alt="Side Visual" />
			</div>
			
	
		</div>
		{/* Form Section Ends*/}
		
		{/* Modal for complete your details ends */}
		{showPersonalDetailsModal && (
		<div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
			<div className="bg-white rounded-2xl shadow-2xl p-6 w-[95%] max-w-md transform transition-all duration-300 scale-100 animate-fadeIn">
			
				{/* Heading */}
				<h2 className="text-2xl font-bold text-[#074572] text-center mb-6">
					Complete your Details 
				</h2>
	
				{/* Full Name */}
				<div className="mb-4">
					<label className="block text-sm font-medium text-gray-700 mb-1">
						Full Name <span className="text-red-500">*</span>
					</label>
					<input
					type="text"
					placeholder="Enter full name"
					value={newUserData.name}
					onChange={(e) => setNewUserData({ ...newUserData, name: e.target.value })}
					className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#074572] transition"
					/>
				</div>
	
				{/* Phone with Calling Code */}
				<div className="mb-4">
					<label className="block text-sm font-medium text-gray-700 mb-1">
						Phone <span className="text-red-500">*</span>
					</label>
					<div className="flex rounded-lg overflow-hidden border border-gray-300 focus-within:ring-2 focus-within:ring-[#074572]">
						<span className="bg-gray-100 px-4 py-2 text-sm text-gray-700">
							{newUserData.callingCode}
						</span>
						<input
							type="tel"
							placeholder="Enter phone number"
							className="w-full px-4 py-2 text-sm outline-none"
							value={newUserData.phone}
							onChange={(e) => setNewUserData({ ...newUserData, phone: e.target.value })}
						/>
					</div>
				</div>
	
				{/* Address */}
				<div className="mb-6">
					<label className="block text-sm font-medium text-gray-700 mb-1">
						Address <span className="text-red-500">*</span>
					</label>
					<input
						type="text"
						placeholder="Enter address"
						value={newUserData.address}
						onChange={(e) => setNewUserData({ ...newUserData, address: e.target.value })}
						className="w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#074572] transition"
					/>
				</div>
	
				{/* Submit Button */}
				<button
					onClick=
					{
						async () => 
						{
							const fullPhone = `${newUserData.callingCode}${newUserData.phone}`;
							if (
								!newUserData.name.trim() ||
								!newUserData.phone.trim() ||
								!newUserData.address.trim()
							) 
							{
								alert("Please fill all required fields before continuing.");
								return;
							}
	
						try 
						{
							const payload = 
							{
								email,
								name: newUserData.name,
								address: newUserData.address,
								phone: fullPhone,
							};
	
							await axios.post(`${baseURL}/update-user-details`, payload);
							alert("Details updated successfully.");
							setShowPersonalDetailsModal(false);
							navigate("/Client", { replace: true });
						} catch (err) 
						{
							console.error("Update failed", err);
							alert("Failed to update details.");
						}
						}
					}
						className="bg-[#074572] text-white text-sm font-semibold px-4 py-2 rounded-lg w-full shadow-md hover:opacity-90 transition"
				>
						Proceed for Esal-e-Sawab
				</button>
			</div>
		</div>
		)}
		{/* Modal for complete your details ends */}
	
		{/*Contact us*/}
		<section className="bg-[#074572] mt-16 pt-4 pb-0 mb-0">
		
		<div className="mt-5">
			<h1 className="text-3xl font-bold mb-6 text-[#F2F6FA] text-center pb-0 mb-0">
			Contact Us
			</h1>
			
			{/* Subscribe + Social */}
			<div className="bg-[#fff] bg-opacity-50 rounded-md p-6 max-w-6xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-6 mb-6">
				{/* Subscribe */}
				<div className="flex flex-col items-center lg:items-start text-center lg:text-left w-full lg:w-1/2 space-y-3">
				<h2 className="text-2xl font-extrabold text-[#074572] drop-shadow-md">
					Join The Impact Community
				</h2>
				<div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-0">
					<input
					type="email"
					placeholder="Email Id"
					className="p-2 rounded-l-md w-64 sm:w-auto text-[#074572] border border-[#074572]"
					/>
					<button className="bg-[#074572] px-4 ml-3 py-2 rounded-md text-white font-semibold hover:bg-[#8CAAC3] transition">
					Subscribe
					</button>
				</div>
				</div>
	
				{/* Social Icons */}
				<div className="flex flex-col items-center lg:items-end w-full lg:w-1/2 space-y-3 text-center lg:text-right">
				<h3 className="text-2xl font-bold text-[#074572] drop-shadow-md sm:mr-9">
					Follow us
				</h3>
				<div className="flex justify-center lg:justify-end space-x-4 bg-white rounded-md p-3 ">
					<a href="#" className="text-2xl text-green-600 hover:text-green-600">
					<i className="fab fa-whatsapp"></i>
					</a>
					<a href="#" className="text-2xl text-blue-600 hover:text-blue-600">
					<i className="fab fa-facebook"></i>
					</a>
					<a href="#" className="text-2xl text-blue-700 hover:text-blue-700">
					<i className="fab fa-linkedin"></i>
					</a>
					<a href="#" className="text-2xl text-pink-500 hover:text-pink-500">
					<i className="fab fa-instagram"></i>
					</a>
	
				</div>
				</div>
			</div>
	
			{/* Dua Hub Info & Contact */}
			<div className="bg-[#F2F6FA] p-6 max-w-6xl mx-auto mb-3 text-sm">
				<div className="flex flex-col md:flex-row justify-between gap-6 mb-4">
				{/* Dua Hub Text */}
				<div className="md:w-2/3 text-center md:text-left mb-2">
					<h2 className="text-[#074572] font-bold text-2xl mb-3 transition-colors cursor-pointer">
					Dua Hub
					</h2>
					<div className="text-[#074572] max-w-2xl space-y-1 text-justify">
					<p>
						Want to honor someone you’ve lost? <br />With our Esal-e-Sawab
						services, you can send Quran
	
	
						recitation and dua on behalf of your loved ones —
						from anywhere in the world.
	
	
						<br /> Each act is carried out with care, sincerity & Islamic
						principles. <br /> Get in touch today to begin.
					</p>
					</div>
				</div>
	
				{/* Contact Info */}
				<div className="md:w-1/3 text-[#074572] text-left md:text-left sm:ml-90 space-y-2">
					
					<div className="flex justify-start items-center gap-1">
						<FaEnvelope className="text-[#074572]"/> 
						<p>
						duahub26@gmail.com
						</p>
					</div>
				
				</div>
				</div>
	
				{/* Bottom Row */}
				<div className="flex flex-col-reverse sm:flex-row justify-between items-center gap-4 border-t border-[#074572] pt-4 mt-4">
				<div className="text-[#074572] text-[10px] flex flex-wrap justify-center sm:justify-start gap-2">
					<a href="#" className="hover:underline">
					Terms of Use
					</a>
					<span>-</span>
					<a href="#" className="hover:underline">
					Privacy Policy
					</a>
					<span>-</span>
					<a href="#" className="hover:underline">
					Raise a Concern
					</a>
					<span>-</span>
					<a href="#" className="hover:underline">
					Cookie Policy
					</a>
				</div>
				<img
					src={paymentlogo}
					alt="Payment Methods"
					className="h-12 w-auto"
				/>
				</div>
				<div className="text-[#074572] text-[12px] text-center">
				  © {new Date().getFullYear()} Designed & Developed by Verheffen Infotech Pvt Ltd
				</div>
			</div>
			
		</div>
		</section>
	</>

	);
	}
     

