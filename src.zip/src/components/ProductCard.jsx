import { useState , useEffect } from 'react';
import quran from "../assets/slide1.png";
import quran_icon from "../assets/Quran_icon.png"
import React from 'react';
import bgImage from "../assets/bg-image.jpg";
import { baseURL } from "./baseURL";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaKey,
  FaLockOpen,
  FaWhatsapp ,
  FaStarAndCrescent ,
  FaMoon ,
  FaQuestion ,
  FaQuran 
} from "react-icons/fa";

const ProductCard = ({ image, onAddToCart }) => {
const [showPopup, setShowPopup] = useState(false);
const [quantity, setQuantity] = useState(1);
const increaseQuantity = () => setQuantity(prev => prev + 1);
const decreaseQuantity = () => setQuantity(prev => Math.max(1, prev - 1));
const [servc, setServc] = useState({});

	
  return (
	<>
	{/* Fetch services from DB */}
		<div className="grid sm:grid-cols-4 gap-6">
				{servc.map((item, index) => 
				(
					<div key={index}>
						<div className="bg-white shadow-md rounded-lg overflow-hidden w-full max-w-xs flex flex-col mt-5 ml-5">
						
							{/*backgrnd image div starts*/}
							<div className="w-full flex justify-center items-center p-2 h-70 sm:h-100 w-50 bg-[url('/bg-image_grey.jpg')] bg-cover bg-center border border-[#074572]">
								
								<div className="sm:h-80 h-65 mb-2 w-70 bg-[#074572] border-1 border-[#F2F6FA] shadow-2xl">
									<img
										src="./logo.png"
										alt="Logo"
										className="hidden sm:flex h-15 w-15 rounded-full object-cover ml-25 mt-3"
									/>
					
									<img
										src="./logo.png"
										alt="Logo"
										className="sm:hidden h-10 w-10 rounded-full object-cover ml-30 mt-2"
									/>
									<p 
										className="hidden sm:flex justify-center text-bold sm:text-xl text-sm font-[cursive] text-[#F2F6FA] mt-2">
											{item.service_heading}
									</p>
									
									<p 
										className="sm:hidden justify-center flex items-center text-bold sm:text-xl text-xl font-[cursive] text-[#F2F6FA] mt-2"> 
										 {item.service_heading}
									</p>
									
									<p 
										className="sm:hidden justify-center flex items-center text-bold sm:text-xl text-xl font-[cursive] text-[#F2F6FA] mt-2"> 
										{item.service_tagline}
									</p>
		
									<p 
										className="justify-center flex items-center text-bold sm:text-sm text-xs font-[cursive] text-[#F2F6FA] mt-3">
										{item.service_tagline}
									</p>
									<img
										src={quran_icon}
										alt="Logo"
										className="hidden sm:flex h-15 w-15 rounded-full object-cover ml-20 mt-3"
									/>
						
									<img
										src={quran_icon}
										alt="Logo"
										className="sm:hidden h-10 w-10 rounded-full object-cover ml-30 mt-1"
									/>
									<p 
										className="sm:flex text-left text-sm font-[cursive] text-[#F2F6FA] ml-3">
										{item.service_description}
									</p>
									
								</div>
								
							</div>
							{/*backgrnd image div ends*/}
							
							{/*Button div starts*/}
							
							{/* Add to Cart Button */}
							<div className="flex justify-center items-center">

								<button
									className="text-[#F2F6FA] px-2 py-2 rounded hover:bg-[#02588F] text-sm whitespace-nowrap border border-[#F2F6FA] bg-[#074572] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96] w-50 mt-2 mb-2"
								>
						
								<div className="flex justify-center items-center gap-3"> 
									<FaHeart size={20}  /> Add Blessing 
								</div>

								</button>
								
							</div>

						{/*Button div ends*/}	
						</div>
					</div>
					
			
				))}	
			
		</div>
		{/*Fetch services from DB ends*/}
  </>);
};

export default ProductCard;

