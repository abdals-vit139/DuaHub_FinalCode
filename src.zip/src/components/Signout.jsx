import { React,useEffect } from "react";
import {useNavigate} from 'react-router-dom';
import Home from '../components/Home';

const Signout = () => 
{
	const navigate =useNavigate();
	useEffect(() => {
    // Remove user email or token from localStorage
		localStorage.clear();
	
    // Navigate to the login page with replace to prevent going back
    navigate('/Login', { replace: true });
	}, [navigate]); // Empty dependency array ensures this only runs once
    return null;
}

export default Signout;