import React, { useEffect, useState } from "react";
import Sidebar from "../layouts/Sidebar";
import Header from "../layouts/Header";
import { baseURL } from "./baseURL";

const UpdateService = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editId, setEditId] = useState(null);
  const [formData, setFormData] = useState({
    service_heading: "",
    service_tagline: "",
    service_description: "",
    status: "active",
	price:"",
	service_id:""
  });

  const fetchServices = async () => {
    try {
      const response = await fetch(`${baseURL}/api/services`);
      const data = await response.json();
      setServices(data);
    } catch (error) {
      console.error("Error fetching services:", error);
    } finally {
      setLoading(false);
    }
  };
console.log(services);
  const handleEditClick = (service) => {
	  console.log(service.id);
    setEditId(service.id);
    setFormData({
      service_heading: service.service_heading,
      service_tagline: service.service_tagline,
      service_description: service.service_description,
      status: service.status,
	  price: service.price,
	  service_id: service.service_id,
	  
    });
  };

  const handleUpdate = async () => {
    try {
      const res = await fetch(`${baseURL}/api/services/${editId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
	console.log(editId);
      if (res.ok) {
        alert("Service updated successfully.");
        setEditId(null);
        fetchServices();
      } else {
        alert("Failed to update service.");
      }
    } catch (err) {
      console.error("Error updating service:", err);
      alert("Error updating service.");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  useEffect(() => {
    fetchServices();
  }, []);

  return (
    <div>
      <Header />
      <div className="flex flex-col lg:flex-row">
        <Sidebar />
        <div className="p-6 w-full">
          <h2 className="text-2xl font-bold mb-4 text-[#074572]">Update Services</h2>
          {loading ? (
            <p>Loading services...</p>
          ) : services.length === 0 ? (
            <p>No services found.</p>
          ) : (
            <div className="overflow-x-auto w-full border rounded shadow-lg max-h-[500px]">
              <table className="min-w-[700px] w-full bg-white text-sm text-gray-700">
                <thead className="bg-[#074572] text-white sticky top-0 z-10">
                  <tr>
                    <th className="py-2 px-4 border">ID</th>
                    <th className="py-2 px-4 border">Heading</th>
                    <th className="py-2 px-4 border">Tagline</th>
                    <th className="py-2 px-4 border">Description</th>
                    <th className="py-2 px-4 border">Status</th>
					<th className="py-2 px-4 border">currency</th>
					<th className="py-2 px-4 border">price</th>
                    <th className="py-2 px-4 border">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {services.map((service) => (
                    <tr key={service.id} className="hover:bg-gray-100 transition">
                      <td className="py-2 px-4 border">{service.id}</td>
                      <td className="py-2 px-4 border">
                        {editId === service.id ? (
                          <input
                            name="service_heading"
                            value={formData.service_heading}
                            onChange={handleChange}
                            className="border px-2 py-1 w-full"
                          />
                        ) : (
                          service.service_heading
                        )}
                      </td>
                      <td className="py-2 px-4 border">
                        {editId === service.id ? (
                          <input
                            name="service_tagline"
                            value={formData.service_tagline}
                            onChange={handleChange}
                            className="border px-2 py-1 w-full"
                          />
                        ) : (
                          service.service_tagline
                        )}
                      </td>
                      <td className="py-2 px-4 border">
                        {editId === service.id ? (
                          <textarea
                            name="service_description"
                            value={formData.service_description}
                            onChange={handleChange}
                            className="border px-2 py-1 w-full"
                          />
                        ) : (
                          service.service_description
                        )}
                      </td>
                      <td className="py-2 px-4 border">
                        {editId === service.id ? (
                          <select
                            name="status"
                            value={formData.status}
                            onChange={handleChange}
                            className="border px-2 py-1 w-full"
                          >
                            <option value="ACTIVE">ACTIVE</option>
                            <option value="INACTIVE">INACTIVE</option>
                          </select>
                        ) : (
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              service.status === "inactive"
                                ? "bg-red-100 text-red-700"
                                : "bg-green-100 text-green-700"
                            }`}
                          >
                            {service.status}
                          </span>
                        )}
                      </td>
					   <td className="py-2 px-4 border">
                      
					  {service.currency}
              
                      </td>
					  <td className="py-2 px-4 border">
                        {editId === service.id ? (
                          <textarea
                            name="price"
                            value={formData.price}
                            onChange={handleChange}
                            className="border px-2 py-1 w-full"
                          />
                        ) : (
                          service.price
                        )}
                      </td>
                      <td className="py-2 px-4 border">
                        {editId === service.id ? (
                          <div className="flex gap-2">
                            <button
                              onClick={handleUpdate}
                              className="bg-green-600 text-white px-3 py-1 rounded"
                            >
                              Save
                            </button>
                            <button
                              onClick={() => setEditId(null)}
                              className="bg-gray-400 text-white px-3 py-1 rounded"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleEditClick(service)}
                            className="bg-[#074572] hover:bg-blue-700 text-white px-3 py-1 rounded"
                          >
                            Edit
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UpdateService;