import React, { useState } from 'react';
import styled from 'styled-components';
import { FaEnvelope, FaChevronDown } from 'react-icons/fa';
import bgImage from './assets/background.jpg';
import Logo from './assets/logo.jpg';
import { createGlobalStyle } from 'styled-components';

const Container = styled.div`
  background: url(${bgImage}) no-repeat center center;
  background-size: cover;
  min-height: 100vh;
  overflow: hidden;
  display: flex;
  margin: auto;
  justify-content: center;
  align-items: center;
`;
const FormWrapper = styled.div`
  min-height: 150px;
  position: relative;
  transition: all 0.3s ease;
`;


const Box = styled.div`
  padding: 60px 50px 50px;
  border-radius: 40px;
  background: #fff;
  box-shadow: 0 0 25px rgba(14, 252, 157, 0.4);
  width: 500px;
  text-align: center;
  position: relative;
`;

const LogoImage = styled.img`
  width: 120px;
  height: auto;
  margin-bottom: 20px;
  border-radius: 12px;
`;

const Heading = styled.h2`
  font-size: 30px;
  margin-bottom: 10px;
  font-weight: bold;
`;

const ToggleWrapper = styled.div`
  display: flex;
  justify-content: center;
  background: #eee;
  border-radius: 50px;
  padding: 5px;
  margin: 25px 0;
  width: fit-content;
  margin-left: auto;
  margin-right: auto;
`;

const ToggleButton = styled.button`
  background: ${({ active }) => (active ? '#01796F' : 'transparent')};
  color: ${({ active }) => (active ? 'white' : '#333')};
  padding: 12px 28px;
  border: none;
  border-radius: 50px;
  cursor: pointer;
  font-weight: 600;
  font-size: 17px;
  transition: all 0.3s ease;

  &:hover {
    background: ${({ active }) => (active ? '#026a60' : '#ddd')};
  }
`;

const InputWrapper = styled.div`
  display: flex;
  align-items: center;
  border: 1.5px solid #ccc;
  border-radius: 8px;
  padding: 10px 15px;
  margin-bottom: 15px;
`;

const FlagButton = styled.button`
  background: none;
  border: none;
  font-size: 22px;
  margin-right: 8px;
  cursor: pointer;
`;

const Input = styled.input`
  border: none;
  outline: none;
  flex: 1;
  font-size: 15px;
`;

const Icon = styled.div`
  margin-right: 8px;
  font-size: 18px;
`;

const MessageText = styled.p`
  font-size: 19px;
  color: #555;
  margin: px 0 5px 2px;
  text-align: left;
`;

const Button = styled.button`
  width: 100%;
  background: linear-gradient(135deg, rgb(6, 239, 154), #00ffc3);
  color: white;
  border: none;
  padding: 14px;
  font-weight: bold;
  border-radius: 50px;
  cursor: pointer;
  font-size: 17px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3), inset 0 0 5px rgba(255, 255, 255, 0.2);
  transition: all 0.35s ease;

  &:hover {
    background: linear-gradient(135deg, #04c046, #0cefbe);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4), inset 0 0 8px rgba(255, 255, 255, 0.25);
    transform: translateY(-2px);
  }
`;

const CountryDropdown = styled.div`
  position: absolute;
  top: 210px;
  left: 50%;
  transform: translateX(-50%);
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
  padding: 8px 0;
  z-index: 200;
  width: 220px;
`;

const CountryItem = styled.div`
  display: flex;
  align-items: center;
  padding: 12px 16px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background-color: #e6f8f0;
    transform: scale(1.02);
  }
`;


const CountryFlag = styled.span`
  font-size: 22px;
  margin-right: 12px;
`;

const CountryName = styled.span`
  font-size: 16px;
`;

const FooterText = styled.p`
  font-size: 19px;
`;
const LoginPage = () => {
  const [loginType, setLoginType] = useState('phone');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState({ code: 'IN', emoji: '🇮🇳', dial: '+91' });

  const countryOptions = [
    { code: 'IN', name: 'India', emoji: '🇮🇳', dial: '+91' },
    { code: 'US', name: 'USA', emoji: '🇺🇸', dial: '+1' },
    { code: 'AE', name: 'UAE', emoji: '🇦🇪', dial: '+971' },
  ];

  return (
    <>
 
    </>
  );
};
const GlobalStyles = createGlobalStyle`
  @media (max-width: 768px) {
    ${Box} {
      width: 90%;
      padding: 40px 25px 30px;
    }

    ${Heading} {
      font-size: 26px;
    }

    ${ToggleButton} {
      padding: 10px 20px;
      font-size: 15px;
    }

    ${InputWrapper} {
      padding: 8px 12px;
    }

    ${Input} {
      font-size: 14px;
    }

    ${Button} {
      font-size: 15px;
      padding: 12px;
    }

    ${CountryDropdown} {
      top: 200px;
      width: 85%;
    }

    ${CountryItem} {
      padding: 10px 14px;
    }

    ${CountryName} {
      font-size: 14px;
    }

    ${FooterText} {
      font-size: 16px;
    }
  }

  @media (max-width: 480px) {
    ${LogoImage} {
      width: 90px;
      margin-bottom: 15px;
    }

    ${Heading} {
      font-size: 22px;
    }

    ${Button} {
      padding: 10px;
    }

    ${CountryDropdown} {
      top: 190px;
    }
  }
`;



export default LoginPage;