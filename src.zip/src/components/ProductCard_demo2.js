
import quran from "../assets/slide1.png";
import quran_icon from "../assets/Quran_icon.png"
import React from 'react';
import bgImage from "../assets/bg-image.jpg";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaKey,
  FaLockOpen,
  FaWhatsapp ,
  FaStarAndCrescent ,
  FaMoon ,
  FaQuestion ,
  FaQuran 
} from "react-icons/fa";

const ProductCard_demo2 = ({ image, onAddToCart }) => {
  return (
	<>
	
	<div className="bg-white shadow-md rounded-lg overflow-hidden w-full max-w-xs flex flex-col">
      <div className="w-full flex justify-center items-center p-2  h-100 w-50 bg-[url('/bg-image_grey.jpg')] bg-cover bg-center border-1 border-[#034D83] ">
			
				<div className="h-80 w-70 bg-[#034D83] border-1 border-[#F2F6FA] shadow-2xl transform perspective-[500px] rotate-x-[5deg] animate__animated animate__pulse animate__infinite group">
						
						<img
							src="./logo.png"
							alt="Logo"
							className="h-15 w-15 rounded-full object-cover ml-25 mt-3"
						/>
						
						<p className="justify-center flex items-center text-bold text-xl font-[cursive] text-[#fff] mt-2">Surah Yaseen (سورۃ یٰسٓ)  
						</p>
						
						<p className="justify-center flex items-center text-bold text-sm font-[cursive] text-[#fff] mt-3">
							“Heart of the Quran”
						</p> 
				
				
						<img
							src={quran_icon}
							alt="Logo"
							className="h-15 w-15 rounded-full object-cover ml-20 mt-3"
						/>
							
						<p className="text-left text-sm font-[cursive] text-white ml-3">
									Surah Yaseen plays a significant role in providing comfort to the deceased and interceding on their behalf on Judgment Day.
						</p>

				</div>
	
      </div>
		{/* Add to Cart Button */}
		<div className="p-3 flex justify-center">
			<button
			onClick={onAddToCart}
			className="text-[#F2F6FA] px-4 py-2 rounded hover:bg-[#02588F] text-sm whitespace-nowrap border border-[#F2F6FA] bg-[#074572] transition-all duration-150 hover:brightness-110 hover:shadow-[0_2px_0_#D7E7F2] hover:scale-[0.98] active:scale-[0.96]"
        >
			<div className="flex justify-center items-center gap-1">
				<FaHeart size={20}  /> Add Blessing
			</div>
			</button>
		</div>
	</div>
	

  </>);
};

export default ProductCard_demo2;

