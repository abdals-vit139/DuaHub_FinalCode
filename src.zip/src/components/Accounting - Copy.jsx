// import React, { useState } from "react";
// import Header from "../layouts/Header";
// import Sidebar from "../layouts/Sidebar";
// import * as XLSX from "xlsx";

// const DownloadIcon = ({ onClick }) => (
//   <svg
//     onClick={onClick}
//     xmlns="http://www.w3.org/2000/svg"
//     fill="none"
//     viewBox="0 0 24 24"
//     stroke="currentColor"
//     className="w-6 h-6 cursor-pointer text-blue-600 hover:text-blue-800"
//     title="Download Bill"
//   >
//     <path
//       strokeLinecap="round"
//       strokeLinejoin="round"
//       strokeWidth={2}
//       d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 12v8m0 0l-4-4m4 4l4-4M12 4v8"
//     />
//   </svg>
// );

// const HeaderDownloadIcon = () => (
//   <svg
//     xmlns="http://www.w3.org/2000/svg"
//     fill="none"
//     viewBox="0 0 24 24"
//     stroke="currentColor"
//     className="w-5 h-5 mx-auto text-gray-600"
//     title="Download All"
//   >
//     <path
//       strokeLinecap="round"
//       strokeLinejoin="round"
//       strokeWidth={2}
//       d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 12v8m0 0l-4-4m4 4l4-4M12 4v8"
//     />
//   </svg>
// );

// const Accounting = () => {
//   const staticData = [
//     {
//       client_name: "John Doe",
//       email: "john@example.com",
//       mobile: "9876543210",
//       city: "Mumbai",
//       state: "Maharashtra",
//       country: "India",
//       billing_date: "2025-06-01",
//       billing_total: "4500",
//       amount_paid: "3000",
//       balance: "1500",
//     },
//     {
//       client_name: "Priya more",
//       email: "priya@example.com",
//       mobile: "9123456780",
//       city: "Delhi",
//       state: "Delhi",
//       country: "India",
//       billing_date: "2025-06-02",
//       billing_total: "6000",
//       amount_paid: "6000",
//       balance: "0",
//     },
//     {
//       client_name: "Arjun Ram",
//       email: "arjun.patel@example.com",
//       mobile: "9988776655",
//       city: "Ahmedabad",
//       state: "Gujarat",
//       country: "India",
//       billing_date: "2025-05-28",
//       billing_total: "3200",
//       amount_paid: "3200",
//       balance: "0",
//     },
//     {
//       client_name: "Sneha bos",
//       email: "sneha.verma@example.com",
//       mobile: "9871234567",
//       city: "Bangalore",
//       state: "Karnataka",
//       country: "India",
//       billing_date: "2025-06-03",
//       billing_total: "5000",
//       amount_paid: "3500",
//       balance: "1500",
//     },
//     {
//       client_name: "Anita Das",
//       email: "anita.das@example.com",
//       mobile: "9900112233",
//       city: "Kolkata",
//       state: "West Bengal",
//       country: "India",
//       billing_date: "2025-06-05",
//       billing_total: "2700",
//       amount_paid: "1500",
//       balance: "1200",
//     },
//   ];

//   // Initialize filters with empty string (means no filter)
//   const [filters, setFilters] = useState({
//     client_name: "",
//     email: "",
//     mobile: "",
//     city: "",
//     state: "",
//     country: "",
//     billing_date: "",
//   });

//   // Extract unique values per column for dropdown options
//   const getUniqueValues = (key) => {
//     const unique = [...new Set(staticData.map((item) => item[key]))];
//     return unique.sort();
//   };

//   const handleFilterChange = (e) => {
//     const { name, value } = e.target;
//     setFilters((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   // Filter data according to dropdown selections
//   const filteredData = staticData.filter((item) =>
//     Object.entries(filters).every(([key, val]) =>
//       val === "" ? true : item[key] === val
//     )
//   );

//   const paidTotal = filteredData.reduce(
//     (acc, curr) => acc + parseFloat(curr.amount_paid),
//     0
//   );
//   const unpaidTotal = filteredData.reduce(
//     (acc, curr) => acc + parseFloat(curr.balance),
//     0
//   );
//   const billingTotal = filteredData.reduce(
//     (acc, curr) => acc + parseFloat(curr.billing_total),
//     0
//   );

//   const exportToExcel = () => {
//     const ws = XLSX.utils.json_to_sheet(filteredData);
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "BillingData");
//     XLSX.writeFile(wb, "AccountingDetails.xlsx");
//   };

//   const exportSingleBill = (row) => {
//     const ws = XLSX.utils.json_to_sheet([row]);
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "Bill");
//     const fileName = `${row.customer_name.replace(/\s+/g, "_")}_Bill.xlsx`;
//     XLSX.writeFile(wb, fileName);
//   };

//   return (
//     <div>
//       <Header />
//       <div className="flex">
//         <Sidebar />
//         <div className="p-6 w-full">
//           <h1 className="text-3xl font-bold mb-6">Accounting Details</h1>

//           <div className="flex gap-3 mb-4">
//             <div className="bg-teal-200 p-4 rounded-md font-bold text-teal-800">
//               Paid ₹{paidTotal.toFixed(2)}
//             </div>
//             <div className="bg-blue-200 p-4 rounded-md font-bold text-blue-800">
//               Unpaid ₹{unpaidTotal.toFixed(2)}
//             </div>
//             <div className="bg-yellow-200 p-4 rounded-md font-bold text-yellow-800">
//               Total ₹{(paidTotal + unpaidTotal).toFixed(2)}
//             </div>
//             <button
//               onClick={exportToExcel}
//               className="bg-green-500 text-white px-4 py-2 rounded-md ml-auto hover:bg-green-600"
//             >
//               Export to Excel
//             </button>
//           </div>

//           <div className="overflow-x-auto">
//             <table className="w-full table-auto border-collapse border border-gray-300">
//               <thead className="bg-gray-100">
//                 <tr>
//                   {[
//                     "client_name",
//                     "email",
//                     "mobile",
//                     "city",
//                     "state",
//                     "country",
//                     "billing_date",
//                   ].map((col) => (
//                     <th key={col} className="border p-2">
//                       <div className="mb-1 capitalize">
//                         {col.replace(/_/g, " ")}
//                       </div>
//                       <select
//                         name={col}
//                         value={filters[col]}
//                         onChange={handleFilterChange}
//                         className="w-full p-1 border rounded"
//                       >
//                         <option value="">All</option>
//                         {getUniqueValues(col).map((val) => (
//                           <option key={val} value={val}>
//                             {val}
//                           </option>
//                         ))}
//                       </select>
//                     </th>
//                   ))}
//                   <th className="border p-2">Billing Amount</th>
//                   <th className="border p-2 text-center">
//                     Bill
//                     <HeaderDownloadIcon />
//                   </th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {filteredData.length ? (
//                   filteredData.map((item, index) => (
//                     <tr key={index}>
//                       <td className="border p-2">{item.client_name}</td>
//                       <td className="border p-2">{item.email}</td>
//                       <td className="border p-2">{item.mobile}</td>
//                       <td className="border p-2">{item.city}</td>
//                       <td className="border p-2">{item.state}</td>
//                       <td className="border p-2">{item.country}</td>
//                       <td className="border p-2">{item.billing_date}</td>
//                       <td className="border p-2">₹{item.billing_total}</td>
//                       <td className="border p-2 text-center">
//                         <DownloadIcon onClick={() => exportSingleBill(item)} />
//                       </td>
//                     </tr>
//                   ))
//                 ) : (
//                   <tr>
//                     <td colSpan="9" className="text-center p-4">
//                       No records found.
//                     </td>
//                   </tr>
//                 )}
//               </tbody>
//               <tfoot className="bg-gray-100 font-bold">
//                 <tr>
//                   <td className="border p-2 text-right" colSpan="7">
//                     Total Billing Amount:
//                   </td>
//                   <td className="border p-2">₹{billingTotal.toFixed(2)}</td>
//                   <td className="border p-2"></td>
//                 </tr>
//               </tfoot>
//             </table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Accounting;
// import React, { useState } from "react";
// import Header from "../layouts/Header";
// import Sidebar from "../layouts/Sidebar";
// import * as XLSX from "xlsx";

// const DownloadIcon = ({ onClick }) => (
//   <svg
//     onClick={onClick}
//     xmlns="http://www.w3.org/2000/svg"
//     fill="none"
//     viewBox="0 0 24 24"
//     stroke="currentColor"
//     className="w-6 h-6 cursor-pointer text-blue-600 hover:text-blue-800"
//     title="Download Bill"
//   >
//     <path
//       strokeLinecap="round"
//       strokeLinejoin="round"
//       strokeWidth={2}
//       d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 12v8m0 0l-4-4m4 4l4-4M12 4v8"
//     />
//   </svg>
// );

// const HeaderDownloadIcon = () => (
//   <svg
//     xmlns="http://www.w3.org/2000/svg"
//     fill="none"
//     viewBox="0 0 24 24"
//     stroke="currentColor"
//     className="w-5 h-5 mx-auto text-gray-600"
//     title="Download All"
//   >
//     <path
//       strokeLinecap="round"
//       strokeLinejoin="round"
//       strokeWidth={2}
//       d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 12v8m0 0l-4-4m4 4l4-4M12 4v8"
//     />
//   </svg>
// );

// const Accounting = () => {
//   const staticData = [
//     {
//       client_name: "John Doe",
//       email: "john@example.com",
//       mobile: "9876543210",
//       city: "Mumbai",
//       state: "Maharashtra",
//       country: "India",
//       billing_date: "2025-06-01",
//       billing_total: "4500",
//       amount_paid: "3000",
//       balance: "1500",
//        request_status: "Pending",
//     },

//     {
//       client_name: "Arjun Ram",
//       email: "arjun.patel@example.com",
//       mobile: "9988776655",
//       city: "Ahmedabad",
//       state: "Gujarat",
//       country: "India",
//       billing_date: "2025-05-28",
//       billing_total: "3200",
//       amount_paid: "3200",
//       balance: "0",
//        request_status: "Pending",
//     },
//     {
//       client_name: "Sneha bos",
//       email: "sneha.verma@example.com",
//       mobile: "9871234567",
//       city: "Bangalore",
//       state: "Karnataka",
//       country: "India",
//       billing_date: "2025-06-03",
//       billing_total: "5000",
//       amount_paid: "3500",
//       balance: "1500",
//        request_status: "Approved",
//     },
//     {
//       client_name: "Anita Das",
//       email: "anita.das@example.com",
//       mobile: "9900112233",
//       city: "Kolkata",
//       state: "West Bengal",
//       country: "India",
//       billing_date: "2025-06-05",
//       billing_total: "2700",
//       amount_paid: "1500",
//       balance: "1200",
//        request_status: "Pending",
//     },
//   ];

//   // Filters state (existing)
//   const [filters, setFilters] = useState({
//     client_name: "",
//     email: "",
//     mobile: "",
//     city: "",
//     state: "",
//     country: "",
//     billing_date: "",
//   });

//   // New period filter state
//   const [periodFilter, setPeriodFilter] = useState("");
//   const [customDates, setCustomDates] = useState({ start: "", end: "" });
//   // Temporary values shown in inputs (not yet applied)
// const [tempCustomDates, setTempCustomDates] = useState({ start: "", end: "" });

//   const handleFilterChange = (e) => {
//     const { name, value } = e.target;
//     setFilters((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   const handlePeriodChange = (e) => {
//     setPeriodFilter(e.target.value);
//   };

//   // Helper to check if a date string is within a range (inclusive)
//   const isDateInRange = (dateStr, startStr, endStr) => {
//     const date = new Date(dateStr);
//     const start = new Date(startStr);
//     const end = new Date(endStr);
//     return date >= start && date <= end;
//   };

//   // Filter data by selected period
//   const filteredByPeriod = (data) => {
//     const now = new Date();
//     const year = now.getFullYear();
//     const month = now.getMonth();

//     if (periodFilter === "this_month") {
//       return data.filter((item) => {
//         const date = new Date(item.billing_date);
//         return date.getFullYear() === year && date.getMonth() === month;
//       });
//     } else if (periodFilter === "last_month") {
//       return data.filter((item) => {
//         const date = new Date(item.billing_date);
//         return (
//           date.getFullYear() === (month === 0 ? year - 1 : year) &&
//           date.getMonth() === (month === 0 ? 11 : month - 1)
//         );
//       });
//     } else if (periodFilter === "next_month") {
//       return data.filter((item) => {
//         const date = new Date(item.billing_date);
//         return (
//           date.getFullYear() === (month === 11 ? year + 1 : year) &&
//           date.getMonth() === (month === 11 ? 0 : month + 1)
//         );
//       });
//     } else if (periodFilter === "custom" && customDates.start && customDates.end) {
//       return data.filter((item) =>
//         isDateInRange(item.billing_date, customDates.start, customDates.end)
//       );
//     }
//     return data;
//   };

//   // Extract unique values per column for dropdown options
//   const getUniqueValues = (key) => {
//     const unique = [...new Set(staticData.map((item) => item[key]))];
//     return unique.sort();
//   };

//   // Apply existing filters first, then apply period filter
//   const filteredData = filteredByPeriod(
//     staticData.filter((item) =>
//       Object.entries(filters).every(([key, val]) =>
//         val === "" ? true : item[key] === val
//       )
//     )
//   );

//   const paidTotal = filteredData.reduce(
//     (acc, curr) => acc + parseFloat(curr.amount_paid),
//     0
//   );
//   const unpaidTotal = filteredData.reduce(
//     (acc, curr) => acc + parseFloat(curr.balance),
//     0
//   );
//   const billingTotal = filteredData.reduce(
//     (acc, curr) => acc + parseFloat(curr.billing_total),
//     0
//   );

//   const exportToExcel = () => {
//     const ws = XLSX.utils.json_to_sheet(filteredData);
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "BillingData");
//     XLSX.writeFile(wb, "AccountingDetails.xlsx");
//   };

//   const exportSingleBill = (row) => {
//     const ws = XLSX.utils.json_to_sheet([row]);
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "Bill");
//     const fileName = `${row.client_name.replace(/\s+/g, "_")}_Bill.xlsx`;
//     XLSX.writeFile(wb, fileName);
//   };
// const clearFilters = () => {
//   setFilters({
//     client_name: "",
//     email: "",
//     mobile: "",
//     city: "",
//     state: "",
//     country: "",
//     billing_date: "",
//   });
//   setPeriodFilter("");
//   setCustomDates({ start: "", end: "" });
//   setTempCustomDates({ start: "", end: "" });
// };

// const totalBillAmount = filteredData.reduce((sum, row) => sum + parseFloat(row.billing_total || 0), 0).toFixed(2);


//   return (
//     <div>
//       <Header />
//       <div className="flex">
//         <Sidebar />
//         <div className="p-6 w-full"  style={{ backgroundColor: "#F2F6FA" }}>
//           <h1 className="text-3xl font-bold mb-6" style={{ color: "#074572" }}>Accounting Details</h1>

//           {/* Period filter UI */}
//           <div className="mb-4 flex items-center gap-4">
//             <label htmlFor="periodFilter" className="font-semibold">
//               Select Period:
//             </label>
//             <select
//               id="periodFilter"
//               value={periodFilter}
//               onChange={handlePeriodChange}
//               className="p-2 border rounded"
//             >
//               <option value="">All</option>
//               <option value="this_month">This Month</option>
//               <option value="last_month">Last Month</option>
//               <option value="next_month">Next Month</option>
//               <option value="custom">Custom</option>
//             </select>
//             <button
//   onClick={clearFilters}
//   className="bg-[#074572] text-white px-3 py-2 rounded hover:bg-[#053957]"
// >
//   Clear Filters
// </button>



//             {periodFilter === "custom" && (
//   <>
//     <input
//       type="date"
//       value={tempCustomDates.start}
//       onChange={(e) =>
//         setTempCustomDates((prev) => ({ ...prev, start: e.target.value }))
//       }
//       className="p-2 border rounded"
//       placeholder="Start Date"
//     />
//     <input
//       type="date"
//       value={tempCustomDates.end}
//       onChange={(e) =>
//         setTempCustomDates((prev) => ({ ...prev, end: e.target.value }))
//       }
//       className="p-2 border rounded"
//       placeholder="End Date"
//     />
//     <button
//       onClick={() => setCustomDates({ ...tempCustomDates })}
//       className="bg-green-600 text-white px-3 py-2 rounded hover:bg-green-800"
//     >
//       Apply
//     </button>
//   </>
// )}

//           </div>

//          {/* Export button and summary boxes in one row */}
// <div className="flex justify-between items-center mb-8 flex-wrap gap-4">


//   <div className="flex gap-3">
//     <div className="bg-[#074572] p-4 rounded-md font-bold text-white">
//      Billing Total ₹{billingTotal}
//     </div>
//   </div>

//   <button
//     onClick={exportToExcel}
//     className="bg-[#074572] hover:bg-blue-800 text-white px-4 py-2 rounded flex items-center gap-2 "
//     title="Download All"
//   >
//     Export to Excel
//   </button>
// </div>


//           {/* Table */}
//           <div className="overflow-auto rounded-md border border-gray-300 shadow-md">
//             <table className="w-full text-sm text-left text-gray-700">
//               <thead className="bg-gray-100 border-b border-gray-300">
//   <tr>
//     {[
//       "C.Name",
//       "Email",
//       "Mobile",
//       "City",
//       "State",
//       "Country",
//       "Bill Date",
//       "Bill Total",
//      "Req. Status", // <-- New column
//       "Bill",
//     ].map((heading, index) => {
//       // keys for filters (skip last 4 columns except billing_date which has filter)
//       const keys = [
//         "client_name",
//         "email",
//         "mobile",
//         "city",
//         "state",
//         "country",
//         "billing_date",
//         "", // Billing Total - no filter
//         "request_status", // ← Add this line
//         "", // Download - no filter
//       ];
//       const key = keys[index];

//       return (
//         <th
//           key={heading}
//           className="px-4 py-3 text-gray-600 font-semibold align-top"
//         >
//           <div>{heading}</div>
//           {/* Only show filter if key exists */}
//           {key && (
//             <select
//               name={key}
//               value={filters[key]}
//               onChange={handleFilterChange}
//               className="mt-1 p-1 border rounded w-full"
//             >
//               <option value="">All</option>
//               {getUniqueValues(key).map((val) => (
//                 <option key={val} value={val}>
//                   {val}
//                 </option>
//               ))}
//             </select>
//           )}
//         </th>
//       );
//     })}
//   </tr>
// </thead>

//               <tbody>
//                 {filteredData.length === 0 && (
//                   <tr>
//                     <td colSpan={11} className="text-center py-4">
//                       No records found.
//                     </td>
//                   </tr>
//                 )}
//                 {filteredData.map((row, i) => (
//                   <tr
//                     key={i}
//                     className={`border-b ${
//                       i % 2 === 0 ? "bg-white" : "bg-gray-50"
//                     }`}
//                   >
//                     <td className="px-4 py-3">{row.client_name}</td>
//                     <td className="px-4 py-3">{row.email}</td>
//                     <td className="px-4 py-3">{row.mobile}</td>
//                     <td className="px-4 py-3">{row.city}</td>
//                     <td className="px-4 py-3">{row.state}</td>
//                     <td className="px-4 py-3">{row.country}</td>
//                     <td className="px-4 py-3">{row.billing_date}</td>
//                     <td className="px-4 py-3">₹{row.billing_total}</td>
//                    <td className="px-4 py-3">
//   {row.request_status}
// </td>

//                     <td className="px-4 py-3 text-center">
//                       <DownloadIcon onClick={() => exportSingleBill(row)} />
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//               <tfoot>
//   <tr className="bg-gray-100 font-semibold text-gray-700">
//     <td colSpan={7} className="px-4 py-2 text-right" style={{ color: "#074572", fontFamily:"bold"}}>
//       Total
//     </td>
//     <td className="px-4 py-2">
//       ₹ {totalBillAmount}
//     </td>
//     <td colSpan={2}></td>
//   </tr>
// </tfoot>

//             </table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Accounting;


import React, { useState } from "react";
import Header from "../layouts/Header";
import Sidebar from "../layouts/Sidebar";
import * as XLSX from "xlsx";

const DownloadIcon = ({ onClick }) => (
  <svg
    onClick={onClick}
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    className="w-6 h-6 cursor-pointer text-blue-600 hover:text-blue-800"
    title="Download Bill"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 12v8m0 0l-4-4m4 4l4-4M12 4v8"
    />
  </svg>
);

const Accounting = () => {
  const staticData = [
    {
      client_name: "John Doe",
      email: "john@example.com",
      mobile: "9876543210",
      city: "Mumbai",
      state: "Maharashtra",
      country: "India",
      billing_date: "2025-06-01",
      billing_total: "4500",
      amount_paid: "3000",
      balance: "1500",
      request_status: "Pending",
    },
    {
      client_name: "Arjun Ram",
      email: "arjun.patel@example.com",
      mobile: "9988776655",
      city: "Ahmedabad",
      state: "Gujarat",
      country: "India",
      billing_date: "2025-05-28",
      billing_total: "3200",
      amount_paid: "3200",
      balance: "0",
      request_status: "Pending",
    },
    {
      client_name: "Sneha bos",
      email: "sneha.verma@example.com",
      mobile: "9871234567",
      city: "Bangalore",
      state: "Karnataka",
      country: "India",
      billing_date: "2025-06-03",
      billing_total: "5000",
      amount_paid: "3500",
      balance: "1500",
      request_status: "Approved",
    },
    {
      client_name: "Anita Das",
      email: "anita.das@example.com",
      mobile: "9900112233",
      city: "Kolkata",
      state: "West Bengal",
      country: "India",
      billing_date: "2025-06-05",
      billing_total: "2700",
      amount_paid: "1500",
      balance: "1200",
      request_status: "Pending",
    },
  ];

  // Filters state (existing)
  const [filters, setFilters] = useState({
    client_name: "",
    email: "",
    mobile: "",
    city: "",
    state: "",
    country: "",
    billing_date: "",
  });

  // New period filter state
  const [periodFilter, setPeriodFilter] = useState("");
  const [customDates, setCustomDates] = useState({ start: "", end: "" });
  // Temporary values shown in inputs (not yet applied)
  const [tempCustomDates, setTempCustomDates] = useState({ start: "", end: "" });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePeriodChange = (e) => {
    setPeriodFilter(e.target.value);
  };

  // Helper to check if a date string is within a range (inclusive)
  const isDateInRange = (dateStr, startStr, endStr) => {
    const date = new Date(dateStr);
    const start = new Date(startStr);
    const end = new Date(endStr);
    return date >= start && date <= end;
  };

  // Filter data by selected period
  const filteredByPeriod = (data) => {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();

    if (periodFilter === "this_month") {
      return data.filter((item) => {
        const date = new Date(item.billing_date);
        return date.getFullYear() === year && date.getMonth() === month;
      });
    } else if (periodFilter === "last_month") {
      return data.filter((item) => {
        const date = new Date(item.billing_date);
        return (
          date.getFullYear() === (month === 0 ? year - 1 : year) &&
          date.getMonth() === (month === 0 ? 11 : month - 1)
        );
      });
    } else if (periodFilter === "next_month") {
      return data.filter((item) => {
        const date = new Date(item.billing_date);
        return (
          date.getFullYear() === (month === 11 ? year + 1 : year) &&
          date.getMonth() === (month === 11 ? 0 : month + 1)
        );
      });
    } else if (periodFilter === "custom" && customDates.start && customDates.end) {
      return data.filter((item) =>
        isDateInRange(item.billing_date, customDates.start, customDates.end)
      );
    }
    return data;
  };

  // Extract unique values per column for dropdown options
  const getUniqueValues = (key) => {
    const unique = [...new Set(staticData.map((item) => item[key]))];
    return unique.sort();
  };

  // Apply existing filters first, then apply period filter
  const filteredData = filteredByPeriod(
    staticData.filter((item) =>
      Object.entries(filters).every(([key, val]) =>
        val === "" ? true : item[key] === val
      )
    )
  );

  const paidTotal = filteredData.reduce(
    (acc, curr) => acc + parseFloat(curr.amount_paid),
    0
  );
  const unpaidTotal = filteredData.reduce(
    (acc, curr) => acc + parseFloat(curr.balance),
    0
  );
  const billingTotal = filteredData.reduce(
    (acc, curr) => acc + parseFloat(curr.billing_total),
    0
  );

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(filteredData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "BillingData");
    XLSX.writeFile(wb, "AccountingDetails.xlsx");
  };

  const exportSingleBill = (row) => {
    const ws = XLSX.utils.json_to_sheet([row]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Bill");
    const fileName = `${row.client_name.replace(/\s+/g, "_")}_Bill.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  const clearFilters = () => {
    setFilters({
      client_name: "",
      email: "",
      mobile: "",
      city: "",
      state: "",
      country: "",
      billing_date: "",
    });
    setPeriodFilter("");
    setCustomDates({ start: "", end: "" });
    setTempCustomDates({ start: "", end: "" });
  };

  const totalBillAmount = filteredData
    .reduce((sum, row) => sum + parseFloat(row.billing_total || 0), 0)
    .toFixed(2);

  return (
    <div>
      <Header />
      <div className="flex flex-col md:flex-row min-h-screen">
        <Sidebar />
        <div
          className="p-6 w-full"
          style={{ backgroundColor: "#F2F6FA" }}
        >
         <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold mb-4 text-[#074572] w-full max-w-lg mx-auto">
  <span className="flex-grow border-t border-[#074572] mr-4"></span>
  Accounting
  <span className="flex-grow border-t border-[#074572] ml-4"></span>
</h1>
          {/* Period filter UI */}
          <div className="mb-4 flex flex-col md:flex-row md:items-center gap-4">
            <label
              htmlFor="periodFilter"
              className="font-semibold"
            >
              Select Period:
            </label>
            <select
              id="periodFilter"
              value={periodFilter}
              onChange={handlePeriodChange}
              className="p-2 border rounded w-full md:w-auto"
            >
              <option value="">All</option>
              <option value="this_month">This Month</option>
              <option value="last_month">Last Month</option>
              <option value="next_month">Next Month</option>
              <option value="custom">Custom</option>
            </select>

            <button
              onClick={clearFilters}
              className="bg-[#074572] text-white px-3 py-2 rounded hover:bg-[#053957]"
            >
              Clear Filters
            </button>

            {periodFilter === "custom" && (
              <div className="flex flex-col md:flex-row md:items-center gap-2 w-full md:w-auto">
                <input
                  type="date"
                  value={tempCustomDates.start}
                  onChange={(e) =>
                    setTempCustomDates((prev) => ({
                      ...prev,
                      start: e.target.value,
                    }))
                  }
                  className="p-2 border rounded w-full md:w-auto"
                  placeholder="Start Date"
                />
                <input
                  type="date"
                  value={tempCustomDates.end}
                  onChange={(e) =>
                    setTempCustomDates((prev) => ({
                      ...prev,
                      end: e.target.value,
                    }))
                  }
                  className="p-2 border rounded w-full md:w-auto"
                  placeholder="End Date"
                />
                <button
                  onClick={() => setCustomDates({ ...tempCustomDates })}
                  className="bg-[#074572] text-white px-3 py-2 rounded hover:bg-green-800"
                >
                  Apply
                </button>
              </div>
            )}
          </div>

          {/* Export button and summary boxes */}
          <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4 flex-wrap">
            <div className="bg-gray-300 p-4 rounded-md font-bold text-black">
              Billing Total ₹{billingTotal}
            </div>

            <button
              onClick={exportToExcel}
              className="bg-[#074572] hover:bg-blue-800 text-white px-4 py-2 rounded flex items-center gap-2"
              title="Download All"
            >
              Export to Excel
            </button>
          </div>

          {/* Table container with horizontal scroll on small devices */}
          <div className="overflow-x-auto rounded-md border border-gray-300 shadow-md">
            <table className="min-w-[700px] w-full text-sm text-left text-gray-700">
              <thead className="bg-gray-100 border-b border-gray-300">
                <tr>
                  {[
                    "C.Name",
                    "Email",
                    "Mobile",
                    "City",
                    "State",
                    "Country",
                    "Bill Date",
                    "Bill Total",
                    "Req. Status",
                    "Bill",
                  ].map((heading, index) => {
                    // keys for filters (skip last 4 columns except billing_date which has filter)
                    const keys = [
                      "client_name",
                      "email",
                      "mobile",
                      "city",
                      "state",
                      "country",
                      "billing_date",
                      "", // Billing Total - no filter
                      "request_status",
                      "", // Download - no filter
                    ];
                    const key = keys[index];

                    return (
                      <th
                        key={heading}
                        className="px-2 md:px-4 py-3 text-gray-600 font-semibold align-top whitespace-nowrap"
                      >
                        <div>{heading}</div>
                        {/* Only show filter if key exists */}
                        {key && (
                          <select
                            name={key}
                            value={filters[key]}
                            onChange={handleFilterChange}
                            className="mt-1 p-1 border rounded w-full"
                          >
                            <option value="">All</option>
                            {getUniqueValues(key).map((val) => (
                              <option key={val} value={val}>
                                {val}
                              </option>
                            ))}
                          </select>
                        )}
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody>
                {filteredData.length === 0 && (
                  <tr>
                    <td colSpan={10} className="text-center py-4">
                      No records found.
                    </td>
                  </tr>
                )}
                {filteredData.map((row, i) => (
                  <tr
                    key={i}
                    className={`border-b ${
                      i % 2 === 0 ? "bg-white" : "bg-gray-50"
                    }`}
                  >
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.client_name}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.email}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.mobile}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.city}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.state}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.country}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.billing_date}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      ₹{row.billing_total}
                    </td>
                    <td className="px-2 md:px-4 py-3 whitespace-nowrap">
                      {row.request_status}
                    </td>

                    <td className="px-2 md:px-4 py-3 text-center whitespace-nowrap">
                      <DownloadIcon onClick={() => exportSingleBill(row)} />
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-gray-100 font-semibold text-gray-700">
                  <td
                    colSpan={7}
                    className="px-2 md:px-4 py-2 text-right text-[#074572] font-bold whitespace-nowrap"
                  >
                    Total
                  </td>
                  <td className="px-2 md:px-4 py-2 whitespace-nowrap">
                    ₹ {totalBillAmount}
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Accounting;
