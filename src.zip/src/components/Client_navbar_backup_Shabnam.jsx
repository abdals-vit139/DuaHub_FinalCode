import { useState } from "react";
import { Link } from "react-router-dom";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaHandsHelping,
  FaShieldAlt,
  FaKey,
  FaUser,

} from "react-icons/fa";


export default function Navbar() 
{
	const [menuOpen, setMenuOpen] = useState(false);
	return(
	<>
	  {/* Navbar */}
      <div 
			className="hidden sm:flex bg-[#074572] text-white flex flex-wrap md:flex-nowrap items-center justify-between px-4 py-0.5 sm:py-3 text-sm gap-4 relative z-10">
        
        <div className="flex items-center space-x-4">
         
			<button
            onClick={() => setMenuOpen(true)}
            className="text-[#F2F6FA] text-2xl focus:outline-none"
			>
				<FaBars />
			</button>
	
            <img
              src={logo}
              alt="duahub Logo"
              className="h-8 w-8 sm:h-12 sm:w-12 md:h-12 md:w-12 rounded-lg object-cover flex-shrink-0"
            />

        </div>

        {/* Delivery */}
        <div className="flex items-center space-x-1 cursor-pointer font-bold">
          <FaMapMarkerAlt />
          <span>Pune 411041</span>
        </div>

        {/* Search bar */}
        <div className="flex flex-grow max-w-6xl h-10 bg-[#F2F6FA] rounded overflow-hidden text-black mx-0 md:mx-4 w-full sm:w-auto flex-shrink-0">
          <select className="bg-[#F2F6FA] text-sm px-2 border-r border-gray-300 outline-none">
            <option>All</option>
          </select>
         
		 <input
            type="text"
            placeholder="Search Duahub.in"
            className="flex-grow px-3 text-sm outline-none"
          />
          
		  <button className="bg-[#F2F6FA] hover:bg-[#F2F6FA] px-4 flex items-center justify-center">
            <FaSearch className="text-black" />
          </button>
        </div>

        {/* Account */}
		<div className="flex justify-center items-center gap-1">
		<FaUser />
			<a href="/" className="cursor-pointer font-bold">
				<p>Welcome, User</p>
			</a>
		</div>


        {/* Cart */}
        <div
  onClick={() => setIsCartModalOpen(true)}
  className="relative flex items-center text-sm font-bold cursor-pointer"
>
  <div className="relative">
    
	<img src={sandook} className="w-12 h-12" />
    {cartItems.length > 0 && (
      <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
        {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
      </span>
    )}
  </div>
  {<span className="ml-1">Blessing Box</span> }
</div>

      </div>
	  {/*Nav bar ends*/}

		{/* Navbar for mobile*/}
      <div className="sm:hidden bg-[#074572] fixed top-0 text-white flex flex-wrap md:flex-nowrap items-center justify-between px-4 py-0.5 sm:py-3 text-sm gap-4 relative z-10">
        {/* Hamburger + Logo */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setMenuOpen(true)}
            className="text-[#F2F6FA] text-2xl focus:outline-none"
          >
            <FaBars />
          </button>

            <img
              src={logo}
              alt="duahub Logo"
              className="h-8 w-8 sm:h-12 sm:w-12 md:h-12 md:w-12 rounded-lg object-cover flex-shrink-0 mt-1"
            />

        </div>
		
        {/* Account */}
		<div className="flex justify-right items-center gap-1 ml-24">
		<FaUser />
			<a href="/" className="cursor-pointer font-bold">
				<p>Welcome, User</p>
			</a>
		</div>
		
		
		{/* Cart */}
        <div
			onClick={() => setIsCartModalOpen(true)}
			className="relative flex items-center text-sm font-bold cursor-pointer"
		>
			<div className="relative">
				<FaArchive  className="text-2xl" />
					{cartItems.length > 0 && (
						<span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex 	items-center justify-center rounded-full">
						{cartItems.reduce((sum, item) => sum + item.quantity, 0)}
						</span>
					)}
			</div>
		</div>
		{/* Search bar */}
        <div className="flex flex-grow max-w-6xl h-10 bg-[#F2F6FA] rounded overflow-hidden text-black mx-0 md:mx-4 w-full sm:w-auto flex-shrink-0 mb-2">
          <select className="bg-[#F2F6FA] text-sm px-2 border-r border-gray-300 outline-none">
            <option>All</option>
          </select>
          <input
            type="text"
            placeholder="Search Duahub.in"
            className="flex-grow px-3 text-sm outline-none"
          />
          <button className="bg-[#F2F6FA] hover:bg-[#F2F6FA] px-4 flex items-center justify-center">
            <FaSearch className="text-black" />
          </button>
        </div>

     </div>
	  {/*Nav bar ends*/}
		  {/*<div className="flex justify-center gap-2 items-center mt-3 bg-[#074572] h-10">
			<FaHandsHelping size={30} className="text-[#F2F6FA]"/> 
			
			<p className="flex justify-center text-bold text-center sm:text-3xl text-[#F2F6FA] text-sm">Send Blessings to their souls with your selections 
			</p>
		</div> */}
 
		
		<div className="sm:hidden flex justify-center items-center mt-2 bg-[#F2F6FA] h-[50px] gap-4 px-4">
		<img src="/s3.jpg" alt="Spiritual" className="h-8 w-8 rounded-full object-cover rounded" />
		<div className="flex items-center gap-2">
			<p className="text-[#074572] text-xs sm:text-3xl text-left font-semibold">
			Send Blessings to their souls with your selections
			</p>

		</div>
		
		</div>
		
	</>
  );
}