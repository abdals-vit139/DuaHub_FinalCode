import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import slide1 from "../assets/slide1.jpg";
import slide2 from "../assets/slide2.jpg";
import slide3 from "../assets/slide3.jpg";
import slide4 from "../assets/slide4.png";
import slide5 from "../assets/slide5.png";
import slide6 from "../assets/slide6.png";
import slide7 from "../assets/slide7.png";
import slide8 from "../assets/slide8.png";
import dua from "../assets/dua.jpg";
import s1 from "../assets/s1.jpeg";
import s2 from "../assets/s2.jpg";
import logo_1 from "../assets/logo-1.png";
import introVideo from "../assets/introVideo.mp4";
import About from "./About";
import Values from "./Values";
import Services from "./Services";
import Contact from "./Contact.jsx";
import Login from "./Login.jsx";
import { Link } from "react-router-dom";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaStarAndCrescent 
} from "react-icons/fa";


export default function navbar_desktop() {
const navButtonClass = `
	bg-gradient-to-br from-[#074572] via-[#F2F6FA] to-[#F2F6FA]
  text-[#074572] font-semibold sm:text-lg text-lg 
  px-6 sm:px-8 md:px-10 py-2 
  shadow-[0_4px_0_#02588F] transition-all duration-150 
  hover:brightness-110 hover:shadow-[0_2px_0_#02588F] 
  hover:scale-[0.98] active:scale-[0.96]
  whitespace-nowrap
  sm:mr-1
`.trim();
  
const navButtonClass_1 = `
  bg-gradient-to-br from-[#074572] via-[#074572] to-[#F2F6FA]
  text-[#F2F6FA] font-semibold text-sm 
  px-6 sm:px-8 md:px-10 py-2 
  shadow-[0_3px_0_4px_#8CAAC3] transition-all duration-150 
  hover:brightness-110 hover:shadow-[0_2px_0_#074572] 
  hover:scale-[0.98] active:scale-[0.96]
  mr-7
`.trim();

const navButtonClass_2 = `

  text-[#F2F6FA] font-semibold text-lg
  px-6 sm:px-8 md:px-10 py-2 
`.trim();



  return (
		{/*Nav Bar for desktop device*/}
		<div className=" bg-[#074572] hidden sm:block fixed top-0 left-0 w-full z-50">
					
			<div className="bg-[#074572] text-white px-4 sm:h-14 h-10 rounded shadow-lg flex items-center justify-between w-full">
						
				<div className="flex items-center justify-center ">
													
					<div className="hidden sm:flex gap-11 items-center whitespace-nowrap">
						<img
							src="/logo.png"
							alt="Logo"
							className="h-12 w-12 rounded-full object-cover"
						/>

						<Link to="/" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg px-6 sm:px-6 md:px-6 py-2">
							<FaHome sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Home
						</Link>
						
						<Link to="/About" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg px-6 sm:px-6 md:px-6 py-2">
							<FaHeart sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Our Services
						</Link>
						
						<Link to="/Values" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg px-6 sm:px-6 md:px-6 py-2">
						    <FaHandsHelping sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Our Affiliates
						</Link>
						
						<Link to="/Services" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg px-6 sm:px-6 md:px-6 py-2">
						    <FaShieldAlt sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Why Us?
						</Link>
						
						<Link to="/Contact" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg px-6 sm:px-6 md:px-6 py-2">
						  <FaPhoneAlt sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Contact Us
						</Link>
						
						<Link to="/Login" className="flex items-center gap-2 text-[#F2F6FA] font-semibold text-lg">
						  <FaLock  sm:size={25} size={20} style={{ color: "#F2F6FA" }} /> Login/Signup
						</Link>
						
					</div>
				</div>
						

			</div>
		</div>
		{/*Nav Bar Ends*/}

	)
}
