import { useRef, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import Navbar from "./Navbar.jsx";
import bg from "../assets/bg-1.jpg";
import login from "../assets/login.jpg";

export default function Values() {
  const cards = [
    {

      title: "❤ We Understand Your Responsibilities..",
      text: "Life gets busy — between work, family, and everyday demands, it’s easy to lose track of the spiritual acts we deeply care about. That’s where DuaHub steps in — making it simple for you to fulfill your spiritual responsibilities with ease and consistency. ",
    },
    {

      title: "❤ We help you facilitate what They Need Most",
      text: "There’s one thing your deceased loved ones truly yearn for — Esaal-e-Sawab (a gift of spiritual reward).",
    },
    {
      title: "❤ Schedule Esaal-e-Sawab with DuaHub",
      text: "DuaHub helps you to schedule your esaal-e-sawab deeds weekly, monthly or yearly"
    },
    {

      title: "❤ Make your Hadiya online",
      text: "Send your Hadiya with ease.Track your Esaal-e sawab and honor their memory.",
    },
  ];

  const [current, setCurrent] = useState(0);

  const prevSlide = () => setCurrent((prev) => (prev === 0 ? cards.length - 1 : prev - 1));
  const nextSlide = () => setCurrent((prev) => (prev === cards.length - 1 ? 0 : prev + 1));

  // ✅ Auto-slide every 5 seconds
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000); // Change slide every 5s
    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  return (
<section className="w-full px-4 py-12 relative">
  <Navbar />
  <h2 className="text-3xl font-bold text-center text-[#074572] mb-8 mt-10">
    Our Role - How it works
  </h2>

  <div
    className="flex relative mx-auto flex-col md:flex-row"
    style={{
      maxWidth: "1000px",
      perspective: "1300px",
    }}
  >
    {/* ✅ Left Page - Hidden on Mobile */}
    <div
      className="hidden md:flex w-full md:w-1/2 h-[400px] bg-[#074572] flex-col justify-center items-center text-center text-white relative"
      style={{
        transformOrigin: "right center",
        boxShadow: "inset -20px 0 20px rgba(0,0,0,0.4)",
        borderRight: "3px solid #F2F6FA",
        marginRight: "-2px",
      }}
    >
      <img
        src="./logo.png"
        alt="Logo"
        className="h-20 w-20 rounded-full object-cover border-4 border-white shadow-lg mb-4"
        style={{
          animation: "flip-horizontal 20s infinite linear",
          transformStyle: "preserve-3d",
        }}
      />

      <h1 className="text-4xl font-bold leading-tight mb-2 drop-shadow-lg">
        ❤ Your <br /> Intention,<br /> Our <br /> Responsibility
      </h1>
    </div>

    {/* ✅ Right Page - Full width on Mobile */}
    <div
      className="w-full md:w-1/2 h-[400px] bg-[#F2F6FA] flex flex-col relative"
      style={{
        transformOrigin: "left center",
        boxShadow: "inset 20px 0 20px rgba(0,0,0,0.3)",
        borderLeft: "3px solid #074572",
        marginLeft: "-2px",
      }}
    >
      <div className="p-4 md:p-6">
        <h3 className="text-2xl font-semibold text-[#074572] text-center mt-8 mb-6">
          {cards[current].title}
        </h3>
        <p className="text-[#074572] text-base text-center mb-6 px-2">
          {cards[current].text}
        </p>

        <div className="flex justify-center">
          <Link
            to="/Login"
            className="inline-block border border-[#F2F6FA] bg-gradient-to-br from-[#034D83] to-[#8CAAC3] text-white font-semibold py-2 px-6 rounded-md shadow transition hover:scale-95"
          >
            🌸 Send Esaal-e-Sawab
          </Link>
        </div>
      </div>

      {/* ✅ Arrows - Hidden but functional */}
      <button
        onClick={prevSlide}
        className="absolute top-1/2 left-2 transform -translate-y-1/2 p-1 bg-white rounded-full shadow z-20 opacity-0"
      >
        <ChevronLeft size={20} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute top-1/2 right-2 transform -translate-y-1/2 p-1 bg-white rounded-full shadow z-20 opacity-0"
      >
        <ChevronRight size={20} />
      </button>
    </div>
  </div>
</section>



  );
}
