import React, { useState, useEffect } from "react";
import {
  FaSearch,
  FaArchive,
  FaBars,
  FaTimes,
  FaUser,
  FaHistory,
  FaTasks,
  FaSignOutAlt,
  FaMapMarkerAlt,
  FaHome
} from "react-icons/fa";
import { baseURL } from "./baseURL";
import logo from "../assets/logo.png";
import axios from "axios";
import sandook_w from "../assets/sandook_white.png";
import { Link, useNavigate } from "react-router-dom";

const Client_navbar = ({ cartItems, setIsCartModalOpen, username = "user123" }) => {
const [menuOpen, setMenuOpen] = useState(false);
const [userdata,setUserData] =useState('');
const [user, getUser] = useState([]);
const isLoggedIn = localStorage.getItem("loggedIn"); // Returns "true" (as a string)
const [userId, setUserId] = useState(null);

// Retrieve user ID from localStorage on component mount
useEffect(() => {
    const storedUserId = localStorage.getItem("loginIdentifier");
	console.log(storedUserId)
    if (storedUserId) {
      setUserId(storedUserId);
	     console.log(userId)
	     axios.post(`${baseURL}/api/GetUser`, { email: storedUserId })
        .then((res) => {
          console.log("User data:", res.data);
          setUserData(res.data[0]); // or set whatever part of response you need
        })
        .catch((err) => {
          console.error("Error fetching user:", err);
          //setError("Failed to fetch user data");
        });
    }
	}, []);
  return (
    <>
      {/* Navbar */}
		  {/*<div className="hidden sm:flex bg-[#074572] text-white flex flex-wrap md:flex-nowrap items-center justify-between px-4 py-0.5 sm:py-3 text-sm gap-4 relative z-10"> */}
			<div className="fixed top-0 left-0 w-full hidden sm:flex bg-[#074572] text-white flex flex-wrap md:flex-nowrap items-center justify-between px-4 py-0.5 sm:py-3 text-sm gap-4 z-50">

			{/* Hamburger + Logo */}
			<div className="flex items-center space-x-4">
				<button
				onClick={() => setMenuOpen(true)}
				className="text-[#F2F6FA] text-2xl focus:outline-none"
				>
					<FaBars />
				</button>
				<Link to="/" className="flex items-center space-x-1">
					<img
					src={logo}
					alt="duahub Logo"
					className="h-8 w-8 sm:h-12 sm:w-12 md:h-12 md:w-12 rounded-lg object-cover flex-shrink-0"
				/>
				</Link>
			</div>
			
			{/* Delivery */}
			<div className="flex items-center space-x-1 cursor-pointer font-bold">
				<FaMapMarkerAlt />
				<span>{userdata.city} </span>
			</div>
			
			{/* Search bar */}
			<div className="flex flex-grow max-w-6xl h-10 bg-[#F2F6FA] rounded overflow-hidden text-black mx-0 md:mx-4 w-full sm:w-auto flex-shrink-0">
			<select className="bg-[#F2F6FA] text-sm px-2 border-r border-gray-300 outline-none">
				<option>All</option>
			</select>
			<input
				type="text"
				placeholder="Search Duahub.in"
				className="flex-grow px-3 text-sm outline-none"
			/>
			<button className="bg-[#F2F6FA] hover:bg-[#F2F6FA] px-4 flex items-center justify-center">
				<FaSearch className="text-black" />
			</button>
			</div>
			
			{/* Account */}
			<div className="flex justify-center items-center gap-1">
				<FaUser />
				<a href="/" className="cursor-pointer font-bold">
					<p>Welcome, {userdata.name}</p>
				</a>
			</div>


		</div>
    
		{/* Sidebar menu */}
		 <div className={`fixed top-0 left-0 h-full w-64 bg-[#074572] text-white p-4 z-50 transform ${
		menuOpen ? "translate-x-0" : "-translate-x-full"} transition-transform duration-300`}
		>
			<div className="flex justify-between items-center mb-6">
				<button
					onClick={() => setMenuOpen(false)}
					className="text-white text-xl"
				>
					<FaTimes />
				</button>
			</div>
			<ul className="space-y-4">
				<li className="flex items-center gap-3">
					<FaUser />
					<Link to="/Client" onClick={() => setMenuOpen(false)}>
						Home
					</Link>
				</li>
				<li className="flex items-center gap-3">
					<FaHistory />
					<Link to="/order-history" onClick={() => setMenuOpen(false)}>
						Order History
					</Link>
				</li>
				<li className="flex items-center gap-3">
					<FaTasks />
					<Link to="/manage-orders" onClick={() => setMenuOpen(false)}>
						Manage Orders
					</Link>
				</li>
		        <li className="flex items-center gap-3">
					<FaSignOutAlt />
					<Link to="/Logout" onClick={() => setMenuOpen(false)}>
						Logout
					</Link>
				</li>
			</ul>	

		</div> 
	</>
  );
};

export default Client_navbar;
