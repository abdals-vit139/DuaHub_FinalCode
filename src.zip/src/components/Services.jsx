import { Moon } from "lucide-react"; // or your preferred icon library
import dua from "../assets/dua.png";
import quran from "../assets/slide1.png";
import world from "../assets/world_1.jpg";
import path from "../assets/path.png";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import slide1 from "../assets/slide1.jpg";
import slide2 from "../assets/slide2.jpg";
import slide3 from "../assets/slide3.jpg";
import slide4 from "../assets/slide4.png";
import slide5 from "../assets/slide5.png";
import slide6 from "../assets/slide6.png";
import slide7 from "../assets/slide7.png";
import slide8 from "../assets/slide8.png";
import s1 from "../assets/s1.jpeg";
import s2 from "../assets/s2.jpg";
import introVideo from "../assets/introVideo.mp4";
import Contact from "./Contact.jsx";
import Values from "./Values";
import logo_1 from "../assets/logo-1.png";
import Login from "./Login.jsx";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/pagination';
import { Pagination,Autoplay  } from 'swiper/modules';
import whyDua from "../assets/WhyUs.png";
import impact from "../assets/impact.jpg";
import expat from "../assets/expat.jpg";
import community from "../assets/community.jpg";
import spiritual_connection from "../assets/spiritual_connection.png";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaArrowRight,
  FaSearch ,
  FaQuestion,
  FaKey,
  FaArrowUp 
} from "react-icons/fa";
import Client from "./Client.jsx";
import Navbar from "./Navbar.jsx";
import { useState } from "react";

export default function Services() {

const cardData = [
  {
    image: dua,
    alt: 'Dua',
    title: 'Instant Khatm-e-Quran',
    description: 'User-friendly interface designed for easy navigation and reading.',
  },
  {
    image: quran,
    alt: 'Quran',
    title: 'Personalized Blessings',
    description: 'Customize duas with their names and your intentions.',
  },
  {
    image: world,
    alt: 'World',
    title: 'Global Reach, Local Heart',
    description: 'Connect spiritually from anywhere in the world.',
  },
  {
    image: path,
    alt: 'Path',
    title: 'Hassle-Free Experience',
    description: 'A simple platform for your busy life.',
  },
  {
     image: spiritual_connection,
    alt: 'Path',
    title: 'Effortless spiritual Connection',
    description: 'Send Esaal-e-Sawab in just few clicks.',
  },
  {
     image: impact,
    alt: 'Path',
    title: 'Meaningful Impact',
    description: 'Every Dua brings your parents closer to Jannah',
  },
  {
     image: expat,
    alt: 'Path',
    title: 'Designed for Expats',
    description: 'Perfect for busy lives,anywhere in the world.',
  },
  {
     image: community,
    alt: 'Path',
    title: 'Trusted by Thousands',
    description: 'Join a community honoring thier loved ones.',
  },
     
];
const chunkArray = (arr, size) =>
  arr.reduce((acc, _, i) => (i % size ? acc : [...acc, arr.slice(i, i + size)]), []);

const cardRows = chunkArray(cardData, 4);

  return (
   
	<section className="bg-[#fff] shadow-md mt-3 mb-1 pt-4">
 
		<Navbar />

		<div className=" hidden lg:block space-y-12 mt-10 mb-2">
			{cardRows.map((row, rowIndex) => (
				<div key={rowIndex}>
	  
				{/* Row Heading */}
				<h2 className="text-4xl font-bold text-[#074572] mb-20 justify-center items center flex">{rowIndex === 0 ? "What We Offer ?" : "Why choose DuaHub ?"}</h2>

				{/* Card Grid */}
				<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-20 ">
				{row.map((card, index) => (
				<div
					key={index}
					className="relative bg-[#F2F6FA] rounded-md shadow-xl pt-16 px-4 pb-4 flex flex-col items-center text-white  ml-3 mr-6 transform transition-transform duration-300 hover:-translate-y-2 hover:scale-105 hover:shadow-[0_15px_30px_rgba(0,0,0,0.2)] border border-[#D7E7F2]"
				>

				{/* Floating Image */}
				<div className="absolute -top-10 left-1/2 transform -translate-x-1/2">
                <img
                  src={card.image}
                  alt={card.alt}
                  className="w-30 h-30 object-cover rounded-full  shadow-md"
                />
              </div>

              {/* Title */}
              <div className="flex items-center gap-2 mb-2 mt-10">
                <h2 className="text-2xl font-semibold text-[#074572] text-center">{card.title}</h2>
              </div>

              {/* Description */}
              <p className="text-sm text-center mb-4 px-2 text-[#074572]">{card.description}</p>

              {/* CTA Button */}
              <Link
                to="/Login"
                className="mt-auto inline-flex border border-[#F2F6FA] bg-gradient-to-br from-[#074572] via-[#074572] to-[#F2F6FA] text-[#F2F6FA] font-semibold py-1 px-4 items-center gap-2 shadow-[0_2px_0_#D7E7F2] transition duration-150 hover:brightness-110 hover:scale-[0.98] mb-5 border-2 border-[#D7E7F2] animate-border-move"
              >
                🌸 Send Esaal-e-Sawab
              </Link>
            </div>
          ))}
        </div>
		
      </div>
    ))}
  </div>
  
	{/*Mobile Screen*/}
  	{/* Mobile Swiper (visible only on small screens) */}
<div className="block lg:hidden mt-10 space-y-12">
  {cardRows.map((row, rowIndex) => (
    <div key={rowIndex}>
      <h2 className="text-3xl font-bold text-[#074572] mb-10 text-center">
        {rowIndex === 0 ? "What We Offer ?" : "Why choose DuaHub ?"}
      </h2>

      <Swiper
        modules={[Pagination, Autoplay]}
        pagination={{ clickable: true }}
        autoplay={{ delay: 3000, disableOnInteraction: false }}
        spaceBetween={20}
        slidesPerView={1}
        loop={true}
      >
        {row.map((card, index) => (
          <SwiperSlide key={index}>
            <div className="relative bg-[#F2F6FA] rounded-md shadow-xl pt-20 px-4 pb-4 flex flex-col items-center text-white mx-4 border border-[#D7E7F2] h-70">
              <div className="absolute -top-0 left-1/2 transform -translate-x-1/2 z-10">
                <img
                  src={card.image}
                  alt={card.alt}
                  className="w-[100px] h-[100px] mt-2 object-cover rounded-full shadow-md border border-[#D7E7F2]"
                />
              </div>
              <div className="flex items-center gap-2 mb-2 mt-10">
                <h2 className="text-xl font-semibold text-[#074572] text-center">
                  {card.title}
                </h2>
              </div>
              <p className="text-sm text-center mb-4 px-2 text-[#074572]">{card.description}</p>
              <Link
                to="/Login"
                className="mt-auto inline-flex border border-[#F2F6FA] bg-gradient-to-br from-[#074572] via-[#074572] to-[#F2F6FA] text-[#F2F6FA] font-semibold py-1 px-4 items-center gap-2 shadow-[0_2px_0_#D7E7F2] transition duration-150 hover:brightness-110 hover:scale-[0.98] mb-5 border-2 border-[#D7E7F2] animate-border-move"
              >
                🌸 Send Esaal-e-Sawab
              </Link>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  ))}
</div>
	{/**/}
</section>

  );
}
