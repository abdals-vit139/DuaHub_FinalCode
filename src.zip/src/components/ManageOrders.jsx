import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Header from '../layouts/Header';
import Sidebar from '../layouts/Sidebar';
import Client_navbar from "../components/Client_navbar";
import { Link } from "react-router-dom";
import {
FaDownload 
} from 'react-icons/fa';
import { baseURL } from "./baseURL";
import { Navigate } from "react-router-dom";


const ManageOrders = () => {
  const [data, setData] = useState([]);
  const [expandedRow, setExpandedRow] = useState(null);
  const [cartItems, setCartItems] = useState([]);
  const [isCartModalOpen, setIsCartModalOpen] = useState(false);
  const storedUserId = localStorage.getItem("loginIdentifier");
  const isLoggedIn 	 = localStorage.getItem("loggedIn");
  console.log(isLoggedIn)


  useEffect(() => {
    axios.post(`${baseURL}/api/user/manage-order`,{email: storedUserId})
      .then((res) => {
		  console.log(res);
        const grouped = [];

        res.data.forEach((row) => {
          if (row.order_status === 'completed') return; // Skip completed orders

          const key = `${row.username}_${row.bill_date}`;
          const existing = grouped.find((entry) => entry.key === key);

          const item = {
            product_name: row.product_name,
            quantity: row.quantity,
			currency :row.currency,
			price:row.price
          };

          if (existing) {
            existing.items.push(item);
          } else {
            grouped.push({
              key,
              id: row.id,
              total_price: row.total_price,
              order_status: row.order_status,
			  esaal_date :row.esaal_date,
			  deceased_name:row.deceased_name,
              items: [item],
            });
          }
        });

        setData(grouped);
      })
      .catch((err) => {
        console.error('Fetch error:', err);
        setData([]);
      });
  }, []);
  
  

  const updateStatus = (id, newStatus) => {
    axios.put(`${baseURL}/api/admin/update-status/${id}`, {
        order_status: newStatus,
      })
      .then(() => {
        setData(prev =>
          prev.map(order =>
            order.id === id ? { ...order, order_status: newStatus } : order
          )
        );
        alert('Status updated successfully');
      })
      .catch(err => {
        console.error('Status update error:', err);
        alert('Failed to update status');
      });
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-700';
      case 'processing': return 'bg-blue-100 text-blue-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-yellow-100 text-yellow-700';
    }
  };

	const toggleExpand = (key) => {
		setExpandedRow(prev => (prev === key ? null : key));
	};
  
  	const handleDownload = (id) => 
	{
		console.log(" in handle download func")
		console.log(id)
		window.location.href = `${baseURL}/document_download/${id}`;
	};

	//function to format date
	const formatDate = (dateString) => 
	{
		const date = new Date(dateString);
		const year = date.getFullYear();
		const month = String(date.getMonth() + 1).padStart(2, '0'); // months are zero-indexed
		const day = String(date.getDate()).padStart(2, '0');
		return `${year}-${month}-${day}`;
	};
	
	
	
	return (
    <>
      <Client_navbar/>
      <div className="flex flex-col md:flex-row min-h-screen">
        {/* <Sidebar /> */}
        <div className="p-6 w-full bg-[#F2F6FA]">
          <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold mb-6 text-[#074572] w-full max-w-lg mx-auto">
            <span className="flex-grow border-t border-[#074572] mr-4"></span>
            Manage Orders
            <span className="flex-grow border-t border-[#074572] ml-4"></span>
          </h1>

          <div className="overflow-x-auto bg-white shadow-md rounded-lg">
            <table className="min-w-full text-sm text-left border-collapse">
              <thead className="bg-gray-100 text-xs text-gray-700 uppercase">
                <tr>
                  <th className="px-3 py-3" style={{ color: "#074572" }}>#</th>
				   <th className="px-6 py-3" style={{ color: "#074572" }} >Bill #</th>
                  <th className="px-6 py-3" style={{ color: "#074572" }} >Deceased Name</th>
				  <th className="px-6 py-3" style={{ color: "#074572" }}> Date for Esal-e-Sawab</th>
				  <th className="px-6 py-3" style={{ color: "#074572" }}> Receipt</th>
				  <th className="px-6 py-3" style={{ color: "#074572" }}> Status</th>
				  
                </tr>
              </thead>
              <tbody>
                {data.length > 0 ? (
                  data.map((order, idx) => (
                    <React.Fragment key={order.key}>
                      <tr className="border-b hover:bg-gray-50">
					    
                        <td
                          className="px-3 py-4 cursor-pointer text-xl font-bold text-gray-600"
                          onClick={() => toggleExpand(order.key)}
                        >
                          {expandedRow === order.key ? '−' : '+'}
                        </td>
						<td className="px-6 py-4 font-medium" style={{ color: "#074572" }}>{order.id}</td>
                        <td className="px-6 py-4 font-medium" style={{ color: "#074572" }}>{order.deceased_name}</td>
						<td className="px-6 py-4 capitalize" style={{ color: "#074572" }}>{formatDate(order.esaal_date)}</td>
						<td className="px-6 py-4" style={{ color: "#074572" }}>
						<button className="flex items-center gap-1 text-[#F2F6FA] font-semibold text-lg px-6 py-2 rounded-md" title="Download Receipt" onClick={() => handleDownload(order.id)}>
						<FaDownload style={{ color: "#074572" }} />
						</button>
                        </td>
						<td className="px-6 py-4" style={{ color: "#074572" }}>
                          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${getStatusStyle(order.order_status)}`}>
                            {order.order_status || 'pending'}
                          </span>
                        </td>

                      </tr>

                      {expandedRow === order.key && (
                        <tr className="bg-gray-50">
                          <td colSpan="8" className="px-6 py-3">
                            <table className="ml-20 w-120 text-sm text-left border-collapse">
                              <thead className="bg-gray-300">
                                <tr>
                                  <th className="px-4 py-2">Product name</th>
                                  <th className="px-4 py-2">Quantity</th>
								  <th className="px-4 py-2">Price</th>
                                </tr>
                              </thead>
                              <tbody>
                                {order.items.map((item, i) => (
                                  <tr key={i} className="border-b">
                                    <td className="px-4 py-2">{item.product_name}</td>
                                    <td className="px-4 py-2">{item.quantity}</td>
									 <td className="px-4 py-2">{item.currency} {item.price}</td>

                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))
                ) : (
                  <tr>
                    <td colSpan="10" className="text-center px-6 py-10 text-gray-500">
                      No orders found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </>
  );
};

export default ManageOrders;
