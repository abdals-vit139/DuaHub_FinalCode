import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import slide1 from "../assets/slide1.jpg";
import slide2 from "../assets/slide2.jpg";
import slide3 from "../assets/slide3.jpg";
import slide4 from "../assets/slide4.png";
import slide5 from "../assets/slide5.png";
import slide6 from "../assets/slide6.png";
import slide7 from "../assets/slide7.png";
import slide8 from "../assets/slide8.png";
import dua from "../assets/dua.jpg";
import s1 from "../assets/s1.jpeg";
import s2 from "../assets/s2.jpg";
import introVideo from "../assets/introVideo.mp4";
import Contact from "./Contact.jsx";
import Values from "./Values";
import Services from "./Services";
import Login from "./Login.jsx";
import { Link } from "react-router-dom";
import Client from "./Client.jsx";
import Navbar from "./Navbar.jsx";
import '../animate.css';
import {
  FaEnvelope,
  FaPhoneAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaMapMarkerAlt ,
  FaRegFileAlt,
  FaKey
} from "react-icons/fa";
import { useState } from "react";
import { BookOpen, HeartHandshake, Globe, ShieldCheck } from "lucide-react";

const people = [
  {
    src:   "/Maulana_1.jpg",
    name: "Maulana  Wahiduddin Khan",
    role: "Pune",
	description: "Providing quality Islamic education and community support in Pune."
  },
  {
    src:   "/Maulana_1.jpg",
    name: "Maulana  Wahiduddin Khan",
    role: "Pune",
	description: "Providing quality Islamic education and community support in Pune."
  },
  {
    src:   "/Maulana_1.jpg",
    name: "Maulana Wahiduddin Khan",
    role: "Mumbai",
	description: "Providing quality Islamic education and community support in Pune."
  },
  {
    src: "/Madrasa_1.jpg",
    name: "Madrasa 1",
    role: "Pune",
	description: "Providing quality Islamic education and community support in Pune."
  },
  {
    src: "/Madrasa_1.jpg",
    name: "Madrasa 2",
    role: "Pune",
	description: "Providing quality Islamic education and community support in Pune."
  },
  {
    src: "/Madrasa_1.jpg",
    name: "Madrasa 3",
    role: "Pune",
	description: "Providing quality Islamic education and community support in Pune."
  },
];

export default function AutoScrollImages() {
	const navButtonClass_1 = `
  bg-gradient-to-br from-[#074572] via-[#074572] to-[#F2F6FA]
  font-semibold text-sm px-6 sm:px-6 md:px-6 py-2
  shadow-[0_1px_0_1px_#8CAAC3] transition-all duration-150 
  hover:brightness-110 hover:shadow-[0_2px_0_#074572] 
  hover:scale-[0.98] active:scale-[0.96]
  mr-7
`.trim();
const [menuOpen, setMenuOpen] = useState(false);
  return (
  <section className="bg-[#F2F6FA] text-[#fff] mt-14 pt-4 pb-0 mb-2">
	<Navbar />
	  <h1 className="text-3xl font-bold mb-3 text-[#074572] text-center ">Our Collaborators</h1>
		<div className="mx-auto ">
  
			<div className="sm:text-lg text-sm font-medium leading-loose tracking-wide sm:space-y-8 space-y-2 animate-fadeIn">
				
				<div className="flex items-start gap-x-4 px-2">
					<div className="w-6 mt-1 flex-shrink-0">
						<ShieldCheck sm:size={25} size={20} style={{ color: "#074572" }} />
					</div>
					<p className="flex-1 text-[#074572] text-left">
					<strong> Trusted Religious Scholars (Maulana): </strong>
					<p>Our Maulana partners are respected Islamic scholars with deep knowledge and experience, ensuring that all prayers, duas, and recitations are performed with proper adherence to Islamic teachings.</p>
					</p>
				</div>

				<div className="flex items-start gap-x-4 px-2">
					<div className="w-6 mt-1 flex-shrink-0">
						<BookOpen sm:size={25} size={20}  style={{ color: "#074572" }} />
					</div>
						<p className="flex-1 text-[#074572] text-left">
							<strong>	Affiliated Madrasas for Quranic Recitations: </strong> 
							<p>We collaborate with reputable Madrasas where Quran recitations and dua sessions are carried out by well-trained students and teachers, maintaining high religious standards.</p>
						</p>
				</div>



			</div>
		</div>
	<div className="mx-auto overflow-hidden">
		<div className="w-full overflow-hidden relative bg-gray-50 py-2">
			<div className="flex gap-6 animate-scroll whitespace-nowrap" style={{ animationTimingFunction: "linear", animationDuration: "25s" }}
			>
				{[...people, ...people].map(({ src, name, role,description }, idx) => (
				<div key={idx} className="w-52 flex-shrink-0">
					<img
					src={src}
					alt={name}
					className="h-40 w-full object-cover rounded-lg shadow-md"
					/>
					<div className="mt-2 bg-white rounded-md h-60 p-2 shadow text-center">
						<h3 className="font-semibold text-[#074572]">{name}</h3>
						<div className="flex justify-center items-center gap-1 mt-2">
							<FaMapMarkerAlt className="text-[#074572]"/><p className="text-sm text-[#074572]">{role}</p>
						</div>
						<div className="flex justify-center items-center gap-1 mt-2">
							<FaRegFileAlt className="text-[#074572]" /><p className="text-sm text-[#074572] break-words whitespace-normal h-12 justify-text mt-5">{description}</p>
						</div>
					</div>
				</div>
				))}
			</div>
	
			<style>{`
			@keyframes scroll {
				0% {
				transform: translateX(0);
				}
				100% {
				transform: translateX(-50%);
				}
			}
			.animate-scroll {
				animation-name: scroll;
				animation-iteration-count: infinite;
				animation-timing-function: linear;
				animation-duration: 25s;
				will-change: transform;
			}
			`}</style>
		</div>
	</div>

	</section>
	
  );
}
