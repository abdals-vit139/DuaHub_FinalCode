import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Header from '../layouts/Header';
import Sidebar from '../layouts/Sidebar';
import { baseURL } from "./baseURL";

const ManageStatus = () => {
  const [data, setData] = useState([]);
  const [expandedRow, setExpandedRow] = useState(null);

  useEffect(() => {
    axios.get(`${baseURL}/api/admin/manage-status`)
      .then((res) => {
        const grouped = [];

        res.data.forEach((row) => {
          const key = `${row.username}_${row.bill_date}`;
          const existing = grouped.find((entry) => entry.key === key);

          const item = {
            product_name: row.product_name,
            quantity: row.quantity,
			currency :row.currency,
			price:row.price
          };

          if (existing) {
            existing.items.push(item);
          } else {
            grouped.push({
              key,
              id: row.id, // needed for status update
              username: row.username,
              payment_method: row.payment_method,
              total_items: row.total_items,
              total_price: row.total_price,
              bill_date: row.bill_date,
			  deceased_name : row.deceased_name ,
			  relation : row.relation ,
			  date_of_death : row.date_of_death ,
			  esaal_date : row.esaal_date ,
			  schedule : row.schedule ,
			  order_status: row.order_status,
              items: [item],
            });
          }
        });

        setData(grouped);
      })
      .catch((err) => {
        console.error('Fetch error:', err);
        setData([]);
      });
  }, []);

  const updateStatus = (id, newStatus) => {
    axios
      .put(`${baseURL}/api/admin/update-status/${id}`, {
        order_status: newStatus,
      })
      .then(() => {
        setData(prev =>
          prev.map(order =>
            order.id === id ? { ...order, order_status: newStatus } : order
          )
        );
        alert('Status updated successfully');
      })
      .catch(err => {
        console.error('Status update error:', err);
        alert('Failed to update status');
      });
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-700';
      case 'processing': return 'bg-blue-100 text-blue-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-yellow-100 text-yellow-700';
    }
  };

  const toggleExpand = (key) => {
    setExpandedRow(prev => (prev === key ? null : key));
  };
	//function to format date
	const formatDate = (dateString) => 
	{
		const date = new Date(dateString);
		const year = date.getFullYear();
		const month = String(date.getMonth() + 1).padStart(2, '0'); // months are zero-indexed
		const day = String(date.getDate()).padStart(2, '0');
		return `${year}-${month}-${day}`;
	};
	
  return (
    <div>
      <Header />
      <div className="flex flex-col md:flex-row min-h-screen">
        <Sidebar />
        <div className="p-6 w-full bg-[#F2F6FA]">
          <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold mb-6 text-[#074572] w-full max-w-lg mx-auto">
            <span className="flex-grow border-t border-[#074572] mr-4"></span>
            Manage Order Status
            <span className="flex-grow border-t border-[#074572] ml-4"></span>
          </h1>

          <div className="overflow-x-auto bg-white shadow-md rounded-lg w-full">
            <table className="min-w-[3800px] w-full text-sm text-left border-collapse">
              <thead className="bg-gray-100 text-xs text-gray-700 uppercase">
                <tr>
                  <th className="px-3 py-3">#</th>
				  <th className="px-3 py-3">bill#</th>
                  <th className="px-3 py-3">User </th>
                  <th className="px-3 py-3"> Items</th>
                  <th className="px-3 py-3"> Price</th>
                  <th className="px-3 py-3">PaymentMode</th>
                  <th className="px-3 py-3">BillDate</th>
				  <th className="px-3 py-3">Deceased Name</th>
				  <th className="px-3 py-3">Relation</th>
				  <th className="px-3 py-3">Death date</th>
				  <th className="px-3 py-3">Esaal-e-sawab Date</th>
				  <th className="px-3 py-3">schedule</th>
                  <th className="px-3 py-3">Order Status</th>
                  <th className="px-3 py-3">Update Status</th>
                </tr>
              </thead>
              <tbody>
                {data.length > 0 ? (
                  data.map((order, idx) => (
                    <React.Fragment key={order.key}>
                      <tr className="border-b hover:bg-gray-50">
                        <td
                          className="px-3 py-4 cursor-pointer text-xl font-bold text-gray-600"
                          onClick={() => toggleExpand(order.key)}
                        >
                          {expandedRow === order.key ? '−' : '+'}
                        </td>
						<td className="px-3 py-4 font-medium whitespace-nowrap">{order.id}</td>
                        <td className="px-3 py-4 font-medium whitespace-nowrap">{order.username}</td>
                        <td className="px-3 py-4" whitespace-nowrap>{order.total_items}</td>
                        <td className="px-3 py-4 whitespace-nowrap">₹{parseFloat(order.total_price).toFixed(2)}</td>
                        <td className="px-3 py-4 capitalize whitespace-nowrap">{order.payment_method}</td>
                        <td className="px-3 py-4 whitespace-nowrap">{new Date(order.bill_date).toLocaleString()}</td>
						<td className="px-3 py-4 whitespace-nowrap" >{order.deceased_name}</td>
						<td className="px-3 py-4 whitespace-nowrap">{order.relation}</td>
						<td className="px-3 py-4 whitespace-nowrap">{formatDate(order.date_of_death)}</td>
						<td className="px-3 py-4 whitespace-nowrap">{formatDate(order.esaal_date)}</td>
						<td className="px-3 py-4 whitespace-nowrap">{order.schedule}</td>
                        <td className="px-3 py-4 whitespace-nowrap">
                          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${getStatusStyle(order.order_status)}`}>
                            {order.order_status || 'pending'}
                          </span>
                        </td>
                        <td className="px-3 py-4">
                          <select
                            value={order.order_status || 'pending'}
                            onChange={(e) => updateStatus(order.id, e.target.value)}
                            className="border border-gray-300 rounded px-2 py-1 text-sm bg-white"
                          >
                            <option value="pending">pending</option>
                            <option value="processing">processing</option>
                            <option value="completed">completed</option>
                            <option value="cancelled">cancelled</option>
                          </select>
                        </td>
                      </tr>

                      {expandedRow === order.key && (
                        <tr className="bg-gray-50">
                          <td colSpan="8" className="px-6 py-3">
                            <table className="ml-20 w-120 text-sm text-left border-collapse">
                              <thead className="bg-gray-300">
                                <tr>
                                  <th className="px-4 py-2">Product name</th>
                                  <th className="px-4 py-2">Quantity</th>
								  <th className="px-4 py-2">Price</th>
                                </tr>
                              </thead>
                              <tbody>
                                {order.items.map((item, i) => (
                                  <tr key={i} className="border-b">
                                    <td className="px-4 py-2">{item.product_name}</td>
                                    <td className="px-4 py-2">{item.quantity}</td>
									<td className="px-4 py-2">{item.currency} {item.price}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))
                ) : (
                  <tr>
                    <td colSpan="10" className="text-center px-6 py-10 text-gray-500">
                      No orders found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageStatus;
