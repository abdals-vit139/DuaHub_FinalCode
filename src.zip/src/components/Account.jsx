 export default function Account() {
  return (
  <section className="bg-gradient-to-b from-green-50 to-white">
    <div className="mt-10">
      Login Page Content
    </div>
      </section>
  );
}
