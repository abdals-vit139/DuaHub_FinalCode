import React, { useEffect, useState } from "react";
import Sidebar from "../layouts/Sidebar";
import Header from "../layouts/Header";
import { baseURL } from "./baseURL";


function ServiceConfiguration() 
{
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const currencySymbols = {
    USD: "$",
    INR: "₹",
    GBP: "£",
  };

  useEffect(() => 
  {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const res = await fetch(`${baseURL}/api/admin/getListofservices`);
      if (res.ok) {
        const data = await res.json();
        setServices(data);
      } else {
        console.error("Failed to fetch services");
      }
    } catch (error) {
      console.error("Error fetching services:", error);
    } finally {
      setLoading(false);
    }
  };
  
  // Helper to get prices as { USD: 10, INR: 700, ... }
  const getPriceMap = (pricesArray) => 
  {
	const priceMap = {};
	pricesArray?.forEach(({ currency, price }) => {
    priceMap[currency] = price;
  });
  return priceMap;
};

  return (
    <div className="min-h-screen bg-[#F2F6FA] text-black">
		<Header />
		<div className="flex flex-col lg:flex-row">
        <Sidebar />
        <div className="w-full flex flex-col items-center px-4 sm:px-6 lg:px-8 pt-0">
          <h1 className=" flex items-center text-3xl sm:text-4xl font-extrabold text-[#074572] w-full max-w-lg mx-auto mt-4 mb-5">
            <span className="flex-grow border-t border-[#074572] mr-4"></span>
            List of Services
            <span className="flex-grow border-t border-[#074572] ml-4"></span>
          </h1>

          <div className="w-full max-w-7xl mx-auto bg-white rounded-xl shadow-md p-6 border border-gray-200">
            <h2 className="text-2xl font-bold text-[#074572] mb-4 border-b pb-2 text-center">
              All Services
            </h2>

            {loading ? (
              <p className="text-gray-500">Loading services...</p>
            ) : services.length === 0 ? (
              <p className="text-gray-500">No services found.</p>
            ) : (
              <div className="w-full max-w-6xl overflow-x-auto rounded-lg shadow">
	<table className="w-full table-auto border-2 border-gray-300 text-sm rounded-lg border-collapse">
    <thead className="bg-[#074572] text-white text-xs uppercase tracking-wide">
      <tr>
        <th className="border border-gray-400 px-2 py-2 text-left whitespace-nowrap">Heading</th>
        <th className="border border-gray-400 px-2 py-2 text-left whitespace-nowrap">Tagline</th>
        <th className="border border-gray-400 px-2 py-2 text-left whitespace-nowrap">Description</th>
        <th className="border border-gray-400 px-4 py-4 whitespace-nowrap">
			USD
       </th>
		<th className="border border-gray-400 px-2 py-2 whitespace-nowrap">
			INR
        </th>
		<th className="border border-gray-400 px-2 py-2 whitespace-nowrap">
			GBP
        </th>
        <th className="border border-gray-400 px-2 py-2 text-left whitespace-nowrap">Status</th>
        <th className="border border-gray-400 px-2 py-2 text-left whitespace-nowrap">Created At</th>
      </tr>
    </thead>
    <tbody className="bg-white divide-y divide-gray-200">
      {services.map((service, index) => {
        const priceMap = getPriceMap(service.prices || []);
        return (
          <tr
            key={service.id}
            className="hover:bg-gray-100 transition duration-150"
          >
            <td className="border border-gray-400 px-2 py-2 whitespace-nowrap">{service.service_heading}</td>
            <td className="border border-gray-400 px-2 py-2 whitespace-nowrap">{service.service_tagline}</td>
            <td className="border border-gray-400 px-2 py-2 whitespace-wrap overflow-hidden text-ellipsis ">
              {service.service_description}
            </td>
            <td className="border border-gray-400 px-4 py-4 whitespace-nowrap">
				${service.USD_price}
            </td>
			<td className="border border-gray-400 px-2 py-2 whitespace-nowrap">
				Rs.{service.INR_price}
            </td>
			<td className="border border-gray-400 px-2 py-2 whitespace-nowrap">
				£{service.GBP_price}
             </td>
            <td className="border border-gray-400 px-2 py-2">
              <span
                className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${
                  service.status === "INACTIVE"
                    ? "bg-red-100 text-red-700"
                    : "bg-green-100 text-green-700"
                }`}
              >
                {service.status || "ACTIVE"}
              </span>
            </td>
            <td className="border border-gray-400 px-2 py-2 whitespace-nowrap">
              {new Date(service.created_at).toLocaleString()}
            </td>
          </tr>
        );
      })}
    </tbody>
  </table>
</div>

            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ServiceConfiguration;