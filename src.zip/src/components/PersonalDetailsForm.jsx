import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Client from "./Client.jsx";
import { baseURL } from "./baseURL";
import logo from '../assets/logo.png';
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaKey,
  FaLockOpen,
  FaWhatsapp ,
  FaStarAndCrescent ,
  FaQuestion ,
  FaQuran ,
  } from "react-icons/fa";	
import { Country, State, City} from 'country-state-city';
	
const PersonalDetailsForm = () => {
  
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    mobile: "",
    address: "",
    city: "",
    state: "",
    country: "",
  });
	
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "full_name") {
      // Prevent special characters in full name
      if (/[^a-zA-Z\s]/.test(value)) return;
    }
    setFormData({ ...formData, [name]: value });
  };

  const handlePincodeChange = async (e) => {
    const value = e.target.value;
    setFormData({ ...formData, pincode: value });

    if (value.length === 6) {
      try {
        const response = await axios.get(`https://api.postalpincode.in/pincode/${value}`);
        const data = response.data[0];

        if (data.Status === "Success") {
          const postOffice = data.PostOffice[0];
          setFormData((prev) => ({
            ...prev,
            city: postOffice.District,
            state: postOffice.State,
          }));
        } else {
          setFormData((prev) => ({ ...prev, city: "", state: "" }));
          alert("Invalid Pincode");
        }
      } catch (error) {
        console.error("Error fetching pincode data:", error);
        alert("Failed to fetch city/state. Try again later.");
      }
    } else {
      setFormData((prev) => ({ ...prev, city: "", state: "" }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
	
	if (!formData.full_name ||
		!formData.email ||
		!formData.mobile ||
		!formData.address ||
		!formData.city ||
		!formData.state ||
		!formData.country
		) 
		{
			alert("Please fill in all the details!!");
			return; // Don't proceed with the API request if validation fails
		}
		if(!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(formData.email)) 
		{
			alert("Please enter valid email-id");
			setEmail('');
			return; 
		}

    try {
	console.log(formData)
      await axios.post(`${baseURL}/api/personal-details`, formData);
      alert("Personal details saved successfully!");
      navigate("/Client");
    } catch (error) {
      console.error("Error saving data:", error);
      alert("Something went wrong. Try again.");
    }
  };

  return (

    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#074572]-100 via-[#074572] to-[#D7E7F2] p-4">
				

		<form
			onSubmit={handleSubmit}
			className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md border border-[#074572]"
		>
			<h2 className="text-2xl font-bold text-center mb-6 text-gray-700">
				Personal Details
			</h2>
			<p className="text-sm text-gray-500 mb-4">
				Special characters not allowed in full name field
			</p>

			<div className="mb-4">
				<label className="block font-semibold mb-1">
				Full Name <span className="text-red-500">*</span>
				</label>
				<input
					type="text"
					name="full_name"
					value={formData.full_name}
					onChange={handleChange} 
					className="w-full border border-gray-300 rounded px-3 py-2"
				/>
			</div>

			<div className="mb-4">
				<label className="block font-semibold mb-1">
					Email <span className="text-red-500">*</span>
				</label>
				<input
					type="email"
					name="email"
					value={formData.email}
					onChange={handleChange}
					className="w-full border border-gray-300 rounded px-3 py-2"
			/>
			</div>

			<div className="mb-4">
				<label className="block font-semibold mb-1">
					Mobile Number <span className="text-red-500">*</span>
				</label>
				<input
					type="tel"
					name="mobile"
					value={formData.mobile}
					onChange={handleChange}
					className="w-full border border-gray-300 rounded px-3 py-2"
				/>
			</div>

			<div className="mb-4">
          <label className="block font-semibold mb-1">
            Address <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            name="address"
            value={formData.address}
			onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2"
          />
			</div>


        <div className="mb-4">
          <label className="block font-semibold mb-1">City</label>
          <input
            type="text"
            name="city"
            value={formData.city}
			onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2"
            
          />
        </div>

        <div className="mb-4">
          <label className="block font-semibold mb-1">State</label>
          <input
            type="text"
            name="state"
            value={formData.state}
			onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2"
            
          />
        </div>

        <div className="mb-4">
          <label className="block font-semibold mb-1">Country</label>
          <input
            type="text"
            name="country"
            value={formData.country}
			onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-[#074572] text-[#F2F6FA] font-bold py-2 px-4 rounded hover:bg-[#D7E7F2]"
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default PersonalDetailsForm;