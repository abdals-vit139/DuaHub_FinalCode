import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import s1 from "../assets/s1.jpeg";
import s2 from "../assets/s2.jpg";
import introVideo from "../assets/IntroVideo.mp4";
import About from "./About";
import Values from "./Values";
import Services from "./Services";
import Contact from "./Contact.jsx";
import Login from "./Login.jsx";
import Client from "./Client.jsx";
import { Link } from "react-router-dom";
import { useState, useRef ,useEffect} from "react";
import {
  FaEnvelope,
  FaPhoneAlt,
  FaMapMarkerAlt,
  FaBars,
  FaTimes,
  FaHome,
  FaHeart,
  FaShieldAlt,
  FaHandsHelping,
  FaLock ,
  FaKey,
  FaLockOpen,
  FaWhatsapp ,
  FaStarAndCrescent ,
  FaQuestion ,
  FaQuran ,
  FaArrowUp
  } from "react-icons/fa";


export default function Home() {


	const [menuOpen, setMenuOpen] = useState(false);
	const videoRef = useRef(null);
	const [isPlaying, setIsPlaying] = useState(true);
	const [showVideo, setShowVideo] = useState(true);
	const [isVisible, setIsVisible] = useState(false);
	localStorage.clear();
	const scrollToTop = () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	};
	
	useEffect(() => {
		const handleScroll = () => {
			setIsVisible(window.scrollY > 500);
			};

			window.addEventListener('scroll', handleScroll);

		// Cleanup the listener on unmount
		return () => window.removeEventListener('scroll', handleScroll);
	}, []);

	return (

    <div className="font-sans overflow-x-hidden w-screen m-0 p-0">
	
		<section className="relative sm:h-[150vh] h-[30vh] w-full overflow-x-hidden sm:mt-0 mt-10">
			{/* Background Slider */}
			<div className="absolute inset-0 z-0">
				<Carousel
				autoPlay
				infiniteLoop
				showThumbs={false}
				showStatus={false}
				interval={4000}
				transitionTime={500}
				showArrows={false}
				swipeable
				emulateTouch
				className="w-full h-full !m-0 !p-0"
				stopOnHover={false}
				style={{ transitionTimingFunction: "ease-in-out" }}
				>
				{[s1,s2].map((img, i) => (
				<div key={i} >
					<img
					src={img}
					alt={`Slide ${i + 1}`}
					className="w-full h-full object-cover" 
				/>
				</div>
				))}	
				</Carousel>
				
			</div>		
	
		</section>
		{/* Other Sections */}
		
	
			<About />
			<Values /> 
			<Services />
			<Contact />

		<div className="flex justify-center gap-5">
		{isVisible && <FaArrowUp size={50} className="fixed bottom-25 left-3 bg-[#074572] text-white p-4 ml-1 rounded-full shadow-lg  transition z-50" onClick={scrollToTop}/>}
			<a
			href="https://wa.me/1234567890" // Replace with your WhatsApp number
			target="_blank"
			rel="noopener noreferrer"
			className="fixed bottom-5 left-3 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition z-50"
			>
				<FaWhatsapp size={28} />
				</a>
				{showVideo && (
        <div className="fixed bottom-5 right-5 z-50">
          {/* Video Element */}
          <video
			className="w-full h-70 rounded-xl shadow-lg"
            src={introVideo}
            autoPlay
            muted
            loop
            playsInline
            controls
          />
		  {/* Close Button */}
          <button
            onClick={() => setShowVideo(false)}
            className="absolute -top-1 -right-2 bg-white rounded-full p-1 shadow hover:bg-red-100 transition"
            aria-label="Close video"
          >
            <FaTimes className="text-red-500" />
          </button>
        </div>
      )}
		</div>
    </div>
  );
}

function Section({ title, id, children, titleClassName = "", titleStyle = {} }) {
  return (
    <section id={id} className="bg-white shadow-md rounded-xl p-6 overflow-x-hidden">
      <h2 className={`text-3xl font-bold mb-3 ${titleClassName}`} style={titleStyle}>
        {title}
      </h2>
      {children}
    </section>
  );
}
