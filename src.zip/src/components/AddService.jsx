import React, { useState } from "react";
import Sidebar from "../layouts/Sidebar";
import Header from "../layouts/Header";

function AddService() {
  const [heading, setHeading] = useState("");
  const [tagline, setTagline] = useState("");
  const [description, setDescription] = useState("");
  const [prices, setPrices] = useState({
    USD: "",
    INR: "",
    GBP: "",
    
  });
  const [showPrices, setShowPrices] = useState(false);

  const wordLimit = 30;

  const currencySymbols = {
    USD: "$",
    INR: "Rs.",
    GBP: "£",
    
  };

  const handlePriceChange = (currencyCode, value) => {
    setPrices({ ...prices, [currencyCode]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const wordCount = description.trim().split(/\s+/).filter(Boolean).length;
    if (wordCount > wordLimit) {
      alert(`Description must be ${wordLimit} words or fewer.`);
      return;
    }

    // Validate prices only if price inputs are shown
    if (!showPrices) {
      alert("Please click 'Show Prices' and fill prices for all currencies.");
      return;
    }

    const missingPrices = Object.entries(prices).filter(
      ([, value]) => !value || isNaN(value) || Number(value) < 0
    );

    if (missingPrices.length > 0) {
      alert("Please enter valid prices for all currencies.");
      return;
    }

    const payload = {
      service_heading: heading,
      service_tagline: tagline,
      service_description: description,
      prices: Object.entries(prices).map(([currency, price]) => ({
        currency,
        price: parseFloat(price),
      })),
    };

    try {
      const res = await fetch("http://localhost:7000/api/services/multi", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        alert("Service added successfully for all currencies!");
        setHeading("");
        setTagline("");
        setDescription("");
        setPrices({ USD: "", INR: "", GBP: ""});
        setShowPrices(false);
      } else {
        const data = await res.json();
        alert(`Failed to save service: ${data.error || res.statusText}`);
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Error saving service");
    }
  };

  return (
  <div className="min-h-screen bg-[#F2F6FA] text-black">
    <Header />
    <div className="flex flex-col lg:flex-row">
      <Sidebar />
      <div className="w-full flex flex-col items-center px-4 sm:px-6 lg:px-8 pt-0">
  <h1 className="flex items-center text-3xl sm:text-4xl font-extrabold text-[#074572] w-full max-w-lg mx-auto mt-4 mb-5">
    <span className="flex-grow border-t border-[#074572] mr-4"></span>
    Add Services
    <span className="flex-grow border-t border-[#074572] ml-4"></span>
  </h1>



        <div className="w-full max-w-2xl mx-auto bg-white rounded-xl shadow-md p-8 border border-gray-200">
          <h2 className="text-3xl font-bold text-[#074572] mb-6 border-b pb-2 border-gray-300">
            Add New Service
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-gray-700 font-semibold">Service Heading</label>
              <input
                type="text"
                value={heading}
                onChange={(e) => setHeading(e.target.value)}
                required
                placeholder="e.g., Surah Yaseen"
                className="w-full px-4 py-2 border border-gray-300 rounded-md"
              />
            </div>

            <div>
              <label className="text-gray-700 font-semibold">Service Tagline</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                required
                placeholder='e.g., "Heart of the Quran"'
                className="w-full px-4 py-2 border border-gray-300 rounded-md"
              />
            </div>

            <div>
              <label className="text-gray-700 font-semibold">Service Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                rows={4}
                placeholder="Max 30 words"
                className="w-full px-3 py-1 border border-gray-300 rounded-md"
              />
              <p className="text-sm text-gray-500 mt-1">
                {description.trim().split(/\s+/).filter(Boolean).length}/{wordLimit} words
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowPrices(!showPrices)}
              className="bg-[#074572] text-white px-4 py-2 rounded-md hover:bg-[#063a59] transition"
            >
              {showPrices ? "Hide Prices" : "Add Prices"}
            </button>

            {showPrices && (
  <div>
    <label className="text-gray-700 font-semibold block mb-2">
      Prices (All Currencies)
    </label>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {["USD", "INR", "GBP"].map((currency) => (
        <div key={currency}>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {currency} ({currencySymbols[currency]})
          </label>
          <input
            type="number"
            value={prices[currency]}
            onChange={(e) => handlePriceChange(currency, e.target.value)}
            placeholder={`Enter price in ${currency}`}
            min="0"
            step="0.01"
            className="w-full px-4 py-2 border border-gray-300 rounded-md"
          />
        </div>
      ))}
    </div>
  </div>
)}

            <button
              type="submit"
              className="w-full bg-[#074572] text-white py-2 rounded-md font-semibold hover:bg-[#063a59] transition"
            >
              Save Service
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
);

}

export default AddService;