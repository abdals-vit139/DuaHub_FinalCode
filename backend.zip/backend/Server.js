require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');
const multer = require("multer");
const path = require("path"); // ✅ Add this line
const fs = require("fs");
const moment = require('moment');
const useragent = require('useragent');
const axios = require('axios');
const crypto = require('crypto');


const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME, // change this
}); 

/*const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'shabnam',
  database: 'duahub_db', // change this
});*/

// ✅ Updated getClientIp (async)
// Utility to get client IP
const getClientIp = async (req) => {
  let ip =
    req.headers['x-forwarded-for']?.split(',')[0] ||
    req.socket?.remoteAddress ||
    req.connection?.remoteAddress ||
    req.ip ||
    null;

  // Clean IPv6-mapped IPv4
  ip = ip?.includes('::ffff:') ? ip.split('::ffff:')[1] : ip;

  // If local/private IP, fetch public IP
  const isPrivate =
    ip === '127.0.0.1' ||
    ip === '::1' ||
    ip?.startsWith('192.168.') ||
    ip?.startsWith('10.') ||
    ip?.startsWith('172.16.') ||
    ip?.startsWith('172.17.') ||
    ip?.startsWith('172.18.') ||
    ip?.startsWith('172.19.') ||
    ip?.startsWith('172.2') ||
    ip?.startsWith('::ffff:127.');

  if (isPrivate) {
    try {
      const response = await axios.get('https://api.ipify.org?format=json');
      return response.data.ip; // Public IP from external service
    } catch (error) {
      console.error('Error fetching public IP:', error.message);
      return ip; // Fallback to local IP
    }
  }

  return ip;
};

// ✅ Utility to get private IP (used in /get-ip route)
const getClientPrivateIp = (req) => {
  let ip =
    req.headers['x-forwarded-for']?.split(',')[0] ||
    req.socket?.remoteAddress ||
    req.connection?.remoteAddress ||
    req.ip ||
    null;

  if (ip?.includes('::ffff:')) {
    ip = ip.split('::ffff:')[1];
  }

  return ip;
};

// 📌 New route to test local IP
app.get('/get-ip', (req, res) => {
  const clientIp = getClientPrivateIp(req);
  console.log('Client Private IP:', clientIp);
  res.json({ ip: clientIp });
});

// Get location
const getLocation = async (ip) => {
  try {
    const response = await axios.get(`https://ipapi.co/${ip}/json/`);
    const data = response.data;
	console.log(data);
    return `${data.city || 'Unknown'}, ${data.region || 'Unknown'}, ${data.country_name || 'Unknown'},${data.currency || 'Unknown'}`;
  } catch (error) {
    console.error('Geolocation failed:', error.message);
    return 'Unknown Location';
  }
};

// Send admin login alert
const sendAdminNotification = async (name, email, userAgent, loginTime, ip) => {
  const agent = useragent.parse(userAgent);
  const deviceDetails = `${agent.toAgent()} on ${agent.os.toString()}`;
  const cleanIp = ip?.includes('::ffff:') ? ip.split('::ffff:')[1] : ip;
  const location = await getLocation(cleanIp);

  const mailOptions = {
    from: 'verheffensystems@gmail.com',
    to: 'sunitamore078@gmail.com',
    subject: '🔐 User Login Alert',
    html: `
      <p><strong>Hi Admin,</strong></p>
      <p>User <strong>${name}</strong> just logged in.</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Location:</strong> ${location}</p>
      <p><strong>Device:</strong> ${deviceDetails}</p>
      <p><strong>Time:</strong> ${loginTime}</p>
      <p><strong>IP Address:</strong> ${cleanIp}</p>
    `
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Admin notification email failed:', error);
    } else {
      console.log('Admin notified:', info.response);
    }
  });
};


// Nodemailer setup
const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: 'verheffensystems@gmail.com',
    pass: 'kflczfcyrhbwpxne',
  }
});

// Generate OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Send OTP
app.post('/send-otp', async (req, res) => {
  const { email, phone } = req.body;
  console.log("In send OTP");
  const otp = generateOTP();
  const expiresAt = new Date(Date.now() + 5 * 60000);
  const ipAddress = await getClientIp(req); // ✅ now async

  if (!email) return res.status(400).json({ message: 'Email is required' });

  db.query(
    'INSERT INTO otp_codes (email, otp, expires_at, ip_address) VALUES (?, ?, ?, ?)',
    [email, otp, expiresAt, ipAddress],
    (err) => {
      if (err) {
        console.error('Insert error:', err);
        return res.status(500).json({ message: 'Error saving OTP' });
      }

const mailOptions = {
      from: 'sunitamore078@gmail.com',
      to: email,
      subject: 'DuaHub Login OTP',
       html: `<!DOCTYPE html>
<html>
  <body style="font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; color: #333;">
    <div style="max-width: 600px; margin: auto; background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
      <h2 style="color: #074572;">Your DuaHub OTP and Our Gratitude</h2>
      <p>Dear <strong>${email}</strong>,</p>

      <p>Thank you for choosing and trusting <strong>DuaHub</strong>.</p>

      <p>We are deeply honored to be a part of your spiritual journey.<br>
      Your faith in us means more than words can express, and we are committed to serving you with sincerity, care, and devotion.</p>

      <p style="font-style: italic;">✨ May your duas be accepted and your loved ones be blessed.</p>

      <p style="font-size: 18px; font-weight: bold; color: #074572;">
        🔐 Your OTP is: <span style="color: #d6336c;">${otp}</span>
      </p>

      <p>With gratitude and prayers,<br>
      <strong>The DuaHub Team</strong></p>
    </div>
  </body>
</html>
`,
    };

      transporter.sendMail(mailOptions, (error) => {
        if (error) return res.status(500).json({ message: 'Failed to send OTP' });

        db.query('SELECT * FROM users WHERE email = ?', [email], (err, result) => {
          if (err) return res.status(500).json({ message: 'DB error' });

          const userExists = result.length > 0;
          res.json({ message: 'OTP sent', userExists });
        });
      });
    }
  );
});

app.post('/verify-otp', async (req, res) => {
  const { email, otp, name, phone, address } = req.body;
	console.log("In verify otp");
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const ip = await getClientIp(req);
  const loginTime = moment().format('YYYY-MM-DD HH:mm:ss');

  const cleanIp = ip?.includes('::ffff:') ? ip.split('::ffff:')[1] : ip;
  const locationStr = await getLocation(cleanIp);
  const [city, state, country] = locationStr.split(',').map(part => part.trim());

  db.query(
    'SELECT * FROM otp_codes WHERE email = ? AND otp = ? AND expires_at > NOW() ORDER BY id DESC LIMIT 1',
    [email, otp],
    (err, otpResults) => {
      if (err || otpResults.length === 0) {
        return res.status(400).json({ message: 'Invalid or expired OTP' });
      }

      db.query('SELECT * FROM users WHERE email = ?', [email], (err, userResults) => {
        if (err) return res.status(500).json({ message: 'DB error on user check' });

        if (userResults.length === 0) {
          // Register new user with autofilled location
          db.query(
            `INSERT INTO users (email, name, phone, address, city, state, country, role)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [email, name, phone, address, city, state, country, 'user'],
            (err) => {
              if (err) {
                console.error("Insert Error:", err);
					console.log("Error");
                return res.status(500).json({ message: 'Error saving user details' });
              }

              sendAdminNotification(name, email, userAgent, loginTime, cleanIp);
              return res.json({ message: 'User registered and logged in', role: 'user', newUser: true });
            }
          );
        } else {
          const existingUser = userResults[0];
          sendAdminNotification(existingUser.name, email, userAgent, loginTime, cleanIp);

          const message = existingUser.role === 'admin' ? 'Admin login successful' : 'Login successful';
          return res.json({ message, role: existingUser.role, newUser: false });
        }
      });
    }
  );
});

// ✅ Must match '/api/login'
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
console.log("in admin Login")
  const sql = 'SELECT * FROM users WHERE email = ? AND pwd = ?';
  db.query(sql, [email, password], (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error' });

    if (result.length > 0) {
      res.json({ message: 'Login successful', user: result[0] });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  });
});

app.post('/api/login-with-otp', (req, res) => {
  const { otp } = req.body;
  console.log(otp)
  if (!otp)
  {
	 console.log('OTP Required');
	  return res.status(400).json({ message: 'OTP required' });
  }
  const query = `SELECT * FROM login WHERE otp = ? AND status = 'ACTIVE'`;
  db.query(query, [otp], (err, results) => {
   console.log(results.length);
	if (err) 
	{
		 console.log('Server error');
		return res.status(500).json({ message: 'Server error' });
	}
    if (results.length === 0) 
	{
		console.log('Invalid OTP');
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    // Check if OTP is expired
    const expiry = new Date(results[0].otp_expiry);
    if (new Date() > expiry) {
      // Set status to 'Inactive' for the expired OTP
      const updateQuery = `UPDATE login SET status = 'INACTIVE' WHERE otp = ?`;
      db.query(updateQuery, [otp], (updateErr, updateResult) => {
        if (updateErr) {
          console.error('Failed to update OTP status:', updateErr);
          return res.status(500).json({ message: 'Server error' });
        }
        console.log('OTP status updated:', updateResult);
        return res.status(400).json({ message: 'OTP expired' });
      });
      return;
    }
	return res.json(results);

  });
});

app.post('/api/personal-details', (req, res) => {
	const formData  = req.body;
	//console.log(formData)
	
	const add_user ='INSERT INTO users (email,name,phone,created_at,address,city,state,country,role,pwd) VALUES (?,?,?,NOW(),?,?,?,?,?,?)';
		db.query(add_user, [formData.email,formData.full_name,formData.mobile,formData.address,formData.city,formData.state,formData.country,'user',null], (err, data) => 
			{
			if (err) 
			{ 
		         console.log(err);
				return res.json({Status:"error"})
			}
				else return res.json({Status:"Success"})
			
			});
});

// Get all services
app.get("/api/services", (req, res) => {
  
const sql = "select * from services s, service_prices sp where s.id=sp.service_id";

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error fetching services:", err); // Log error details
      return res.status(500).json({ error: "Internal server error" });
    }
    res.json(results);
  });
});

// Get all users
app.get("/api/admin/ListUsers", (req, res) => {
  
const sql = "select * from users";

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error fetching users:", err); // Log error details
      return res.status(500).json({ error: "Internal server error" });
    }
    res.json(results);
  });
});

// Get all services along with prices
app.get("/api/admin/getListofservices", (req, res) => {

const sql = "SELECT s.id,s.service_heading,s.service_tagline,service_description ,MAX(CASE WHEN sp.currency = 'USD' THEN sp.price END) AS USD_price, MAX(CASE WHEN sp.currency = 'INR' THEN sp.price END) AS INR_price, MAX(CASE WHEN sp.currency = 'GBP' THEN sp.price END) AS GBP_price,s.created_at FROM services s JOIN  service_prices sp ON s.id = sp.service_id GROUP BY s.id,s.service_heading,s.service_tagline,s.created_at";

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error fetching services:", err); // Log error details
      return res.status(500).json({ error: "Internal server error" });
    }
	else
	{
		console.log(results);
		res.json(results);
	}
  });
});

app.post("/api/Getservices/", (req, res) => {
  console.log("hi");

  const { email } = req.body;
  console.log(email);

  const sql = `
    SELECT ul.currency_name, sp.currency, sp.service_id, s.*, sp.price, ul.currency_code 
    FROM user_loc_cur_mapping ul
    JOIN users u ON u.country = ul.country
    JOIN service_prices sp ON ul.currency_name = sp.currency
    JOIN services s ON sp.service_id = s.id
    WHERE u.email = ?
	and s.status='ACTIVE'
  `;

  db.query(sql, [email], (err, results) => {
    if (err) {
      console.error("Error fetching services:", err);
      return res.status(500).json({ error: "Internal server error" });
    }

    if (results.length === 0) {
      // If no location-based services found, return USD-based services
      const fallbackQuery = `
        SELECT 
    ul.currency_code, 
    sp.currency , 
    sp.service_id, 
    s.*, 
    sp.price 
FROM 
    service_prices sp
JOIN 
    services s ON sp.service_id = s.id
JOIN 
    user_loc_cur_mapping ul ON sp.currency = ul.currency_name
WHERE 
    sp.currency = 'USD'
	and s.status='ACTIVE'
      `;

      db.query(fallbackQuery, (err, fallbackResults) => {
        if (err) {
          console.error("Error fetching fallback services:", err);
          return res.status(500).json({ error: "Internal server error" });
        }

        return res.json(fallbackResults);
      });
    } else {
      return res.json(results);
    }
  });
});

//18-06-25
// PUT /api/services/:id
app.put('/api/services/:id', async (req, res) => {
  const { id } = req.params;
  const { service_heading, service_tagline, service_description, status } = req.body;

  try {
    await db.query(
      "UPDATE services SET service_heading = ?, service_tagline = ?, service_description = ?, status = ? WHERE id = ?",
      [service_heading, service_tagline, service_description, status, id]
    );
    res.status(200).json({ message: "Service updated successfully." });
  } catch (error) {
    res.status(500).json({ error: "Failed to update service." });
  }
});
app.post('/api/GetUser', (req, res) => {
const {email}  = req.body;
	console.log(email)
	
	const search_user ='select * from users where email =?';
		db.query(search_user, [email], (err, data) => 
			{
			if (err) 
			{ 
		         console.log(err);
				return res.json({Status:"error"})
			}
				else return res.json(data)
			
			});
});

// POST endpoint to save bill
/*app.post('/api/save-bill', (req, res) => {
  const { username, paymentMethod, items, totalItems, totalPrice } = req.body;

  if (!username || !paymentMethod || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: 'Invalid bill data' });
  }

  const billItems = items.map(item => [
    username,
    paymentMethod,
    item.image?.split("/").pop().split(".")[0] || 'Unknown', // product_name
    item.quantity || 0,
    totalItems || 0,
    totalPrice || 0,
    new Date() // bill_date
  ]);

  const query = `
    INSERT INTO billing 
    (username, payment_method, product_name, quantity, total_items, total_price, bill_date)
    VALUES ?
  `;

  db.query(query, [billItems], (err, result) => {
    if (err) {
      console.error("Error inserting bill:", err);
      return res.status(500).json({ message: 'Error saving bill', error: err });
    }
    res.status(200).json({ message: 'Bill saved successfully' });
  });
});*/
const pdfUploader = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const folder = path.join(__dirname, 'Bills'); // create 'pdfs' inside your backend root
      if (!fs.existsSync(folder)) fs.mkdirSync(folder);
      cb(null, folder);
    },
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      cb(null, `invoice_${timestamp}.pdf`);
    },
  }),
});

/*app.post('/api/save-bill', pdfUploader.single('pdf'), (req, res) => {
  try {
    console.log(req.body);

    const { username, paymentMethod, totalItems, totalPrice } = req.body;
    const items = JSON.parse(req.body.items || '[]');

    const esaalDetails = JSON.parse(req.body.Esaal_details || '{}');

    const { deceased_name, relation, date_of_death, esaal_date, schedule } = esaalDetails;

    if (!username || !paymentMethod || items.length === 0 || !req.file) {
      return res.status(400).json({ message: 'Invalid bill data' });
    }

    const billdoc = req.file.path;

    const billItems = items.map(item => [
      username,
      paymentMethod,
      item.heading || 'Unknown',
      item.quantity || 0,
      totalItems || 0,
      totalPrice || 0,
      new Date(),
      'pending',
      billdoc
    ]);

    const insertBillingQuery = `
      INSERT INTO billing 
      (username, payment_method, product_name, quantity, total_items, total_price, bill_date, order_status, bill_doc)
      VALUES ?
    `;

    db.query(insertBillingQuery, [billItems], (err, result) => {
      if (err) {
        console.error("Error inserting bill:", err);
        return res.status(500).json({ message: 'Error saving bill', error: err });
      }

      const BillId = result.insertId;

      const insertEsaalQuery = `
        INSERT INTO esaal_details
        (bill_id, deceased_name, relation, date_of_death, esaal_date, schedule, email, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
      `;

      db.query(insertEsaalQuery, [
        BillId,
        deceased_name,
        relation,
        date_of_death,
        esaal_date,
        schedule,
        username
      ], (err2) => {
        if (err2) {
          console.error('Error inserting Esaal details:', err2);
          return res.status(500).json({ error: 'Failed to insert Esaal details', details: err2 });
        }

        res.status(200).json({ message: 'Bill and Esaal details saved successfully.' });
      });
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ message: 'Unexpected server error', error: error });
  }
});*/

app.post('/api/save-bill', pdfUploader.single('pdf'), (req, res) => {
  try {
    const { username, paymentMethod, totalItems, totalPrice } = req.body;
    const items = JSON.parse(req.body.items || '[]');
	console.log("Item list")
	--console.log(items);
    const esaalDetails = JSON.parse(req.body.Esaal_details || '{}');
	console.log(esaalDetails);
    const { deceased_name, relation, date_of_death, esaal_date, schedule } = esaalDetails;
	console.log(relation);
    if (!username || !paymentMethod || items.length === 0 || !req.file) {
      return res.status(400).json({ message: 'Invalid bill data' });
    }

    const billdoc = req.file.path;

    // ✅ STEP 1: Insert into billing (one record)
    const insertBillingQuery = `
      INSERT INTO billing 
      (username, payment_method, total_items, total_price, bill_date, order_status, bill_doc)
      VALUES (?, ?, ?, ?, NOW(), 'pending', ?)
    `;

    db.query(insertBillingQuery, [username, paymentMethod, totalItems, totalPrice, billdoc], (err, result) => {
      if (err) {
        console.error("Error inserting bill:", err);
        return res.status(500).json({ message: 'Error saving bill', error: err });
      }

      const BillId = result.insertId;

      // ✅ STEP 2: Insert each item into order_list
      const orderItems = items.map(item => [
        BillId,
        item.heading || 'Unknown',
        item.quantity || 0,
        new Date(),
		item.currency || 'Unknown',
		item.price || 0
      ]);

      const insertOrderQuery = `
        INSERT INTO order_list 
        (bill_id, product_name, quantity, created_at,currency,price)
        VALUES ?
      `;

      db.query(insertOrderQuery, [orderItems], (err2) => {
        if (err2) {
          console.error('Error inserting order list:', err2);
          return res.status(500).json({ message: 'Error saving order list', error: err2 });
        }

        // ✅ STEP 3: Insert Esaal details
        const insertEsaalQuery = `
          INSERT INTO esaal_details
          (bill_id, deceased_name, relation, date_of_death, esaal_date, schedule, email, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        `;

        db.query(insertEsaalQuery, [
          BillId,
          deceased_name,
          relation,
          date_of_death,
          esaal_date,
          schedule,
          username
        ], (err3) => {
          if (err3) {
            console.error('Error inserting Esaal details:', err3);
            return res.status(500).json({ error: 'Failed to insert Esaal details', details: err3 });
          }

          res.status(200).json({ message: 'Bill, Order list, and Esaal details saved successfully.' });
        });
      });
    });

  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ message: 'Unexpected server error', error: error });
  }
});

app.post('/update-user-details', (req, res) => {
  const { email, name, phone, address } = req.body;

  if (!email || !name || !phone || !address) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  db.query(
    `UPDATE users SET name = ?, phone = ?, address = ? WHERE email = ?`,
    [name, phone, address, email],
    (err, result) => {
      if (err) {
        console.error("Update error:", err);
        return res.status(500).json({ message: "Database update failed" });
      }

      return res.json({ message: "User details updated" });
    }
  );
});

app.post('/api/esaal-details', (req, res) => {
  const {
    deceased_name,
    relation,
    date_of_death,
    esaal_date,
    schedule,
    email
  } = req.body;

  if (!email) {
    return res.status(400).send('Email is required');
  }

  const sql = `
    INSERT INTO esaal_details
    (deceased_name, relation, date_of_death, esaal_date, schedule, email, created_at)
    VALUES (?, ?, ?, ?, ?, ?, NOW())
  `;

  const values = [
    deceased_name,
    relation,
    date_of_death,
    esaal_date,
    schedule,
    email
  ];

  db.execute(sql, values, (err, result) => {
    if (err) {
      console.error('DB Insert Error:', err);
      return res.status(500).send('Failed to save esaal details');
    }
    res.status(200).send('Esaal details saved successfully');
  });
});

// GET /api/admin/manage-status
app.get('/api/admin/manage-status', (req, res) => {
  const sql = `
    
SELECT 
	  b.id,
      b.username, 
	  b.payment_method,
      ol.product_name, 
      ol.quantity, 
	  ol.currency,
	  ol.price,
      b.total_items, 
      b.total_price, 
      b.bill_date, 
	  ed.deceased_name,
	  ed.relation,
	  ed.date_of_death,
	  ed.esaal_date,
	  ed.schedule,
      order_status 
    FROM billing  b, esaal_details ed,order_list ol
	where b.id=ed.bill_id
	and b.id=ol.bill_id
    ORDER BY bill_date DESC
  `;

  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});



// GET api/user/manage-order
app.post('/api/user/manage-order', (req, res) => {
	const {email} = req.body;
	console.log("email"+email);
  const sql = `
   	 SELECT 
	  b.id,
      b.username, 
      b.payment_method, 
      ol.product_name, 
      ol.quantity, 
	  ol.currency,
	  ol.price,
      b.total_items, 
      b.total_price, 
      b.bill_date, 
      b.order_status,
	  ed.deceased_name,
	  ed.esaal_date	  
    FROM billing  b ,esaal_details ed ,order_list ol
	where b.username=ed.email
	and b.id=ed.bill_id
	and ol.bill_id=b.id
	and b.username=?
  `;

  db.query(sql, email,(err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

// GET api/user/manage-status
app.post('/api/user/manage-status', (req, res) => {
	const {email} = req.body;
	console.log("email"+email);
  const sql = `
    SELECT 
      id, 
      username, 
      payment_method, 
      product_name, 
      quantity, 
      total_items, 
      total_price, 
      bill_date, 
      order_status	  
    FROM billing 
	where username=?
  `;

  db.query(sql, email,(err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});
// ✅ PUT - Update order status
// // 🔄 Update order status route
app.put('/api/admin/update-status/:id', (req, res) => {
  const orderId = req.params.id;
  const { order_status } = req.body;

  const query = 'UPDATE billing SET order_status = ? WHERE id = ?';

  db.query(query, [order_status, orderId], (err, result) => {
    if (err) {
      console.error('Error updating order status:', err);
      return res.status(500).json({ message: 'Database update failed' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.status(200).json({ message: 'Order status updated successfully' });
  });
});

// API endpoint for downloading a document
app.get('/document_download/:id', (req, res) => {
  
  console.log("In download function");
  const  id  = parseInt(req.params.id);
  console.log(id)
  const query = 'SELECT * FROM billing WHERE id = ?';
  db.query(query, id, (err, results) => {
    if (err || results.length === 0) {
      return res.status(404).send('Document not found');
    }
	else
	{
		console.log(results);
	}
    const filePath = results[0].bill_doc;
    res.download(filePath);
  });
});
// API endpoint for downloading a bill based on billno
app.get('/bill_download/:id', (req, res) => {
  
  console.log("In download function");
  const  id  = parseInt(req.params.id);
  console.log(id)
  const query = 'SELECT * FROM billing WHERE bill_no = ?';
  db.query(query, id, (err, results) => {
    if (err || results.length === 0) {
      return res.status(404).send('Document not found');
    }
	else
	{
		console.log(results);
	}
    const filePath = results[0].bill_doc;
    res.download(filePath);
  });
});
// GET accounting table info 19-06-25
app.get("/api/billing", (req, res) => {
  const sql = `
    SELECT 
      u.name AS client_name,
      u.email,
      u.phone AS mobile,
      u.city,
      u.state,
      u.country,
      b.bill_date AS billing_date,
      b.total_price AS billing_total,
      b.order_status AS request_status,
	  b.id as bill_no
    FROM billing b
    JOIN users u ON b.username = u.email
  `;

  db.query(sql, (err, result) => {
    if (err) {
      console.error("Error fetching billing data:", err);
      return res.status(500).json({ error: "Database error" });
    }
    res.json(result);
  });
});


// ➕ Add service with multiple prices
app.post('/api/services/multi', (req, res) => {
  const { service_heading, service_tagline, service_description, prices } = req.body;

  if (!service_heading || !Array.isArray(prices) || prices.length === 0) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Insert service
  const insertServiceQuery = `
    INSERT INTO services (service_heading, service_tagline, service_description,status)
    VALUES (?, ?, ?, ?)
  `;

  db.query(insertServiceQuery, [service_heading, service_tagline, service_description,'ACTIVE'], (err, result) => {
    if (err) {
      console.error('Error inserting service:', err);
      return res.status(500).json({ error: 'Failed to insert service' });
    }

    const serviceId = result.insertId;

    // Prepare bulk prices
    const priceValues = prices.map(({ currency, price }) => [serviceId, currency, price]);

    const insertPricesQuery = `
      INSERT INTO service_prices (service_id, currency, price)
      VALUES ?
    `;

    db.query(insertPricesQuery, [priceValues], (err) => {
      if (err) {
        console.error('Error inserting prices:', err);
        return res.status(500).json({ error: 'Failed to insert prices' });
      }

      res.json({ message: 'Service and prices saved successfully' });
    });
  });
});


//18-06-25
app.post('/api/services/:id', (req, res) => {
  const { id } = req.params;
  const { service_heading, service_tagline, service_description, status, price,service_id } = req.body;
  console.log("service_id"+service_id);
  console.log("id"+id);
  const query1 = 'UPDATE services SET service_heading = ?, service_tagline = ?, service_description = ?, status = ? WHERE id = ?';
  const query2 = 'UPDATE service_prices SET price = ? WHERE id = ?';
	
  db.query(query1, [service_heading, service_tagline, service_description, status, service_id], (err1, results1) => {
    if (err1) {
      console.error('Error updating services:', err1);
      return res.status(500).json({ error: "Failed to update service details." });
    }
	console.log(`Services table updated, Rows affected: ${results1.affectedRows}`);
    db.query(query2, [price, id], (err2, results2) => {
      if (err2) {
        console.error('Error updating service price:', err2);
        return res.status(500).json({ error: "Failed to update service price." });
      }
		console.log(`Services table updated, Rows affected: ${results2.affectedRows}`);
      return res.status(200).json({ message: "Service updated successfully." });
    });
  });
});


app.get('/maxBillID',(re,res)=>
{
	const sql="select IFNULL(max(id)+1,1) as BillID from billing";
	db.query(sql,(err,data)=>
	{
		if (err) return res.json(err);
		else
		{
			console.log(data);
			return res.json(data);
		}
	});	
})
app.listen(7000, () => console.log('Server running on http://localhost:7000'));

app.get('/',(re,res)=>
{
	return res.json("from backend");
})